define(function (require, exports, module) {

    var activityId = utils.getQuery("activityId");

    var animationProgressTable;
    var Home = Backbone.View.extend({

        el: document.getElementsByTagName('body')[0],
        events: {
            "click .refresh-btn": "refreshHandler",
            "click .modify-progress": "modifyProgressHandler",
            "click .add-progress":"addProgressHandler"
        },

        initialize: function () {
            this.model = new Backbone.Model();
            this.model.set("resourceData", resourceData);
            this.initData();
        },
        initData: function () {
            animationProgressTable = $('#animationProgressTable').DataTable({
                // 不显示分页相关
                "paging" : false,
                "ordering" : false,
                "info" : true,
                // 不显示分页相关.
                "ajax" : {
                    url: baseUrl + "/console/activity/listanimationprogress",
                    "data": function (temp) {
                        temp.activityId = activityId;
                        return JSON.stringify(temp);
                    }
                },
                "columns" : [{
                    "data": "activityId", // 活动Id
                    "targets": [ 0 ],
                    "visible": false,
                    "searchable": false
                },{
                    "data": "timerId",
                    "targets": [ 1 ],
                    "visible": false,
                    "searchable": false
                },{
                    "data": "id"
                },{
                    "data": "sf"
                },{
                    "data": "tf"
                },{
                    "data": "pId"
                },{
                    "data": "cpf"
                },{
                    "data": "ctf"
                },{
                    "render" : function(data, type,row) {
                        var html = "";
                        if (1 == row.addBtn) {

                            html += "<button  data-text='新增'  data-id='add-progress' data-link='../animationprogressadd/animationprogressadd.html?activityId=" +
                                activityId +
                                "&pId=" +
                                row.id +
                                "'  class='btn btn-primary btn-xs margin-right-5 add-progress'><i class='fa fa-pencil' aria-hidden='true'></i>新增</button>";
                        }
                        if (1 == row.modifyBtn) {
                            html += "<button  data-text='修改'  data-id='modify-progress' data-link='../animationprogressmodify/animationprogressmodify.html?id=" +
                                row.id +
                                "'  class='btn btn-primary btn-xs margin-right-5 modify-progress'><i class='fa fa-pencil' aria-hidden='true'></i>修改</button>";
                        }
                        if (1 == row.delBtn) {
                            html  += "<a data-text='删除' class='btn btn-primary btn-xs margin-right-5 del-progress' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>删除</a>";
                        }
                        if (1 == row.resetBtn) {
                            html  += "<a data-text='清零当前进度和当前计时' class='btn btn-primary btn-xs margin-right-5 on-progress' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>开始</a>";
                            html  += "<a data-text='清零当前进度和当前计时' class='btn btn-primary btn-xs margin-right-5 off-progress' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>暂停</a>";
                            html  += "<a data-text='清零当前进度和当前计时' class='btn btn-primary btn-xs margin-right-5 reset-progress' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>清零当前进度和当前计时</a>";
                        }
                        return html;
                    }
                }]
            });
        },
        modifyProgressHandler : function (event) {
            addTab(event, true);
        },
        addProgressHandler : function (event) {
            addTab(event, true);
        },
        refreshHandler : function () {
            animationProgressTable.ajax.reload(null, false);
        }
    });

    var home = new Home();

    $(function(){
        setInterval(function(){
            animationProgressTable.ajax.reload(null, false);
        }, 10000);
    });

    // 暂停
    $('#animationProgressTable tbody').on( 'click', 'a.off-progress', function () {
        var data = animationProgressTable.row($(this).parents('tr')).data();

        $.ajax({
            url: baseUrl + "/console/activity/offprogress",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("暂停");
                    animationProgressTable.ajax.reload(null, false);
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    // 开始
    $('#animationProgressTable tbody').on( 'click', 'a.on-progress', function () {
        var data = animationProgressTable.row($(this).parents('tr')).data();

        $.ajax({
            url: baseUrl + "/console/activity/onprogress",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("开始");
                    animationProgressTable.ajax.reload(null, false);
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    // 清零当前进度和当前计时
    $('#animationProgressTable tbody').on( 'click', 'a.reset-progress', function () {
        var data = animationProgressTable.row($(this).parents('tr')).data();

        $(".alert-view .alert-txt", parent.document).html("确认要清零当前进度和当前计时?");
        $(".alert-view", parent.document).show();

        $(".alert-view .s-btn", parent.document).unbind("click");
        var _parent = parent.document;
        $(".alert-view .s-btn", parent.document).click(function () {
            var $alert = $(".alert-view", _parent);
            if ($alert)
                $alert.hide();
            $.ajax({
                url: baseUrl + "/console/activity/resetprogress",
                type: 'POST',
                dataType: 'json',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({
                    timerId : data.timerId
                }),
                success: function(data){
                    if (200 == data.code) {
                        utils.showTip("清零完成");
                        animationProgressTable.ajax.reload(null, false);
                    } else {
                        utils.showTip(data.message);
                    }
                }
            });
        })
    });

    // 删除
    $('#animationProgressTable tbody').on( 'click', 'a.del-progress', function () {
        var data = animationProgressTable.row($(this).parents('tr')).data();

        $(".alert-view .alert-txt", parent.document).html("确认删除此条进度设置?");
        $(".alert-view", parent.document).show();

        $(".alert-view .s-btn", parent.document).unbind("click");
        var _parent = parent.document;
        $(".alert-view .s-btn", parent.document).click(function () {
            var $alert = $(".alert-view", _parent);
            if ($alert)
                $alert.hide();
            $.ajax({
                url: baseUrl + "/console/activity/delprogress",
                type: 'POST',
                dataType: 'json',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({
                    id : data.id
                }),
                success: function(data){
                    if (200 == data.code) {
                        utils.showTip("删除完成");
                        animationProgressTable.ajax.reload(null, false);
                    } else {
                        utils.showTip(data.message);
                    }
                }
            });
        })
    });

});

seajs.use('./animationprogresslist.js');
define(function (require, exports, module) {
    var activityVoteLotteryDogTable;
    var Home = Backbone.View.extend({

        el: document.getElementsByTagName('body')[0],

        events: {
            "click .search-btn": "handlerSearch"
        },
        initialize: function () {
            this.model = new Backbone.Model();
            this.model.set("resourceData", resourceData);
            this.initData();
        },
        initData: function () {
            activityVoteLotteryDogTable = $('#activityVoteLotteryDogTable').DataTable({
                // 不显示分页相关
                "paging" : false,
                "ordering" : false,
                "info" : true,
                // 不显示分页相关.
                "ajax" : {
                    url: baseUrl + "/console/activity/votelotterydog",
                    "data": function (temp) {
                        temp.activityName = $("#activityName").val();
                        temp.departmentName = $("#userDepartmentName").val();
                        temp.userName = $("#userName").val();
                        return JSON.stringify(temp);
                    }
                },
                "columns" : [{
                    "data": "id", // 记录Id
                    "targets": [ 0 ],
                    "visible": false,
                    "searchable": false
                },{
                    "data": "activityName" // 活动名称
                },{
                    "data": "userName" //中奖人姓名
                },{
                    "data": "userDepartmentName" // 中奖人部门
                },{
                    "data": "receiveFlag", // 战队1Id
                    "targets": [ 4 ],
                    "visible": false,
                    "searchable": false
                },{
                    "render" : function(data, type,row) {
                        var html = "";
                        if (1 == row.receiveFlag) {
                            html  += "<a data-text='未发' class='btn btn-primary btn-xs margin-right-5 cancel-prize' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>未发</a>";
                        }
                        if (2 == row.receiveFlag) {
                            html  += "<a data-text='已发' class='btn btn-primary btn-xs margin-right-5 receive-prize' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>已发</a>";
                        }
                        return html;
                    }
                }]
            });
        },
        handlerSearch:function () {
            activityVoteLotteryDogTable.ajax.reload(null, false);
        }
    });

    var home = new Home();

    $('#activityVoteLotteryDogTable tbody').on( 'click', 'a.cancel-prize', function () {
        var data = activityVoteLotteryDogTable.row($(this).parents('tr')).data();
        $.ajax({
            url: baseUrl + "/console/activity/receiveprize",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({activityLuckyDogId:data.id}),
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("已发");
                    activityVoteLotteryDogTable.ajax.reload(null, false);
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    $('#activityVoteLotteryDogTable tbody').on( 'click', 'a.receive-prize', function () {
        var data = activityVoteLotteryDogTable.row($(this).parents('tr')).data();
        $.ajax({
            url: baseUrl + "/console/activity/cancelprize",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({activityLuckyDogId:data.id}),
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("未发");
                    activityVoteLotteryDogTable.ajax.reload(null, false);
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });



});

seajs.use('./activtitylotterydoglist1.js');
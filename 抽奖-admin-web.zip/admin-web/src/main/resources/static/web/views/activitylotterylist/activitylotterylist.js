define(function (require, exports, module) {
    var activityLotteryTable;
    var Home = Backbone.View.extend({

        el: document.getElementsByTagName('body')[0],
        events: {
            "click .animation-progress": "animationProgressHandler"
        },
        initialize: function () {
            this.model = new Backbone.Model();
            this.model.set("resourceData", resourceData);
            this.initData();
        },
        initData: function () {
            activityLotteryTable = $('#activityLotteryTable').DataTable({
                // 不显示分页相关
                "paging" : false,
                "ordering" : false,
                "info" : false,
                // 不显示分页相关.
                "ajax" : {
                    url: baseUrl + "/console/activity/listother"
                },
                "columns" : [{
                    "data": "activityId", // 活动Id
                    "targets": [ 0 ],
                    "visible": false,
                    "searchable": false
                },{
                    "data": "status", // 活动状态
                    "targets": [ 1 ],
                    "visible": false,
                    "searchable": false
                },{
                    "data": "activityType", // 活动类型
                    "targets": [ 2 ],
                    "visible": false,
                    "searchable": false
                },{
                    "data": "activityName" //活动名称
                },{
                    "data": "activityPrizeId", // 奖项Id
                    "targets": [ 4 ],
                    "visible": false,
                    "searchable": false
                },{
                    "data": "prizeName" // 奖品名称
                },{
                    "data": "activityPrizeWinningNumber" //奖品数量
                },{
                    "render" : function(data, type,row) {
                        var html = "";
                        if (2 == row.activityType) {
                             html += "<a data-text='奖品展示' class='btn btn-primary btn-xs margin-right-5 display-prize1' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>奖品展示</a>";

                             html += "<a data-text='抽奖展示' class='btn btn-primary btn-xs margin-right-5 display-lottery1' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>抽奖展示</a>";
                            html += "<br/>";
                            html += "<br/>";
                             // html += "<button  data-text='动画进度设置'  data-id='animation-progress' data-link='../animationprogresslist/animationprogresslist.html?activityId=" +
                            //     row.activityId +
                            //     "'  class='btn btn-primary btn-xs margin-right-5 animation-progress'><i class='fa fa-pencil' aria-hidden='true'></i> 动画进度设置</button>";

                            // html += "<a data-text='动画进度设置' class='btn btn-primary btn-xs margin-right-5 animation-progress' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>动画进度设置</a>";
//                            html += "<a data-text='开始动画' class='btn btn-primary btn-xs margin-right-5 play-animation' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>开始动画</a>";
//                            html += "<a data-text='抽奖开始' class='btn btn-primary btn-xs margin-right-5 decibel-lottery' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>抽奖开始</a>";

                            html += "<a data-text='开始抽奖' class='btn btn-primary btn-xs margin-right-5 decibel-lottery' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>开始抽奖</a>";
                            html += "<br/>";
                            html += "<br/>";

                            html += "<a data-text='设置返回666' class='btn btn-primary btn-xs margin-right-5 decibel-lottery1' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>设置返回666</a>";
                            html += "<a data-text='设置返回333' class='btn btn-primary btn-xs margin-right-5 decibel-lottery2' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>设置返回333</a>";


                        //    html += "<a data-text='抽奖展示2(再次抽取333)' class='btn btn-primary btn-xs margin-right-5 display-lottery1-1' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>抽奖展示2(再次抽取333)</a>";

                            html += "<a data-text='第一轮333结束' class='btn btn-primary btn-xs margin-right-5 decibel-lottery_end_333' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>第一轮333结束</a>";
                            html += "<a data-text='设置返回剩余的333' class='btn btn-primary btn-xs margin-right-5 decibel-lottery3' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>设置返回剩余的333</a>";
                            html += "<br/>";
                            html += "<br/>";

                            html += "<a data-text='中奖结果推送到我的中奖页面' class='btn btn-primary btn-xs margin-right-5 end-activity' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>中奖结果推送到“我的中奖”页面</a>";
                            html += "<a data-text='清空结果' class='btn btn-primary btn-xs margin-right-5 clear-lottery' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>清空结果</a>";
                        }
                        // if (4 == row.activityType || 5 == row.activityType) {
                        //     html += "<a data-text='抽奖展示' class='btn btn-primary btn-xs margin-right-5 display-lottery2' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>抽奖展示</a>";
                        //     // html += "<a data-text='开启抽奖' class='btn btn-primary btn-xs margin-right-5 open-lottery' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>开启抽奖</a>";
                        //     // html += "<a data-text='清空结果' class='btn btn-primary btn-xs margin-right-5 clear-lottery-2' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>清空结果</a>";
                        // }

                        if (1 == row.showLottery) {
                            html += "<a data-text='抽奖展示' class='btn btn-primary btn-xs margin-right-5 display-lottery3' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>抽奖展示</a>";
                        }
                        if (1 == row.showClear) {
                            html += "<a data-text='清空结果' class='btn btn-primary btn-xs margin-right-5 clear-lottery-2' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>清空结果</a>";
                        }
                        if (1 == row.showLotteryDog) {
                           //  html += "<a data-text='展示中奖人' class='btn btn-primary btn-xs margin-right-5 show-lottery-dog' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>展示中奖人</a>";
                        }

                        return html;
                    }
                }]
            });
        },
        animationProgressHandler : function (event) {
            addTab(event, true);
        }
    });

    var home = new Home();

    // 奖品展示 display-prize1
    $('#activityLotteryTable tbody').on( 'click', 'a.display-prize1', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();
        var url = "../bilibili/game1.html?activityId={activityId}"
            .replace("{activityId}", data.activityId);
        window.open(url, "_blank");
    });

    // 抽奖展示
    $('#activityLotteryTable tbody').on( 'click', 'a.display-lottery1', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();
        var url = "../bilibili/game2.html?activityId={activityId}"
            .replace("{activityId}", data.activityId);
        window.open(url, "_blank");
    });

    // 抽奖展示(再次抽取333)
    $('#activityLotteryTable tbody').on( 'click', 'a.display-lottery1-1', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();
        var url = "../bilibili/game2.html?activityId={activityId}&activityPrizeInfoExtId=3"
            .replace("{activityId}", data.activityId);
        window.open(url, "_blank");
    });




    // // 设置动画进度 (弹框)
    // $('#activityLotteryTable tbody').on( 'click', 'a.animation-progress', function () {
    //     var data = activityLotteryTable.row($(this).parents('tr')).data();
    //     var url = "../animationprogresslist/animationprogresslist.html?activityId={activityId}"
    //         .replace("{activityId}", data.activityId);
    //     window.open(url);
    // });

    // 开始动画
    $('#activityLotteryTable tbody').on( 'click', 'a.play-animation', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();
        $.ajax({
            url: baseUrl + "/console/activity/playanimation",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({activityId:data.activityId}),
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("动画开始");
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    // 分贝抽奖
    $('#activityLotteryTable tbody').on( 'click', 'a.decibel-lottery', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();
        $.ajax({
            url: baseUrl + "/console/activity/decibellottery",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({activityId:data.activityId}),
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("抽奖正在进行...请等待...");
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    // 抽取666
    $('#activityLotteryTable tbody').on( 'click', 'a.decibel-lottery1', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();
        var param = JSON.stringify({
            activityId:data.activityId,
            activityPrizeInfoExtId : 1
        });
        $.ajax({
            url: baseUrl + "/console/activity/setlotterydognum",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: param,
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("设置成功！");
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    // 抽取333
    $('#activityLotteryTable tbody').on( 'click', 'a.decibel-lottery2', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();
        var param = JSON.stringify({
            activityId:data.activityId,
            activityPrizeInfoExtId : 2
        });
        $.ajax({
            url: baseUrl + "/console/activity/setlotterydognum",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: param,
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("设置成功！");
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    // 再次抽取333
    $('#activityLotteryTable tbody').on( 'click', 'a.decibel-lottery3', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();
        var param = JSON.stringify({
            activityId:data.activityId,
            activityPrizeInfoExtId : 3
        });
        $.ajax({
            url: baseUrl + "/console/activity/setlotterydognum",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: param,
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("设置成功！");
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    $('#activityLotteryTable tbody').on( 'click', 'a.decibel-lottery_end_333', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();
        var param = JSON.stringify({
            activityId:data.activityId
        });
        $.ajax({
            url: baseUrl + "/console/activity/end333",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: param,
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("设置成功！");
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });


    // 推送中奖结果
    $('#activityLotteryTable tbody').on( 'click', 'a.end-activity', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();
        $.ajax({
            url: baseUrl + "/console/activity/end",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({activityId:data.activityId}),
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("推送中奖结果完成");
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    // 清空结果
    $('#activityLotteryTable tbody').on( 'click', 'a.clear-lottery', function () {

        var data = activityLotteryTable.row($(this).parents('tr')).data();

        $(".alert-view .alert-txt", parent.document).html("确认清空本次抽奖结果?<br/>本轮抽奖将重新开始");
        $(".alert-view", parent.document).show();

        $(".alert-view .s-btn", parent.document).unbind("click");
        var _parent = parent.document;
        $(".alert-view .s-btn", parent.document).click(function () {
            var $alert = $(".alert-view", _parent);
            if ($alert)
                $alert.hide();

            $.ajax({
                url: baseUrl + "/console/activity/cleardecibellottery",
                type: 'POST',
                dataType: 'json',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({activityId:data.activityId}),
                success: function(data){
                    if (200 == data.code) {
                        utils.showTip("清空结果完成");
                    } else {
                        utils.showTip(data.message);
                    }
                }
            });
        })
    });

    // 开启抽奖
    // $('#activityLotteryTable tbody').on( 'click', 'a.open-lottery', function () {
    //     var data = activityLotteryTable.row($(this).parents('tr')).data();
    //     $.ajax({
    //         url: baseUrl + "/console/activity/openlottery",
    //         type: 'POST',
    //         dataType: 'json',
    //         contentType: "application/json; charset=utf-8",
    //         data: JSON.stringify({activityPrizeId:data.activityPrizeId}),
    //         success: function(data){
    //             if (200 == data.code) {
    //                 utils.showTip("开启抽奖完成");
    //             } else {
    //                 utils.showTip(data.message);
    //             }
    //         }
    //     });
    // });

    // 清空结果2
    $('#activityLotteryTable tbody').on( 'click', 'a.clear-lottery-2', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();

        $(".alert-view .alert-txt", parent.document).html("确认清空本次抽奖结果?<br/>本轮抽奖将重新开始");
        $(".alert-view", parent.document).show();

        $(".alert-view .s-btn", parent.document).unbind("click");
        var _parent = parent.document;
        $(".alert-view .s-btn", parent.document).click(function () {
            var $alert = $(".alert-view", _parent);
            if ($alert)
                $alert.hide();

            $.ajax({
                url: baseUrl + "/console/activity/clearlottery",
                type: 'POST',
                dataType: 'json',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({
                    activityId : data.activityId,
                    activityPrizeId:data.activityPrizeId
                }),
                success: function(data){
                    if (200 == data.code) {
                        utils.showTip("清空结果完成");
                    } else {
                        utils.showTip(data.message);
                    }
                }
            });
        })
    });

    // 抽奖展示
    $('#activityLotteryTable tbody').on( 'click', 'a.display-lottery2', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();
        var url = "../bilibili/game3.html?activityId={activityId}&activityPrizeId={activityPrizeId}"
            .replace("{activityId}", data.activityId)
            .replace("{activityPrizeId}", data.activityPrizeId);
        window.open(url, "_blank");
    });

    // 抽奖展示
    $('#activityLotteryTable tbody').on( 'click', 'a.display-lottery3', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();
        var url = "../bilibili/game3.html?activityId={activityId}"
            .replace("{activityId}", data.activityId);
        window.open(url, "_blank");
    });

    // 展示中奖人
    $('#activityLotteryTable tbody').on( 'click', 'a.show-lottery-dog', function () {
        var data = activityLotteryTable.row($(this).parents('tr')).data();
        var url = "../vote/winners.html?activityId={activityId}"
            .replace("{activityId}", data.activityId);
        window.open(url, "_blank");
    });

});

seajs.use('./activitylotterylist.js');
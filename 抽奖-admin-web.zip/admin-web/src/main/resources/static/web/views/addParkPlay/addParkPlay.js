define(function (require, exports, module) {


    var id = utils.getQuery("id");

    var Home = Backbone.View.extend({

        el: document.getElementsByTagName('body')[0],

        events: {
            "click .sure-btn": "handlerSure"
        },

        initialize: function () {
            this.model = new Backbone.Model();
            this.initData();
            this.initParkInfo();
        },

        handlerSure: function () {
            var parkId = $("#parkInfo").val();
            var username = $(".name").val();
            var password = $(".pwd").val();
            var parkName = $("#parkInfo option:selected").text();
            var postData = {
                "username": username,
                "password": password,
                "parkId": parkId,
                "parkName": parkName,
                "workerType": 1
            }
            if (username == "") {
                utils.showTip("请输入账号");
                return;
            }
            if (password == "") {
                utils.showTip("请输入密码 ");
                return;
            }

            if (id) {
                this.handlerEdit(postData);
            } else {
                if (password == "") {
                    utils.showTip("请输入密码");
                    return;
                } else {
                    postData["password"] = password;
                }
                this.handlerAdd(postData);
            }
        },

        handlerAdd: function (postData) {
            var _this = this;
            utils.getPOST("/parkworker/addWorker", postData, function (res) {
                utils.showTip("添加成功");
                setTimeout(function () {
                    _this.refreshData();
                }, 1000);

            })
        },

        handlerEdit: function (postData) {
            var _this = this;
            postData["id"] = id;
            utils.getPUT("/user", postData, function (res) {
                utils.showTip("修改成功");

                setTimeout(function () {
                    _this.refreshData();
                }, 1000);

            })
        },

        initData: function () {
            var _this = this;
            if (id) {
                $(".sure-btn").text("修改");
                $(".p-line").hide();
                utils.getJSON("/user/" + id, {}, function (res) {
                    _this.dealData(res);
                })
            }
        },

        dealData: function (res) {
            $(".name").val(res.name);
            $(".user-name").val(res.username);

        },

        refreshData: function () {
            closeTab(frameElement);
        },

        initParkInfo: function () {
            utils.getJSON("/parkworker/findAllParkInfo", null, function (res) {
                $.each(res, function (i, val) {
                    $("#parkInfo").append("<option value="+val.id+">"+val.parkName+"</option>");
                });
            });
        }

    });

    var home = new Home();

});

seajs.use('./addParkPlay.js');

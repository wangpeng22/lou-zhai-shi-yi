define(function (require, exports, module) {

    var parkPalyTable;

    var Home = Backbone.View.extend({

        el: document.getElementsByTagName('body')[0],

        events: {
            "click .del-btn": "handlerDelete",
            "click .add-btn": "handlerAdd",
            "click .refresh-btn": "handlerRefresh"
        },
        template: _.template($('#buttonTemplate').html()),

        initialize: function () {
            this.model = new Backbone.Model();
            this.model.set("resourceData", resourceData);
            this.render();
            this.hideView();
            this.initData();
        },

        render: function () {
            $("#toolBox").empty().append(this.template(this.model.toJSON()));
        },

        initData: function () {
            parkPalyTable = $('#table').DataTable({
                "ajax": {
                    url: baseUrl + "/parkworker/findAllWorker",
                    "data": function (d) {
                        d.workerType = 1;
                        return JSON.stringify(d);
                    }
                },
                "columns": [
                    {"data": "parkName"},
                    {"data": "username"},
                    {"data": "password"},
                    {
                        render: function (data, type, row, meta) {
                            var str = "";

                            if ($.inArray("/parkworker/addWorker-post", resourceData) > -1) {
                                str += "<button data-id='" + row.id + "' class='btn btn-danger del-btn btn-xs'><i class='fa fa-trash-o' aria-hidden='true'></i> 删除</button>"
                            }
                            return str;
                        }
                    }
                ]
            });
        },
        handlerDelete: function (event) {
            var target = $(event.currentTarget);
            resourceId = target.data("id");
            $(".alert-view .alert-txt", parent.document).text("确定要删除吗？");
            $(".alert-view", parent.document).show();

        },
        hideView: function () {
            var _this = this;

            $(".alert-view .s-btn", parent.document).click(function () {
                $(".alert-view", parent.document).hide();
                _this.handlerSureDel();
            })
        },
        handlerSureDel: function () {
            var _this = this;
            utils.getJSON("/parkworker/deleteWorker/" + resourceId, {}, function (res) {
                utils.showTip("删除成功");
                setTimeout(function () {
                    parkPalyTable.ajax.reload(null, false);
                }, 1000);
            })
        },

        handlerAdd: function (event) {
            var id = $(".item-ul li.active", parent.document).data("id");
            addTab(event, true, id);
        },
        handlerRefresh: function () {
            parkPalyTable.ajax.reload(null, false);
        }


    });

    var home = new Home();

});

seajs.use('./parkPlayList.js');

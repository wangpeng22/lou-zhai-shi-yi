define(function (require, exports, module) {
    var staffTable;
    var Home = Backbone.View.extend({

        el: document.getElementsByTagName('body')[0],

        events: {
            "click .edit-btn": "handlerEdit",
            "click .refresh-btn": "handlerRefresh",
            "click .export-btn": "handlerExport",
            "click .search-btn": "handlerSearch",
            "change .staffImport": "handlerImport"
        },
        template: _.template($('#buttonTemplate').html()),
        initialize: function () {
            this.model = new Backbone.Model();
            this.model.set("resourceData", resourceData);
            this.render();
            this.initData();
            this.hideView();
        },
        render: function () {
            $("#toolBox").empty().append(this.template(this.model.toJSON()));
        },
        initData: function () {
            staffTable = $('#table').DataTable({
                "ajax": {
                    url: baseUrl + "/staff/listStaffInfo",
                    "data": function (temp) {
                        temp.staffName = $("#staffName").val();
                        temp.deptName = $("#deptName").val();
                        return JSON.stringify(temp);
                    }
                },
                "columns": [
                    {"data": "deptName"},
                    {"data": "staffName"},
                    {"data": "staffAddress"},
                    {"data": "staffRegistTime"},
                    {"data": "staffTripMode"},
                    {"data": "staffRecevieState"},
                    {"data": "staffPlayState"},
                    {"data": "staffPrizeState"},
                    {"data": "staffPlaceInfo"},
                    {"data": "staffSignState"},
                    {"data": "staffEnterState"},
                    {
                        render: function (data, type, row, meta) {
                            var str = "";
                            if ($.inArray("/staff-post", resourceData) > -1) {
                                str += "<button  data-text='修改信息'  data-id='editStaff' data-link='../staffEdit/staffEdit.html?id=" + row.staffId + "&deptId=" + row.deptId + "&staffAddress=" + row.staffAddress +"&staffPlaceInfo="+row.staffPlaceInfo+"' class='btn btn-primary edit-btn btn-xs margin-right-5'><i class='fa fa-pencil' aria-hidden='true'></i> 修改员工信息</button>"
                            }
                            return str;
                        }


                    }
                ]
            });
        },
        handlerEdit: function(event){
            addTab(event, true);
        },
        hideView: function () {
            var _this = this;

            $(".alert-view .s-btn", parent.document).click(function () {
                $(".alert-view", parent.document).hide();
                _this.handlerSureDel();
            })
        },
        handlerRefresh: function () {
            staffTable.ajax.reload(null, false);
        },
        handlerExport: function () {
            window.location.href=(baseUrl+"/staff/staffExport?staffName="+$("#staffName").val()+"&deptName="+$("#deptName").val());
        },
        handlerSearch:function () {
            staffTable.ajax.reload(null, false);
        },
        handlerImport:function () {
            var formData = new FormData();
            formData.append("file", document.getElementById("j_uploaderCustomInput").files[0]);
            $.ajax({
                type: "POST",
                url:baseUrl+"/staff/staffImport",
                data: formData,
                async: false,
                processData: false,
                contentType: false,
                beforeSend: function (request) {
                    console.log(request)
                    request.setRequestHeader("Authorization", token);
                },
                success: function(data){
                    utils.showTip(data.message);
                    if (data.code == 200) {
                        staffTable.ajax.reload(null, false);
                    }
                }
            });
        }
    });

    var home = new Home();

});

seajs.use('./staffList.js');

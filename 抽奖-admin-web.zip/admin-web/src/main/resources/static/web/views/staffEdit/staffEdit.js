define(function (require, exports, module) {

    //员工ID
    var id = utils.getQuery("id");
    //员工所属部门
    var deptId = utils.getQuery("deptId");
    //员工所在地
    var staffAddress = utils.getQuery("staffAddress");
    //员工座位信息
    var staffPlaceInfo = utils.getQuery("staffPlaceInfo");

    var Home = Backbone.View.extend({

        el: document.getElementsByTagName('body')[0],

        events: {
            "click .sure-btn": "handlerSure"
        },

        initialize: function () {
            this.model = new Backbone.Model();
            this.initData();

        },

        handlerSure: function () {
            var deptId = $(".deptId").val();
            var address = $(".staffAddress").val();
            var placeInfo = $(".placeInfo").val();
            var postData = {
                "deptId": deptId,
                "staffAddress": address,
                "staffPlaceInfo": placeInfo

            }
            if (address == "") {
                utils.showTip("请输入所在地");
                return;
            }
            if (placeInfo == "") {
                utils.showTip("请输入座位信息");
                return;
            }
            if (id) {
                this.handlerEdit(postData);
            } else {
                utils.showTip("修改对象ID识别失败");
                return;
            }
        },

        handlerEdit: function (postData) {
            var _this = this;
            postData["staffId"] = id;
            utils.getPOST("/staff/editStaffInfo", postData, function (res) {
                utils.showTip("修改成功");
                setTimeout(function () {
                    _this.refreshData();
                }, 1000);

            })
        },
        initData: function () {
            $("select option[value='"+deptId+"']").attr("selected","selected");
            //$(".deptId").get(0).selectedIndex=deptId;
            $(".staffAddress").val(staffAddress);
            $(".placeInfo").val(staffPlaceInfo);

        },
        refreshData: function () {
            closeTab(frameElement);
        }

    });

    var home = new Home();

});

seajs.use('./staffEdit.js');

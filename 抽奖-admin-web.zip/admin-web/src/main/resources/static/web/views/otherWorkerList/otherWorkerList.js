define(function (require, exports, module) {

    var propTable;

    var code;

    var userId;

    var Home = Backbone.View.extend({

        el: document.getElementsByTagName('body')[0],

        events: {
            "click .del-btn": "handlerDelete",
            "click .add-btn": "handlerAdd",
            "click .refresh-btn": "handlerRefresh"
        },
        template: _.template($('#buttonTemplate').html()),

        initialize: function () {
            this.model = new Backbone.Model();
            this.model.set("resourceData", resourceData);
            this.render();
            this.initData();
            this.hideView();
        },

        render: function () {
            $("#toolBox").empty().append(this.template(this.model.toJSON()));
        },

        initData: function () {
            propTable = $('#table').DataTable({
                "ajax": {
                    url: baseUrl + "/parkworker/findAllWorker",
                    "data": function (d) {
                        d.workerType = 0;
                        return JSON.stringify(d);
                    },
                    "dataSrc": function (res) {
                        var data = res.data;
                        $.each(data, function (i, val) {
                            if (val.workerType === 1) {
                                val.workerType = "游玩点";
                            } else if (val.workerType === 2) {
                                val.workerType = "兑奖处";
                            } else if (val.workerType === 3) {
                                val.workerType = "签到处";
                            } else if (val.workerType === 4) {
                                val.workerType = "道具领取";
                            } else if (val.workerType === 5) {
                                val.workerType = "入园处";
                            }
                        });
                        return data;
                    }
                },
                "columns": [
                    {"data": "workerType"},
                    {"data": "username"},
                    {"data": "password"},
                    {
                        render: function (data, type, row, meta) {

                            var str = "";

                            if ($.inArray("/parkworker/addWorker-post", resourceData) > -1) {
                                str += "<button data-id='" + row.id + "' class='btn btn-danger del-btn btn-xs'><i class='fa fa-trash-o' aria-hidden='true'></i> 删除</button>"
                            }
                            return str;
                        }
                    }
                ]
            });
        },

        handlerDelete: function (event) {
            var target = $(event.currentTarget);
            resourceId = target.data("id");
            $(".alert-view .alert-txt", parent.document).text("确定要删除吗？");
            $(".alert-view", parent.document).show();

        },

        hideView: function () {
            var _this = this;

            $(".alert-view .s-btn", parent.document).click(function () {
                $(".alert-view", parent.document).hide();
                _this.handlerSureDel();
            })
        },

        handlerSureDel: function () {
            var _this = this;
            utils.getJSON("/parkworker/deleteWorker/" + resourceId, {}, function (res) {
                utils.showTip("删除成功");
                setTimeout(function () {
                    propTable.ajax.reload(null, false);
                }, 1000);
            })
        },

        handlerAdd: function (event) {
            var id = $(".item-ul li.active", parent.document).data("id");
            addTab(event, true, id);
        },

        handlerRefresh: function () {
            propTable.ajax.reload(null, false);
        }

    });

    var home = new Home();

});

seajs.use('./otherWorkerList.js');

define(function (require, exports, module) {
    var activityOtherLotteryDogTable;
    var Home = Backbone.View.extend({

        el: document.getElementsByTagName('body')[0],

        events: {
            "click .search-btn": "handlerSearch"
        },

        initialize: function () {
            this.model = new Backbone.Model();
            this.model.set("resourceData", resourceData);
            this.initData();
        },

        initData: function () {
            activityOtherLotteryDogTable = $('#activityOtherLotteryDogTable').DataTable({
                // 不显示分页相关
                "paging" : false,
                "ordering" : false,
                "info" : true,
                // 不显示分页相关.
                "ajax" : {
                    url: baseUrl + "/console/activity/otherlotterydogs",
                    "data": function (temp) {
                        temp.activityName = $("#activityName").val();
                        temp.departmentName = $("#userDepartmentName").val();
                        temp.userName = $("#userName").val();
                        temp.prizeName = $("#prizeName").val();
                        return JSON.stringify(temp);
                    }
                },
                "columns" : [{
                    "data": "id", // 记录Id
                    "targets": [ 0 ],
                    "visible": false,
                    "searchable": false
                },{
                    "data": "activityName" // 活动名称
                },{
                    "data": "prizeName" // 奖品名称
                },{
                    "data": "userName" //中奖人姓名
                },{
                    "data": "userDepartmentName" // 中奖人部门
                },{
                    "data": "receiveFlag", // 领取标志
                    "targets": [ 5 ],
                    "visible": false,
                    "searchable": false
                },{
                    "render" : function(data, type,row) {
                        var html = "";
                        if (1 == row.receiveFlag) {
                            html  += "<a data-text='未发' class='btn btn-primary btn-xs margin-right-5 cancel-prize' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>未发</a>";
                        }
                        if (2 == row.receiveFlag) {
                            html  += "<a data-text='已发' class='btn btn-primary btn-xs margin-right-5 receive-prize' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>已发</a>";
                        }
                        return html;
                    }
                }]
            });
        },

        handlerSearch:function () {
            activityOtherLotteryDogTable.ajax.reload(null, false);
        }
    });

    var home = new Home();

    $('#activityOtherLotteryDogTable tbody').on( 'click', 'a.cancel-prize', function () {
        var data = activityOtherLotteryDogTable.row($(this).parents('tr')).data();
        $.ajax({
            url: baseUrl + "/console/activity/receiveprize",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({activityLuckyDogId:data.id}),
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("已发");
                    activityOtherLotteryDogTable.ajax.reload(null, false);
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    $('#activityOtherLotteryDogTable tbody').on( 'click', 'a.receive-prize', function () {
        var data = activityOtherLotteryDogTable.row($(this).parents('tr')).data();
        $.ajax({
            url: baseUrl + "/console/activity/cancelprize",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({activityLuckyDogId:data.id}),
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("未发");
                    activityOtherLotteryDogTable.ajax.reload(null, false);
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

});

seajs.use('./activtitylotterydoglist2.js');
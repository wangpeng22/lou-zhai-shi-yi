define(function (require, exports, module) {
    var activityVoteTable;
    var Home = Backbone.View.extend({

        el: document.getElementsByTagName('body')[0],

        events: {
            "click .refresh-btn": "refreshHandler"
        },

        initialize: function () {
            this.model = new Backbone.Model();
            this.model.set("resourceData", resourceData);
            this.initData();
        },
        initData: function () {
            activityVoteTable = $('#activityVoteTable').DataTable({
                // 不显示分页相关
                "paging" : false,
                "ordering" : false,
                "info" : true,
                // 不显示分页相关.
                "ajax" : {
                    url: baseUrl + "/console/activity/listvote"
                },
                "columns" : [{
                    "data": "activityId", // 活动Id
                    "targets": [ 0 ],
                    "visible": false,
                    "searchable": false
                },{
                    "data": "status", // 活动状态
                    "targets": [ 1 ],
                    "visible": false,
                    "searchable": false
                },{
                    "data": "activityName" //活动名称
                },{
                    "data": "activityPrizeId", // 奖项Id
                    "targets": [ 3 ],
                    "visible": false,
                    "searchable": false
                },{
                    "data": "voteId1", // 战队1Id
                    "targets": [ 4 ],
                    "visible": false,
                    "searchable": false
                },{
                    "data": "voteName1" //战队1名称
                },{
                    "data": "voteNumber1" // 战队1得票数
                },{
                    "data": "voteId2", // 战队2Id
                    "targets": [ 7 ],
                    "visible": false,
                    "searchable": false
                },{
                    "data": "voteName2"
                },{
                    "data": "voteNumber2"
                },{
                    "render" : function(data, type,row) {
                        var html = "<a data-text='节目开始' class='btn btn-primary btn-xs margin-right-5 wait-voting' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>节目开始</a>";
                        // html += "<a data-text='开始投票' class='btn btn-primary btn-xs margin-right-5 begin-voting' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>开始投票</a>";
                        html += "<a data-text='结束投票' class='btn btn-primary btn-xs margin-right-5 end-voting' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>结束投票</a>";
                        html += "<a data-text='投票展示' class='btn btn-primary btn-xs margin-right-5 display-voting' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>投票展示</a>";
                        html += "<br/>";
                        html += "<br/>";
                        html += "<a data-text='在" + row.voteName1 +
                            "中抽取幸运观众' class='btn btn-primary edit-btn btn-xs margin-right-5 vote-lottery-1' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>在" + row.voteName1 +
                            "中抽取幸运观众</a>";
                        html += "<br/>";
                        html += "<br/>";
                        html += "<a data-text='在" + row.voteName2 +
                            "中抽取幸运观众' class='btn btn-primary edit-btn btn-xs margin-right-5 vote-lottery-2' href='#'><i class='fa fa-pencil' aria-hidden='true'></i>在" + row.voteName2 +
                            "中抽取幸运观众</a>";

                        return html;
                    }
                }]
            });
        },
        refreshHandler : function () {
            activityVoteTable.ajax.reload(null, false);
        }
    });

    var home = new Home();

    // $(function(){
    //     setInterval(function(){
    //         activityVoteTable.ajax.reload(null, false);
    //     }, 10000);
    // });

    // 节目开始
    $('#activityVoteTable tbody').on( 'click', 'a.wait-voting', function () {
        var data = activityVoteTable.row($(this).parents('tr')).data();
        var activityId = data.activityId;
        $.ajax({
            url: baseUrl + "/console/activity/waitvoting",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({activityId:activityId}),
            success: function(data){
                if (200 == data.code) {
                    // utils.showTip("节目开始");
                    // 节目开始之后就可以投票 即再调用
                    $.ajax({
                        url: baseUrl + "/console/activity/beginvoting",
                        type: 'POST',
                        dataType: 'json',
                        contentType: "application/json; charset=utf-8",
                        data: JSON.stringify({activityId:activityId}),
                        success: function(data){
                            if (200 == data.code) {
                                // utils.showTip("投票开始");
                                utils.showTip("节目开始，可以投票");
                            } else {
                                utils.showTip(data.message);
                            }
                        }
                    });
                    
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    // 开始投票
    $('#activityVoteTable tbody').on( 'click', 'a.begin-voting', function () {
        var data = activityVoteTable.row($(this).parents('tr')).data();
        $.ajax({
            url: baseUrl + "/console/activity/beginvoting",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({activityId:data.activityId}),
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("投票开始");
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    // 结束投票
    $('#activityVoteTable tbody').on( 'click', 'a.end-voting', function () {
        var data = activityVoteTable.row($(this).parents('tr')).data();
        $.ajax({
            url: baseUrl + "/console/activity/endvoting",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify({activityId:data.activityId}),
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("投票结束");
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    // TODO. 投票展示(即跳转到实时投票展示页面)
    $('#activityVoteTable tbody').on( 'click', 'a.display-voting', function () {
        var data = activityVoteTable.row($(this).parents('tr')).data();
        var url = "../vote/vote.html?activityId={activityId}&activityPrizeId={activityPrizeId}&activityName={activityName}"
            .replace("{activityId}", data.activityId)
            .replace("{activityPrizeId}", data.activityPrizeId)
            .replace("{activityName}", data.activityName);
        window.open(url, "_blank");
    });

    // 在战队1中抽取幸运观众, 即设置战队1为获胜队伍
    $('#activityVoteTable tbody').on( 'click', 'a.vote-lottery-1', function () {
        var data = activityVoteTable.row($(this).parents('tr')).data();
        $.ajax({
            url: baseUrl + "/console/activity/setwin",
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data :JSON.stringify({
                activityId : data.activityId,
                activityPrizeId : data.activityPrizeId,
                voteId : data.voteId1
            }),
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("设置成功");
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });

    // 在战队2中抽取幸运观众
    $('#activityVoteTable tbody').on( 'click', 'a.vote-lottery-2', function () {
        var data = activityVoteTable.row($(this).parents('tr')).data();
        $.ajax({
            type: "POST",
            url: baseUrl + "/console/activity/setwin",
            datType: "JSON",
            contentType: "application/json;charset=UTF-8",
            data :JSON.stringify({
                activityId : data.activityId,
                activityPrizeId : data.activityPrizeId,
                voteId : data.voteId2
            }),
            success: function(data){
                if (200 == data.code) {
                    utils.showTip("设置成功");
                } else {
                    utils.showTip(data.message);
                }
            }
        });
    });
});

seajs.use('./activityvotelist.js');
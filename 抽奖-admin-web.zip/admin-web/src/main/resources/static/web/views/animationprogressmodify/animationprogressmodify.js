define(function (require, exports, module) {
    var id = utils.getQuery("id");
    var Home = Backbone.View.extend({
        el: document.getElementsByTagName('body')[0],
        events: {
            "click .modify-progress-save": "modifyProgressSaveHandler"
        },
        initialize: function () {
            this.model = new Backbone.Model();
            this.initData();
        },
        initData: function () {
            $.ajax({
                url: baseUrl + "/console/activity/getprogress",
                type: 'POST',
                dataType: 'json',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({
                    id : id
                }),
                success: function(data){
                    if (200 == data.code) {
                        $(".s").val(data.data.s / 1000);

                        $(".h").val(Math.floor(data.data.t / 3600));
                        $(".m").val(Math.floor(data.data.t / 60 % 60));
                        $(".ss").val(Math.floor(data.data.t % 60));
                    }
                }
            });
        },
        modifyProgressSaveHandler : function () {

            var patrn = /^[0-9]*$/;

            if (patrn.exec($(".s").val()) == null || $(".s").val() == "") {
                utils.showTip("进度间隔：0-100的数字");
                return;
            }
            if ($(".s").val() < 0) {
                utils.showTip("进度间隔：0-100的数字");
                return;
            }
            if ($(".s").val() > 100) {
                utils.showTip("进度间隔：0-100的数字");
                return;
            }

            var s = $(".s").val() * 1000;

            var h = $(".h").val();
            if ("" == h || " " == h) {
                h = 0;
            }
            if (patrn.exec(h) == null || h == "") {
                utils.showTip("时：0-9的数字");
                return;
            }
            if (h < 0) {
                utils.showTip("时：0-9的数字");
                return;
            }
            if (h > 9) {
                utils.showTip("时：0-9的数字");
                return;
            }
            var m = $(".m").val();
            if ("" == m || " " == m) {
                m = 0;
            }
            if (patrn.exec(m) == null || m == "") {
                utils.showTip("分：0-59的数字");
                return;
            }
            if (m < 0) {
                utils.showTip("分：0-59的数字");
                return;
            }
            if (m > 59) {
                utils.showTip("分：0-59的数字");
                return;
            }
            var ss = $(".ss").val();
            if ("" == ss) {
                ss = 0;
            }
            if (patrn.exec(ss) == null || ss == "") {
                utils.showTip("秒：0-59的数字");
                return;
            }
            if (ss < 0) {
                utils.showTip("秒：0-59的数字");
                return;
            }
            if (ss > 59) {
                utils.showTip("秒：0-59的数字");
                return;
            }
            var t = parseInt(h) * 60 * 60 + parseInt(m) * 60 + parseInt(ss);

            $.ajax({
                url: baseUrl + "/console/activity/modifyprogress",
                type: 'POST',
                dataType: 'json',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({
                    id : id,
                    s : s,
                    t : t
                }),
                success: function(data){
                    if (200 == data.code) {
                        utils.showTip("保存成功");
                    } else {
                        utils.showTip(data.message);
                    }
                }
            });
        }
    });
    var home = new Home();
});

seajs.use('./animationprogressmodify.js');
package com.bilibili.admin.dto;

/**
 * Created by wangpeng on 2019/1/2 14:32
 */
public class ActivityExtTimeIntervalSearchDTO extends SearchDTO{

    private Integer activityId;

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }
}

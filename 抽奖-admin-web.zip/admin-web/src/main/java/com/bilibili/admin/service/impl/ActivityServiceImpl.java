package com.bilibili.admin.service.impl;


import com.bilibili.admin.core.ResultCode;
import com.bilibili.admin.dto.*;
import com.bilibili.admin.exception.BusinessException;
import com.bilibili.admin.mapper.*;
import com.bilibili.admin.model.*;
import com.bilibili.admin.service.ActivityService;
import com.bilibili.admin.util.AssertUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Created by wangpeng on 2018/12/19 17:51
 */
@Service
public class ActivityServiceImpl implements ActivityService {

    // 计算进度
    // private static ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);

    // 进度开关控制 on:true 开 on:false 关
    private volatile static boolean  on = true;

    // 标记是否执行过抽取666个中奖人
    private static volatile boolean decibelLotteryFlag = false;
    // 标记是否正在执行抽取666个中奖人
    private static volatile boolean decibelLotteryRunFlag = false;
    // 标记返回666个中奖人
    private static volatile boolean lotteryDog666 = false;
    // 标记返回333个中奖人
    private static volatile boolean lotteryDog333 = false;
    // 标记补充返回333个中奖人
    private static volatile boolean lotteryDog333_ = false;


    @Autowired
    private ActivityBaseInfoMapper activityBaseInfoMapper;

    @Autowired
    private ActivityPrizeInfoMapper activityPrizeInfoMapper;

    @Autowired
    private PrizeInfoMapper prizeInfoMapper;

    @Autowired
    private ActivityVoteInfoMapper activityVoteInfoMapper;

    @Autowired
    private ActivityUserVoteMapper activityUserVoteMapper;

    @Autowired
    private ActivityUserVoteCustomizedMapper activityUserVoteCustomizedMapper;

    @Autowired
    private ActivityLuckyDogInfoMapper activityLuckyDogInfoMapper;

    @Autowired
    private StaffInfoCustomizedMapper staffInfoCustomizedMapper;

    @Autowired
    private ActivityDepartmentWinningWeightMapper activityDepartmentWinningWeightMapper;

    @Autowired
    private ActivityLuckyDogInfoCustomizedMapper activityLuckyDogInfoCustomizedMapper;

    @Autowired
    private ActivityExtTimerMapper activityExtTimerMapper;

    @Autowired
    private ActivityExtTimeIntervalMapper activityExtTimeIntervalMapper;

    @Autowired
    private ActivityPrizeInfoExtMapper activityPrizeInfoExtMapper;

    @Autowired
    private ActivityPrizeInfoCustomizedMapper activityPrizeInfoCustomizedMapper;

    /**
     * 活动列表
     *
     * @param activitySearchDTO
     *
     * @return
     */
    @Override
    public List<ActivityDTO> list(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityType(), "缺少activityType参数");

        // 查询活动
        ActivityBaseInfoExample activityBaseInfoExample = new ActivityBaseInfoExample();
        activityBaseInfoExample.createCriteria()
                .andStatusNotEqualTo(4)
                .andActivityTypeEqualTo(activitySearchDTO.getActivityType());
        List<ActivityBaseInfo> activityBaseInfoList = activityBaseInfoMapper.selectByExample(activityBaseInfoExample);

        if (null == activityBaseInfoList || 0 >= activityBaseInfoList.size()) {
            return null;
        }
        List<Integer> activityIdList = new ArrayList<>();
        Map<Integer, ActivityDTO> activityDTOMap = new HashMap<>();
        for (ActivityBaseInfo activityBaseInfo : activityBaseInfoList) {
            if (null == activityDTOMap.get(activityBaseInfo.getId())) {
                ActivityDTO activityDTO = ActivityDTO.transfer(activityBaseInfo);
                activityDTOMap.put(activityBaseInfo.getId(), activityDTO);
            }
            activityIdList.add(activityBaseInfo.getId());
        }

        // 查询奖项
        ActivityPrizeInfoExample activityPrizeInfoExample = new ActivityPrizeInfoExample();
        activityPrizeInfoExample
                .createCriteria()
                .andActivityIdIn(activityIdList);
        List<ActivityPrizeInfo> activityPrizeInfoList = activityPrizeInfoMapper.selectByExample(activityPrizeInfoExample);

        List<Integer> prizeIdList = new ArrayList<>();
        Map<Integer, ActivityPrizeDTO> activityPrizeDTOMap = new HashMap<>();

        if (null != activityPrizeInfoList && 0 < activityPrizeInfoList.size()) {
            for (ActivityPrizeInfo activityPrizeInfo : activityPrizeInfoList) {
                if (null == activityPrizeDTOMap.get(activityPrizeInfo.getId())) {
                    ActivityPrizeDTO activityPrizeDTO = ActivityPrizeDTO.transfer(activityPrizeInfo);
                    activityPrizeDTOMap.put(activityPrizeInfo.getId(), activityPrizeDTO);
                }
                prizeIdList.add(activityPrizeInfo.getPrizeId());
            }
        }

        // 查询奖品
        Map<Integer, PrizeInfo> prizeInfoMap = new HashMap<>();
        if (null != prizeIdList && 0 < prizeIdList.size()) {
            PrizeInfoExample prizeInfoExample = new PrizeInfoExample();
            prizeInfoExample.createCriteria().andIdIn(prizeIdList);
            List<PrizeInfo> prizeInfoList = prizeInfoMapper.selectByExample(prizeInfoExample);
            if (null != prizeInfoList && 0 < prizeInfoList.size()) {
                for (PrizeInfo prizeInfo : prizeInfoList) {
                    prizeInfoMap.put(prizeInfo.getId(), prizeInfo);
                }
            }
        }

        if (null != activityPrizeInfoList
                && 0 < activityPrizeInfoList.size()) {
            for (ActivityPrizeInfo activityPrizeInfo : activityPrizeInfoList) {

                ActivityPrizeDTO activityPrizeDTO = null;
                if (null != activityPrizeDTOMap
                        && 0 < activityPrizeDTOMap.size()) {
                    activityPrizeDTO = activityPrizeDTOMap.get(activityPrizeInfo.getId());
                }

                if (null != activityPrizeDTO
                        && null != prizeInfoMap
                        && null != prizeInfoMap.get(activityPrizeDTO.getPrizeId())) {
                    if (null == activityPrizeDTO.getPrizeInfoList() || 0 >= activityPrizeDTO.getPrizeInfoList().size()) {
                        List<PrizeInfo> prizeInfoList = new ArrayList<>();
                        prizeInfoList.add(prizeInfoMap.get(activityPrizeDTO.getPrizeId()));
                        activityPrizeDTO.setPrizeInfoList(prizeInfoList);
                    } else {
                        activityPrizeDTO.getPrizeInfoList().add(prizeInfoMap.get(activityPrizeDTO.getPrizeId()));
                    }
                }

                if (null != activityPrizeDTO
                        && null != activityDTOMap
                        && null != activityDTOMap.get(activityPrizeDTO.getActivityId())) {
                    if (null == activityDTOMap.get(activityPrizeDTO.getActivityId()).getActivityPrizeDTOList() || 0 >= activityDTOMap.get(activityPrizeDTO.getActivityId()).getActivityPrizeDTOList().size()) {
                        List<ActivityPrizeDTO> activityPrizeDTOList = new ArrayList<>();
                        activityPrizeDTOList.add(activityPrizeDTO);
                        activityDTOMap.get(activityPrizeDTO.getActivityId()).setActivityPrizeDTOList(activityPrizeDTOList);
                    } else {
                        activityDTOMap.get(activityPrizeDTO.getActivityId()).getActivityPrizeDTOList().add(activityPrizeDTO);
                    }
                }
            }

        }

        // 查询战队
        ActivityVoteInfoExample activityVoteInfoExample = new ActivityVoteInfoExample();
        activityVoteInfoExample.createCriteria().andActivityIdIn(activityIdList);
        List<ActivityVoteInfo> activityVoteInfoList = activityVoteInfoMapper.selectByExample(activityVoteInfoExample);
        if (null != activityVoteInfoList && 0 < activityVoteInfoList.size()) {
            for (ActivityVoteInfo activityVoteInfo : activityVoteInfoList) {

                // 战队得票统计
                ActivityUserVoteExample activityUserVoteExample = new ActivityUserVoteExample();
                activityUserVoteExample
                        .createCriteria()
                        .andActivityIdEqualTo(activityVoteInfo.getActivityId())
                        .andVoteIdEqualTo(activityVoteInfo.getId());
                activityVoteInfo.setVoteNumber(activityUserVoteMapper.countByExample(activityUserVoteExample));

                ActivityDTO activityDTO = activityDTOMap.get(activityVoteInfo.getActivityId());
                if (null != activityDTO) {
                    if (null == activityDTO.getActivityVoteInfoList() || 0 >= activityDTO.getActivityVoteInfoList().size()) {
                        List<ActivityVoteInfo> activityVoteInfoList1 = new ArrayList<>();
                        activityVoteInfoList1.add(activityVoteInfo);
                        activityDTO.setActivityVoteInfoList(activityVoteInfoList1);
                    } else {
                        activityDTO.getActivityVoteInfoList().add(activityVoteInfo);
                    }
                }
            }
        }
        return new ArrayList<>(activityDTOMap.values());
    }

    /**
     * 修改状态
     *
     * @param activityId
     * @param status
     */
    @Override
    public void modifyStatus(Integer activityId, int status) {
        ActivityBaseInfo activityBaseInfo = new ActivityBaseInfo();
        activityBaseInfo.setId(activityId);
        activityBaseInfo.setStatus(status);
        activityBaseInfoMapper.updateByPrimaryKeySelective(activityBaseInfo);
    }

    /**
     * 投票
     *
     * @param activityUserVoteDTO
     */
    @Override
    public void voting(ActivityUserVoteDTO activityUserVoteDTO) {
        AssertUtil.isNull(activityUserVoteDTO, "缺少参数");
        AssertUtil.isNull(activityUserVoteDTO.getActivityId(), "缺少activityId参数");
        AssertUtil.isNull(activityUserVoteDTO.getVoteId(), "缺少voteId参数");
        AssertUtil.isNull(activityUserVoteDTO.getUserId(), "缺少userId参数");
        ActivityBaseInfo activityBaseInfo = activityBaseInfoMapper.selectByPrimaryKey(activityUserVoteDTO.getActivityId());
        if (null == activityBaseInfo) {
            throw new BusinessException(ResultCode.ACTIVITY_NOT_EXIST.getCode(), ResultCode.ACTIVITY_NOT_EXIST.getMsg());
        }
        switch (activityBaseInfo.getStatus()) {
            case 1:
            case 4:
            case 5:
                throw new BusinessException(ResultCode.ACTIVITY_NOT_EXIST.getCode(), ResultCode.ACTIVITY_NOT_EXIST.getMsg());
            case 6:
                throw new BusinessException(ResultCode.ACTIVITY_NOT_BEGIN.getCode(), "投票还没开始");
            case 7:
                ActivityUserVote activityUserVote = new ActivityUserVote();
                activityUserVote.setActivityId(activityUserVoteDTO.getActivityId());
                activityUserVote.setUserId(activityUserVoteDTO.getUserId());
                activityUserVote.setVoteId(activityUserVoteDTO.getVoteId());
                try {
                    activityUserVoteMapper.insertSelective(activityUserVote);
                }
                catch (Exception e){
                    if (e instanceof DuplicateKeyException) {
                        throw new BusinessException(ResultCode.ACTIVITY_VOTED.getCode(), "已经投过票");
                    } else {
                        e.printStackTrace();
                    }
                }
                break;
            case 8:
                throw new BusinessException(ResultCode.ACTIVITY_END.getCode(), "投票已经结束");
        }
    }

    /**
     * 展示投票结果
     *
     * @param activitySearchDTO
     * @param dp true:更新得票数记录，false:不更新得票数记录
     *
     * @return
     */
    @Override
    public ActivityVoteResultDTO displayVoting(ActivitySearchDTO activitySearchDTO, boolean dp) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");

        ActivityVoteInfoExample activityVoteInfoExample = new ActivityVoteInfoExample();
        activityVoteInfoExample.createCriteria().andActivityIdEqualTo(activitySearchDTO.getActivityId());
        List<ActivityVoteInfo> activityVoteInfoList = activityVoteInfoMapper.selectByExample(activityVoteInfoExample);
        if (null == activityVoteInfoList || 0 >= activityVoteInfoList.size()) {
            return null;
        }
        Map<Integer, ActivityVoteInfo> activityVoteInfoMap = new HashMap<>();
        for (ActivityVoteInfo activityVoteInfo : activityVoteInfoList) {
            activityVoteInfoMap.put(activityVoteInfo.getId(), activityVoteInfo);
        }
        // 统计投票数量
        List<ActivityVoteStatistics> statisticsList = activityUserVoteCustomizedMapper.statistics(activitySearchDTO.getActivityId());

        ActivityVoteResultDTO activityVoteResultDTO = new ActivityVoteResultDTO();

        if (null == statisticsList || 0 >= statisticsList.size()) {
            activityVoteResultDTO.setActivityVoteInfoList(activityVoteInfoList);
            return activityVoteResultDTO;
        }

        for (ActivityVoteStatistics statistics : statisticsList) {
            if (null != activityVoteInfoMap.get(statistics.getVoteId())) {
                activityVoteInfoMap.get(statistics.getVoteId()).setVoteNumber(statistics.getVoteNumber());
                // 更新得票数
                if (dp) {
                    activityVoteInfoMapper.updateByPrimaryKey(activityVoteInfoMap.get(statistics.getVoteId()));
                }
            }
        }

        activityVoteResultDTO.setActivityVoteInfoList(new ArrayList<>(activityVoteInfoMap.values()));
        return activityVoteResultDTO;
    }

    /**
     * 抽取投票活动的幸运儿
     *
     * @param activitySearchDTO
     *
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void voteLottery(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        AssertUtil.isNull(activitySearchDTO.getActivityPrizeId(), "缺少activityPrizeId参数");
        AssertUtil.isNull(activitySearchDTO.getVoteId(), "缺少voteId参数");

        ActivityPrizeInfo activityPrizeInfo = activityPrizeInfoMapper.selectByPrimaryKey(activitySearchDTO.getActivityPrizeId());
        if (null == activityPrizeInfo) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "奖项不存在");
        }
        if (3 == activityPrizeInfo.getStatus() || 4 == activityPrizeInfo.getStatus()) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "已经开奖了");
        }
        // 1.修改奖项状态
        ActivityPrizeInfo  record = new ActivityPrizeInfo();
        record.setId(activitySearchDTO.getActivityPrizeId());
        record.setStatus(3);
        activityPrizeInfoMapper.updateByPrimaryKeySelective(record);

        // 查询需要抽取多少个幸运儿
        // ActivityPrizeInfo activityPrizeInfo = activityPrizeInfoMapper.selectByPrimaryKey(activitySearchDTO.getActivityPrizeId());
        if (null == activityPrizeInfo || 0 >= activityPrizeInfo.getActivityPrizeWinningNumber()) {
            return ;
        }
        int activityPrizeWinningNumber = activityPrizeInfo.getActivityPrizeWinningNumber();


        int count = activityUserVoteCustomizedMapper.countValidVoteUser(activitySearchDTO.getActivityId(), activitySearchDTO.getVoteId());
        if (0 >= count) {
            return ;
        }

        List<ActivityUserVote> activityUserVoteList = activityUserVoteCustomizedMapper.selectValidVoteUser(activitySearchDTO.getActivityId(), activitySearchDTO.getVoteId());

        List<Integer> winningUserIdList = new ArrayList<>();

        if (activityPrizeWinningNumber >= count) {
            // 中奖人数 >= 投票人数，即投票的人都中奖
            for (ActivityUserVote activityUserVote : activityUserVoteList) {
                winningUserIdList.add(activityUserVote.getUserId());
            }
            this.saveActivityLuckyDog(winningUserIdList,
                    null,
                    activitySearchDTO.getActivityId(),
                    activitySearchDTO.getActivityPrizeId());
            return;
        }

        // 中奖人数 < 投票人数, 即只有部分人中奖，抽取的策略是，在 [0, count) 产生不重复的 activityPrizeWinningNumber 个随机数
        int[] winningNumbers = new int[count];
        this.random(winningNumbers, activityPrizeWinningNumber, count, 0);
        for (int i = 0; i < count; i++) {
            if (1 == winningNumbers[i]) {
                winningUserIdList.add(activityUserVoteList.get(i).getUserId());
            }
        }

        this.saveActivityLuckyDog(winningUserIdList,
                null,
                activitySearchDTO.getActivityId(),
                activitySearchDTO.getActivityPrizeId());
    }

    private void random(int[] winningNumbers, int activityPrizeWinningNumber, int count, int base) {
        Random random = new Random();
        for (int i = 0; i < activityPrizeWinningNumber; i++) {
            int num = random.nextInt(count) + base;
            if (1 == winningNumbers[num]) {
                i--;
            } else {
                winningNumbers[num] = 1;
            }
        }
    }

    private void saveActivityLuckyDog (List<Integer> userIdList,
                                       List<StaffInfoCustomized> staffInfoCustomizedList,
                                       Integer activityId,
                                       Integer activityPrizeId) {

        ActivityBaseInfo activityBaseInfo = activityBaseInfoMapper.selectByPrimaryKey(activityId);
        if (null != userIdList) {
            staffInfoCustomizedList = staffInfoCustomizedMapper.selectByUserIdList(userIdList);
        }

        List<ActivityLuckyDogInfo> activityLuckyDogInfoList = new ArrayList<>();
        if (null != staffInfoCustomizedList && 0 < staffInfoCustomizedList.size()) {

            for (StaffInfoCustomized staffInfoCustomized : staffInfoCustomizedList) {
                ActivityLuckyDogInfo activityLuckyDogInfo = new ActivityLuckyDogInfo();

                activityLuckyDogInfo.setActivityId(activityId);
                activityLuckyDogInfo.setActivityName(activityBaseInfo.getActivityName());
                activityLuckyDogInfo.setActivityType(activityBaseInfo.getActivityType());
                activityLuckyDogInfo.setActivityPrizeId(activityPrizeId);

                activityLuckyDogInfo.setUserId(staffInfoCustomized.getStaffId());
                activityLuckyDogInfo.setUserName(staffInfoCustomized.getStaffName());
                activityLuckyDogInfo.setUserDepartmentId(staffInfoCustomized.getDeptId());
                activityLuckyDogInfo.setUserDepartmentName(staffInfoCustomized.getDeptName());

                activityLuckyDogInfo.setWinningTime(new Date());

                ActivityPrizeInfo activityPrizeInfo = activityPrizeInfoMapper.selectByPrimaryKey(activityPrizeId);
                PrizeInfo prizeInfo = prizeInfoMapper.selectByPrimaryKey(activityPrizeInfo.getPrizeId());
                activityLuckyDogInfo.setPrizeId(prizeInfo.getId());
                activityLuckyDogInfo.setPrizeName(prizeInfo.getPrizeName());

                activityLuckyDogInfoList.add(activityLuckyDogInfo);
            }
        }
        if (null == activityLuckyDogInfoList
                || 0 >= activityLuckyDogInfoList.size()) {
            return;
        }
        // 批量插入
        activityLuckyDogInfoCustomizedMapper.batchSave(activityLuckyDogInfoList);
    }

    /**
     * 获得幸运儿信息
     *
     * @param activitySearchDTO
     *
     * @return
     */
    @Override
    public List<ActivityLuckyDogInfo> getActivityLuckyDogs(ActivitySearchDTO activitySearchDTO) {

        List<Integer> activityPrizeIds = null;
        boolean showFlag = false;
        if (null != activitySearchDTO.getPrizeStatus()
                && 4 == activitySearchDTO.getPrizeStatus()) {
            showFlag = true;
            ActivityPrizeInfoExample example = new ActivityPrizeInfoExample();
            ActivityPrizeInfoExample.Criteria criteria1 = example
                    .createCriteria();
            criteria1.andStatusEqualTo(activitySearchDTO.getPrizeStatus());
            if (null != activitySearchDTO.getActivityId()) {
                criteria1.andActivityIdEqualTo(activitySearchDTO.getActivityId());
            }
            List<ActivityPrizeInfo> activityPrizeInfoList = activityPrizeInfoMapper.selectByExample(example);
            if (null != activityPrizeInfoList && 0 < activityPrizeInfoList.size()) {
                activityPrizeIds = new ArrayList<>(activityPrizeInfoList.size());
                for (ActivityPrizeInfo activityPrizeInfo : activityPrizeInfoList) {
                    activityPrizeIds.add(activityPrizeInfo.getId());
                }
            }
        }

        ActivityLuckyDogInfoExample activityLuckyDogInfoExample = new ActivityLuckyDogInfoExample();
        ActivityLuckyDogInfoExample.Criteria criteria = activityLuckyDogInfoExample.createCriteria();
        criteria.andStatusEqualTo(1);

        if (showFlag) {
            if (null == activityPrizeIds || 0 >= activityPrizeIds.size()) {
                return new ArrayList<>();
            }
            criteria
                    .andActivityPrizeIdIn(activityPrizeIds);
            if (null != activitySearchDTO.getActivityId()) {
                criteria.andActivityIdEqualTo(activitySearchDTO.getActivityId());
            }
            List<ActivityLuckyDogInfo> activityLuckyDogInfoList = activityLuckyDogInfoMapper.selectByExample(activityLuckyDogInfoExample);
            return activityLuckyDogInfoList;
        }

        if (null != activitySearchDTO.getActivityId()) {
            criteria.andActivityIdEqualTo(activitySearchDTO.getActivityId());
        }
        if (null != activitySearchDTO.getActivityType()) {
            criteria.andActivityTypeEqualTo(activitySearchDTO.getActivityType());
        }
        if (null != activitySearchDTO.getActivityTypeList() && 0 < activitySearchDTO.getActivityTypeList().size()) {
            criteria.andActivityTypeIn(activitySearchDTO.getActivityTypeList());
        }
        if (null != activitySearchDTO.getActivityPrizeId()) {
            criteria.andActivityPrizeIdEqualTo(activitySearchDTO.getActivityPrizeId());
        }
        if (null != activitySearchDTO.getDepartmentId()) {
            criteria.andUserDepartmentIdEqualTo(activitySearchDTO.getDepartmentId());
        }
        if (null != activitySearchDTO.getDepartmentName() && !"".equals(activitySearchDTO.getDepartmentName())) {
            criteria.andUserDepartmentNameLike("%" + activitySearchDTO.getDepartmentName() + "%");
        }
        if (null != activitySearchDTO.getUserName() && !"".equals(activitySearchDTO.getUserName())) {
            criteria.andUserNameLike("%" + activitySearchDTO.getUserName() + "%");
        }
        if (null != activitySearchDTO.getActivityName() && !"".equals(activitySearchDTO.getActivityName())){
            criteria.andActivityNameLike("%" + activitySearchDTO.getActivityName() + "%");
        }
        if (null != activitySearchDTO.getPrizeName() && !"".equals(activitySearchDTO.getPrizeName())){
            criteria.andPrizeNameLike("%" + activitySearchDTO.getPrizeName() + "%");
        }


        List<ActivityLuckyDogInfo> activityLuckyDogInfoList = activityLuckyDogInfoMapper.selectByExample(activityLuckyDogInfoExample);
        return activityLuckyDogInfoList;
    }

    /**
     * 除投票之外的其他活动抽奖
     *
     * @param activitySearchDTO
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void otherLottery(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");

        List<ActivityPrizeInfo> activityPrizeInfoList = null;
        if (null == activitySearchDTO.getActivityPrizeId()) {
            // 没有传奖项Id 说明是一次性将活动所有合理奖项抽取出来

            // 那么说明是第二种类型的活动
            AssertUtil.isNull(activitySearchDTO.getActivityPrizeInfoExtId(), "缺少activityPrizeInfoExtId参数");

            ActivityPrizeInfoExt activityPrizeInfoExt =
                    activityPrizeInfoExtMapper.selectByPrimaryKey(activitySearchDTO.getActivityPrizeInfoExtId());

            if (null == activityPrizeInfoExt) {
                throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "数据配置不完整");
            }
            String activityPrizeIds = activityPrizeInfoExt.getActivityPrizeId();
            String[] activityPrizeIdArray = activityPrizeIds.trim().split(",");
            List<Integer> activityPrizeIdList = new ArrayList<>();
            for (String activityPrizeId : activityPrizeIdArray) {
                activityPrizeIdList.add(Integer.valueOf(activityPrizeId));
            }
            ActivityPrizeInfoExample activityPrizeInfoExample = new ActivityPrizeInfoExample();
            activityPrizeInfoExample
                    .createCriteria()
                    .andStatusNotEqualTo(3)
                    .andStatusNotEqualTo(4)
                    .andIdIn(activityPrizeIdList)
                    .andActivityIdEqualTo(activitySearchDTO.getActivityId());
            activityPrizeInfoList = activityPrizeInfoMapper.selectByExample(activityPrizeInfoExample);

        } else {
            activityPrizeInfoList = new ArrayList<>();
            ActivityPrizeInfo activityPrizeInfo = activityPrizeInfoMapper.selectByPrimaryKey(activitySearchDTO.getActivityPrizeId());
            if (null == activityPrizeInfo || 0 >= activityPrizeInfo.getActivityPrizeWinningNumber()) {
                return;
            }
            switch (activityPrizeInfo.getStatus()) {
                case 3:
                case 4:
                    throw new BusinessException(ResultCode.ACTIVITY_LOTTERY_OPEN.getCode(), "已经开奖");
            }
            activityPrizeInfoList.add(activityPrizeInfo);
        }
        if (null == activityPrizeInfoList || 0 >= activityPrizeInfoList.size()) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "不要重复点击");
        }
        new Thread(){
            @Override
            public void run() {
                List<ActivityPrizeInfo> activityPrizeInfoList = null;
                if (null == activitySearchDTO.getActivityPrizeId()) {
                    // 没有传奖项Id 说明是一次性将活动所有合理奖项抽取出来

                    // 那么说明是第二种类型的活动
                    AssertUtil.isNull(activitySearchDTO.getActivityPrizeInfoExtId(), "缺少activityPrizeInfoExtId参数");

                    ActivityPrizeInfoExt activityPrizeInfoExt =
                            activityPrizeInfoExtMapper.selectByPrimaryKey(activitySearchDTO.getActivityPrizeInfoExtId());

                    if (null == activityPrizeInfoExt) {
                        throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "数据配置不完整");
                    }
                    String activityPrizeIds = activityPrizeInfoExt.getActivityPrizeId();
                    String[] activityPrizeIdArray = activityPrizeIds.trim().split(",");
                    List<Integer> activityPrizeIdList = new ArrayList<>();
                    for (String activityPrizeId : activityPrizeIdArray) {
                        activityPrizeIdList.add(Integer.valueOf(activityPrizeId));
                    }


                    ActivityPrizeInfoExample activityPrizeInfoExample = new ActivityPrizeInfoExample();
                    activityPrizeInfoExample
                            .createCriteria()
                            .andStatusNotEqualTo(3)
                            .andStatusNotEqualTo(4)
                            .andIdIn(activityPrizeIdList)
                            .andActivityIdEqualTo(activitySearchDTO.getActivityId());
                    activityPrizeInfoList = activityPrizeInfoMapper.selectByExample(activityPrizeInfoExample);

                } else {
                    activityPrizeInfoList = new ArrayList<>();
                    ActivityPrizeInfo activityPrizeInfo = activityPrizeInfoMapper.selectByPrimaryKey(activitySearchDTO.getActivityPrizeId());
                    activityPrizeInfoList.add(activityPrizeInfo);
                }
                for (ActivityPrizeInfo activityPrizeInfo : activityPrizeInfoList) {



                    int activityPrizeWinningNumber = activityPrizeInfo.getActivityPrizeWinningNumber();
                    int count = staffInfoCustomizedMapper.countValidUser(null);
                    if (0 >= count) {
                        return;
                    }
                    List<StaffInfoCustomized> staffInfoCustomizedList = staffInfoCustomizedMapper.selectValidUser(null);
                    if (activityPrizeWinningNumber >= count) {
                        // 中奖人数 >= 有效用户数，即所有有效用户都是中奖人员
                        saveActivityLuckyDog(null, staffInfoCustomizedList, activitySearchDTO.getActivityId(), activityPrizeInfo.getId());
                        return;
                    }

                    // 中奖人数 < 有效用户数, 即只有部分人中奖，
                    // 权重 不间断 不交叉
                    // 1.加载部门权重
                    ActivityDepartmentWinningWeightExample activityDepartmentWinningWeightExample = new ActivityDepartmentWinningWeightExample();
                    activityDepartmentWinningWeightExample
                            .createCriteria()
                            .andActivityIdLike(String.valueOf(activitySearchDTO.getActivityId()));
                    List<ActivityDepartmentWinningWeight> activityDepartmentWinningWeightList = activityDepartmentWinningWeightMapper.selectByExample(activityDepartmentWinningWeightExample);
                    if (null == activityDepartmentWinningWeightList || 0 >= activityDepartmentWinningWeightList.size()) {
                        // 没有设置权重 策略: 在[0,count)区间上产生activityPrizeWinningNumber个随机数
                        int[] winningNumbers = new int[count];
                        random(winningNumbers, activityPrizeWinningNumber, count, 0);
                        List<StaffInfoCustomized> winningStaffInfoList = new ArrayList<>();
                        for (int i = 0; i < count; i++) {
                            if (1 == winningNumbers[i]) {
                                winningStaffInfoList.add(staffInfoCustomizedList.get(i));
                            }
                        }
                        saveActivityLuckyDog(null,
                                winningStaffInfoList,
                                activitySearchDTO.getActivityId(),
                                activityPrizeInfo.getId());
                        return;
                    }

                    // 有设置权重 策略: 在[min_left_interval, max_right_interval) 区间上产生activityPrizeWinningNumber个随机数
                    Integer minLeftInterval = null;
                    Integer maxRightInterval = null;

                    Map<String, List<StaffInfoCustomized>> validUserMap = new HashMap<>();
                    Map<String, Integer> validUserCountMap = new HashMap<>();

                    for (ActivityDepartmentWinningWeight weight : activityDepartmentWinningWeightList) {

                        String[] dIdArray = weight.getDepartmentId().replace(" ","").split(",");
                        List<Integer> departmentIdList = new ArrayList<>();
                        for (String dId : dIdArray) {
                            departmentIdList.add(Integer.valueOf(dId));
                        }
                        List<StaffInfoCustomized> staffInfoCustomizedList1 = staffInfoCustomizedMapper.selectValidUser(departmentIdList);
                        validUserMap.put(weight.getDepartmentId(), staffInfoCustomizedList1);
                        Integer countValidUser = staffInfoCustomizedMapper.countValidUser(departmentIdList);
                        validUserCountMap.put(weight.getDepartmentId(), null == countValidUser ? 0 : countValidUser);

                        if (null == minLeftInterval) {
                            minLeftInterval = weight.getLeftInterval();
                        } else if (minLeftInterval > weight.getLeftInterval()) {
                            minLeftInterval = weight.getLeftInterval();
                        }
                        if (null == maxRightInterval) {
                            maxRightInterval = weight.getRightInterval();
                        } else if (maxRightInterval < weight.getRightInterval()) {
                            maxRightInterval = weight.getRightInterval();
                        }
                    }

                    int[] winningNumbers = new int[maxRightInterval];

                    Map<Integer, StaffInfoCustomized> winningMap = new HashMap<>();

                    Random random = new Random();
                    for (int i = 0; i < activityPrizeWinningNumber; i++) {
                        int num = random.nextInt(maxRightInterval) + minLeftInterval;
                        if (1 == winningNumbers[num]) {
                            i--;
                        } else {
                            boolean flag1 = true;
                            for (ActivityDepartmentWinningWeight weight : activityDepartmentWinningWeightList) {
                                if (num >= weight.getLeftInterval() && num < weight.getRightInterval()) {
                                    if (0 < validUserCountMap.get(weight.getDepartmentId())) {
                                        List<StaffInfoCustomized> staffInfoCustomizedList1 = validUserMap.get(weight.getDepartmentId());
                                        Integer countValidUser1 = validUserCountMap.get(weight.getDepartmentId());
                                        boolean flag = true;
                                        while (flag) {
                                            StaffInfoCustomized staffInfoCustomized = staffInfoCustomizedList1.get(random.nextInt(countValidUser1));
                                            if (null == winningMap.get(staffInfoCustomized.getStaffId())) {
                                                winningMap.put(staffInfoCustomized.getStaffId(), staffInfoCustomized);
                                                flag = false;
                                            }
                                        }
                                        validUserCountMap.put(weight.getDepartmentId(), validUserCountMap.get(weight.getDepartmentId()) - 1);

                                        winningNumbers[num] = 1;
                                        flag1 = false;
                                    }
                                }
                            }
                            if (flag1) {
                                i--;
                            }
                        }
                    }

                    saveActivityLuckyDog(null,
                            new ArrayList<>(winningMap.values()),
                            activitySearchDTO.getActivityId(),
                            activityPrizeInfo.getId());

                    // 1.修改奖项状态为结束抽奖
                    ActivityPrizeInfo record = new ActivityPrizeInfo();
                    record.setId(activityPrizeInfo.getId());
                    record.setStatus(3);
                    activityPrizeInfoMapper.updateByPrimaryKeySelective(record);
                }
            }
        }.start();
    }




    // 抽取666个中奖人
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void decibelLottery(ActivitySearchDTO activitySearchDTO) {



        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        ActivityPrizeInfoExample example = new ActivityPrizeInfoExample();
        example
                .createCriteria()
                .andStatusEqualTo(1)
                .andActivityIdEqualTo(activitySearchDTO.getActivityId());
        List<ActivityPrizeInfo> activityPrizeInfoList = activityPrizeInfoMapper.selectByExample(example);

        if (null == activityPrizeInfoList || 0 >= activityPrizeInfoList.size()) {
            decibelLotteryFlag = true;
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "没有有效的奖项");
        }

        int count = staffInfoCustomizedMapper.countValidUser(null);
        if (0 == count) {
            decibelLotteryFlag = true;
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "没有符合抽奖的用户");
        }

        if (decibelLotteryFlag) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "请不要重复点击");
        }

        if (!decibelLotteryFlag) {
            new Thread(){
                @Override
                public void run() {

                    decibelLotteryRunFlag = true;

                    for (ActivityPrizeInfo activityPrizeInfo : activityPrizeInfoList) {
                        int activityPrizeWinningNumber = activityPrizeInfo.getActivityPrizeWinningNumber();
                        int count = staffInfoCustomizedMapper.countValidUser(null);
                        if (0 >= count) {
                            decibelLotteryRunFlag = false;
                            decibelLotteryFlag = true;
                            return;
                        }
                        List<StaffInfoCustomized> staffInfoCustomizedList = staffInfoCustomizedMapper.selectValidUser(null);
                        if (activityPrizeWinningNumber >= count) {
                            // 中奖人数 >= 有效用户数，即所有有效用户都是中奖人员
                            saveActivityLuckyDog(null, staffInfoCustomizedList, activitySearchDTO.getActivityId(), activityPrizeInfo.getId());
                            decibelLotteryRunFlag = false;
                            decibelLotteryFlag = true;
                            return;
                        }

                        // 中奖人数 < 有效用户数, 即只有部分人中奖，
                        // 权重 不间断 不交叉
                        // 1.加载部门权重
                        ActivityDepartmentWinningWeightExample activityDepartmentWinningWeightExample = new ActivityDepartmentWinningWeightExample();
                        activityDepartmentWinningWeightExample
                                .createCriteria()
                                .andActivityIdLike(String.valueOf(activitySearchDTO.getActivityId()));
                        List<ActivityDepartmentWinningWeight> activityDepartmentWinningWeightList = activityDepartmentWinningWeightMapper.selectByExample(activityDepartmentWinningWeightExample);
                        if (null == activityDepartmentWinningWeightList || 0 >= activityDepartmentWinningWeightList.size()) {
                            // 没有设置权重 策略: 在[0,count)区间上产生activityPrizeWinningNumber个随机数
                            int[] winningNumbers = new int[count];
                            random(winningNumbers, activityPrizeWinningNumber, count, 0);
                            List<StaffInfoCustomized> winningStaffInfoList = new ArrayList<>();
                            for (int i = 0; i < count; i++) {
                                if (1 == winningNumbers[i]) {
                                    winningStaffInfoList.add(staffInfoCustomizedList.get(i));
                                }
                            }
                            saveActivityLuckyDog(null,
                                    winningStaffInfoList,
                                    activitySearchDTO.getActivityId(),
                                    activityPrizeInfo.getId());

                            decibelLotteryRunFlag = false;
                            decibelLotteryFlag = true;

                            return;
                        }

                        // 有设置权重 策略: 在[min_left_interval, max_right_interval) 区间上产生activityPrizeWinningNumber个随机数
                        Integer minLeftInterval = null;
                        Integer maxRightInterval = null;

                        Map<String, List<StaffInfoCustomized>> validUserMap = new HashMap<>();
                        Map<String, Integer> validUserCountMap = new HashMap<>();

                        for (ActivityDepartmentWinningWeight weight : activityDepartmentWinningWeightList) {

                            String[] dIdArray = weight.getDepartmentId().replace(" ","").split(",");
                            List<Integer> departmentIdList = new ArrayList<>();
                            for (String dId : dIdArray) {
                                departmentIdList.add(Integer.valueOf(dId));
                            }
                            List<StaffInfoCustomized> staffInfoCustomizedList1 = staffInfoCustomizedMapper.selectValidUser(departmentIdList);
                            validUserMap.put(weight.getDepartmentId(), staffInfoCustomizedList1);
                            Integer countValidUser = staffInfoCustomizedMapper.countValidUser(departmentIdList);
                            validUserCountMap.put(weight.getDepartmentId(), null == countValidUser ? 0 : countValidUser);

                            if (null == minLeftInterval) {
                                minLeftInterval = weight.getLeftInterval();
                            } else if (minLeftInterval > weight.getLeftInterval()) {
                                minLeftInterval = weight.getLeftInterval();
                            }
                            if (null == maxRightInterval) {
                                maxRightInterval = weight.getRightInterval();
                            } else if (maxRightInterval < weight.getRightInterval()) {
                                maxRightInterval = weight.getRightInterval();
                            }
                        }

                        int[] winningNumbers = new int[maxRightInterval];

                        Map<Integer, StaffInfoCustomized> winningMap = new HashMap<>();

                        Random random = new Random();
                        for (int i = 0; i < activityPrizeWinningNumber; i++) {
                            int num = random.nextInt(maxRightInterval) + minLeftInterval;
                            if (1 == winningNumbers[num]) {
                                i--;
                            } else {
                                boolean flag1 = true;
                                for (ActivityDepartmentWinningWeight weight : activityDepartmentWinningWeightList) {
                                    if (num >= weight.getLeftInterval() && num < weight.getRightInterval()) {
                                        if (0 < validUserCountMap.get(weight.getDepartmentId())) {
                                            List<StaffInfoCustomized> staffInfoCustomizedList1 = validUserMap.get(weight.getDepartmentId());
                                            Integer countValidUser1 = validUserCountMap.get(weight.getDepartmentId());
                                            boolean flag = true;
                                            while (flag) {
                                                StaffInfoCustomized staffInfoCustomized = staffInfoCustomizedList1.get(random.nextInt(countValidUser1));
                                                if (null == winningMap.get(staffInfoCustomized.getStaffId())) {
                                                    winningMap.put(staffInfoCustomized.getStaffId(), staffInfoCustomized);
                                                    flag = false;
                                                }
                                            }
                                            validUserCountMap.put(weight.getDepartmentId(), validUserCountMap.get(weight.getDepartmentId()) - 1);

                                            winningNumbers[num] = 1;
                                            flag1 = false;
                                        }
                                    }
                                }
                                if (flag1) {
                                    i--;
                                }
                            }
                        }

                        saveActivityLuckyDog(null,
                                new ArrayList<>(winningMap.values()),
                                activitySearchDTO.getActivityId(),
                                activityPrizeInfo.getId());

                        // 1.修改奖项状态为结束抽奖
                        ActivityPrizeInfo record = new ActivityPrizeInfo();
                        record.setId(activityPrizeInfo.getId());
                        record.setStatus(3);
                        activityPrizeInfoMapper.updateByPrimaryKeySelective(record);

                    }
                    decibelLotteryRunFlag = false;
                }
            }.start();
        }
        decibelLotteryFlag = true;
    }

    /**
     * 清空抽奖结果
     *
     * @param activitySearchDTO
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void clearLottery(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        List<Integer> activityPrizeIdList = new ArrayList<>();
        if (null == activitySearchDTO.getActivityPrizeId()) {
            AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
            ActivityPrizeInfoExample activityPrizeInfoExample = new ActivityPrizeInfoExample();
            activityPrizeInfoExample.createCriteria().andActivityIdEqualTo(activitySearchDTO.getActivityId());
            List<ActivityPrizeInfo> activityPrizeInfoList = activityPrizeInfoMapper.selectByExample(activityPrizeInfoExample);
            if (null == activityPrizeInfoList || 0 >= activityPrizeInfoList.size()) {
                return;
            }
            for (ActivityPrizeInfo activityPrizeInfo : activityPrizeInfoList) {
                activityPrizeIdList.add(activityPrizeInfo.getId());
            }
        } else {
            AssertUtil.isNull(activitySearchDTO.getActivityPrizeId(), "缺少activityPrizeId参数");
            activityPrizeIdList.add(activitySearchDTO.getActivityPrizeId());
        }
        if (null == activityPrizeIdList || 0 >= activityPrizeIdList.size()) {
            return;
        }

        for (Integer activityPrizeId : activityPrizeIdList) {

            // 1.修改奖项状态为等待抽奖
            ActivityPrizeInfo  record = new ActivityPrizeInfo();
            record.setId(activityPrizeId);
            record.setStatus(1);
            activityPrizeInfoMapper.updateByPrimaryKeySelective(record);

            // 2.修改
            ActivityLuckyDogInfoExample activityLuckyDogInfoExample = new ActivityLuckyDogInfoExample();
            activityLuckyDogInfoExample
                    .createCriteria()
                    .andActivityPrizeIdEqualTo(activityPrizeId);
            ActivityLuckyDogInfo activityLuckyDogInfo = new ActivityLuckyDogInfo();
            activityLuckyDogInfo.setStatus(2); // 无效
            activityLuckyDogInfoMapper.updateByExampleSelective(activityLuckyDogInfo,activityLuckyDogInfoExample);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void clearDecibelLottery(ActivitySearchDTO activitySearchDTO) {
        if (decibelLotteryRunFlag) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "正在产生中奖名单，请稍后再试");
        }
        clearLottery(activitySearchDTO);

        // 重置状态
        decibelLotteryFlag = false;
        lotteryDog666 = false;
        lotteryDog333 = false;
        lotteryDog333_ = false;
    }

    /**
     * 修改领奖标记
     *
     * @param activityLuckyDogId
     *         幸运儿Id
     * @param receiveFlag
     *         1-没有领奖 2-已经领奖
     */
    @Override
    public void modifyReceiveFlag(Integer activityLuckyDogId, int receiveFlag) {
        ActivityLuckyDogInfo record = new ActivityLuckyDogInfo();
        record.setId(activityLuckyDogId);
        record.setReceiveFlag(receiveFlag);
        record.setReceiveTime(new Date());
        activityLuckyDogInfoMapper.updateByPrimaryKeySelective(record);
    }

    /**
     * 抽奖活动详情
     * @param activitySearchDTO
     * @return
     */
    @Override
    public ActivityVoteDTO getActivityVote(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getUserId(), "缺少userId参数");

        ActivityBaseInfoExample example = new ActivityBaseInfoExample();
        example.createCriteria().andStatusIn(Arrays.asList(6, 7, 8));
        example.setOrderByClause("update_time asc");
        List<ActivityBaseInfo> activityBaseInfoList = activityBaseInfoMapper.selectByExample(example);
        if (null == activityBaseInfoList || 0 >= activityBaseInfoList.size()) {
            throw new BusinessException(ResultCode.ACTIVITY_NOT_BEGIN.getCode(), "节目还没有开始！");
        }

        ActivityBaseInfo activityBaseInfo = null;
        Integer status = 10;
        for (ActivityBaseInfo baseInfo : activityBaseInfoList) {
            if (status >= baseInfo.getStatus()) {
                status = baseInfo.getStatus();
                activityBaseInfo = baseInfo;
            }
        }

        if (null == activityBaseInfo ) {
            throw new BusinessException(ResultCode.ACTIVITY_NOT_EXIST.getCode(), ResultCode.ACTIVITY_NOT_EXIST.getMsg());
        }

        ActivityVoteDTO activityVoteDTO = new ActivityVoteDTO();
        activityVoteDTO.setActivityBaseInfo(activityBaseInfo);

        // 投票活动
        // 查询战队信息
        ActivityVoteInfoExample activityVoteInfoExample = new ActivityVoteInfoExample();
        activityVoteInfoExample.createCriteria().andActivityIdEqualTo(activityBaseInfo.getId());
        List<ActivityVoteInfo> activityVoteInfoList = activityVoteInfoMapper.selectByExample(activityVoteInfoExample);
        if (null != activityVoteInfoList && 0 < activityVoteInfoList.size()) {
            for (ActivityVoteInfo activityVoteInfo : activityVoteInfoList) {
                ActivityUserVoteExample activityUserVoteExample = new ActivityUserVoteExample();
                activityUserVoteExample
                        .createCriteria()
                        .andActivityIdEqualTo(activityVoteInfo.getActivityId())
                        .andVoteIdEqualTo(activityVoteInfo.getId());
                activityVoteInfo.setVoteNumber(activityUserVoteMapper.countByExample(activityUserVoteExample));
            }
        }
        activityVoteDTO.setActivityVoteInfoList(activityVoteInfoList);

        // 查询用户投票信息
        ActivityUserVoteKey activityUserVoteKey = new ActivityUserVoteKey();
        activityUserVoteKey.setActivityId(activityBaseInfo.getId());
        activityUserVoteKey.setUserId(activitySearchDTO.getUserId());
        ActivityUserVote activityUserVote = activityUserVoteMapper.selectByPrimaryKey(activityUserVoteKey);
        activityVoteDTO.setActivityUserVote(activityUserVote);

        return activityVoteDTO;
    }

    /**
     * "我的奖品"
     *
     * @param activitySearchDTO
     *
     * @return
     */
    @Override
    public List<ActivityPrizeWinningDTO> myPrize(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getUserId(), "缺少userId参数");


        // 查询结束的活动列表
        ActivityBaseInfoExample activityBaseInfoExample = new ActivityBaseInfoExample();
        activityBaseInfoExample.createCriteria().andStatusEqualTo(5);
        List<ActivityBaseInfo> activityBaseInfoList = activityBaseInfoMapper.selectByExample(activityBaseInfoExample);
        if (null == activityBaseInfoList || 0 < activityBaseInfoList.size()) {
            return null;
        }
        List<Integer> activityIdList = new ArrayList<>();
        for (ActivityBaseInfo activityBaseInfo : activityBaseInfoList) {
            activityIdList.add(activityBaseInfo.getId());
        }

        ActivityLuckyDogInfoExample example = new ActivityLuckyDogInfoExample();
        ActivityLuckyDogInfoExample.Criteria criteria = example.createCriteria();
        criteria.andStatusEqualTo(1)
                .andActivityIdIn(activityIdList)
                .andUserIdEqualTo(activitySearchDTO.getUserId());
        if (null != activitySearchDTO.getActivityId()) {
            criteria.andActivityIdEqualTo(activitySearchDTO.getActivityId());
        }
        if (null != activitySearchDTO.getActivityPrizeId()) {
            criteria.andActivityPrizeIdEqualTo(activitySearchDTO.getActivityPrizeId());
        }
        List<ActivityLuckyDogInfo> activityLuckyDogInfoList = activityLuckyDogInfoMapper.selectByExample(example);
        if (null == activityLuckyDogInfoList || 0 >= activityLuckyDogInfoList.size()) {
            return null;
        }

        List<ActivityPrizeWinningDTO> activityPrizeWinningDTOList = new ArrayList<>();

        for (ActivityLuckyDogInfo activityLuckyDogInfo : activityLuckyDogInfoList) {

            ActivityPrizeWinningDTO activityPrizeWinningDTO = new ActivityPrizeWinningDTO();
            activityPrizeWinningDTO.setWinningTime(activityLuckyDogInfo.getWinningTime());
            activityPrizeWinningDTO.setReceiveFlag(activityLuckyDogInfo.getReceiveFlag());
            activityPrizeWinningDTO.setReceiveTime(activityLuckyDogInfo.getReceiveTime());
            ActivityBaseInfo activityBaseInfo = activityBaseInfoMapper.selectByPrimaryKey(activityLuckyDogInfo.getActivityId());
            if (null != activityBaseInfo) {
                activityPrizeWinningDTO.setActivityId(activityBaseInfo.getId());
                activityPrizeWinningDTO.setActivityName(activityBaseInfo.getActivityName());
                activityPrizeWinningDTO.setActivityDesc(activityBaseInfo.getActivityDesc());
            }
            ActivityPrizeInfo activityPrizeInfo = activityPrizeInfoMapper.selectByPrimaryKey(activityLuckyDogInfo.getActivityPrizeId());
            if (null != activityPrizeInfo) {
                PrizeInfo prizeInfo = prizeInfoMapper.selectByPrimaryKey(activityPrizeInfo.getPrizeId());
                activityPrizeWinningDTO.setPrizeInfo(prizeInfo);
            }

            activityPrizeWinningDTOList.add(activityPrizeWinningDTO);
        }

        return activityPrizeWinningDTOList;
    }

    /**
     * 结束投票
     *
     * @param activitySearchDTO
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void endVoting(ActivitySearchDTO activitySearchDTO) {
        this.modifyStatus(activitySearchDTO.getActivityId(), 8);
        this.displayVoting(activitySearchDTO, true);
    }

    @Override
    public ActivityBaseInfo getActivityBaseInfoByActivityId(Integer activityId) {
       return activityBaseInfoMapper.selectByPrimaryKey(activityId);
    }

    /**
     * 设置获胜队伍
     *
     * @param activitySearchDTO
     */
    @Override
    public void setWin(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        AssertUtil.isNull(activitySearchDTO.getVoteId(), "缺少voteId参数");

        ActivityVoteInfo activityVoteInfo = this.getWin(activitySearchDTO);
        if (null != activityVoteInfo) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "已经设置" + activityVoteInfo.getVoteName() +"为获胜队伍");
        }
        ActivityVoteInfo record = new ActivityVoteInfo();
        record.setId(activitySearchDTO.getVoteId());
        record.setWinFlag(2);
        activityVoteInfoMapper.updateByPrimaryKeySelective(record);
    }

    /**
     * 查询获胜队伍
     *
     * @param activitySearchDTO
     */
    @Override
    public ActivityVoteWinDTO getWin(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        AssertUtil.isNull(activitySearchDTO.getActivityPrizeId(), "缺少activityPrizeId参数");
        ActivityVoteInfoExample example = new ActivityVoteInfoExample();
        example.createCriteria().andActivityIdEqualTo(activitySearchDTO.getActivityId()).andWinFlagEqualTo(2);
        List<ActivityVoteInfo> activityVoteInfoList = activityVoteInfoMapper.selectByExample(example);
        if (null == activityVoteInfoList || 0 >= activityVoteInfoList.size()) {
            return null;
        }
        ActivityVoteWinDTO activityVoteWinDTO = ActivityVoteWinDTO.transfer(activityVoteInfoList.get(0));
        activityVoteWinDTO.setActivityPrizeId(activitySearchDTO.getActivityPrizeId());
        return  activityVoteWinDTO;
    }





    private List<ActivityLuckyDogInfo> getActivityLuckyDogInfoList (Integer extId) {
        ActivityPrizeInfoExt activityPrizeInfoExt = activityPrizeInfoExtMapper.selectByPrimaryKey(extId);
        String activityPrizeIdStr = activityPrizeInfoExt.getActivityPrizeId();
        String[] activityPrizeIdArray = activityPrizeIdStr.trim().split(",");
        List<Integer> activityPrizeIdList = new ArrayList<>();
        for (String activityPrizeId : activityPrizeIdArray) {
            activityPrizeIdList.add(Integer.valueOf(activityPrizeId));
        }
        ActivityLuckyDogInfoExample example = new ActivityLuckyDogInfoExample();
        example
                .createCriteria()
                .andActivityPrizeIdIn(activityPrizeIdList)
                .andStatusEqualTo(1);
        return activityLuckyDogInfoMapper.selectByExample(example);
    }


    /**
     * 大屏展示中奖名单
     *
     * @param activitySearchDTO
     *
     * @return
     */
    @Override
    public Map<Integer, List<ActivityLuckyDogInfo>> getOtherLotteryDog(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");

        if (!decibelLotteryFlag) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "没有执行抽取中奖人的操作");
        }
        if (decibelLotteryRunFlag) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "中奖人产生中...");
        }
        if (!lotteryDog666 && !lotteryDog333 && !lotteryDog333_) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "没有执行抽取多少个中奖人的操作");
        }
        List<ActivityLuckyDogInfo> activityLuckyDogInfoList = null;
        if (lotteryDog666) {
            // 返回666个中奖人名单
            activityLuckyDogInfoList = getActivityLuckyDogInfoList(1);
        }
        if (lotteryDog333) {
            // 返回333个中奖名单
            activityLuckyDogInfoList = getActivityLuckyDogInfoList(2);
        }
        if (lotteryDog333_) {
            activityLuckyDogInfoList = getActivityLuckyDogInfoList(3);
        }

        if (null == activityLuckyDogInfoList || 0 >= activityLuckyDogInfoList.size()) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "没有中奖人");
        }

        Map<Integer, List<ActivityLuckyDogInfo>> map = new HashMap<>();
        for (ActivityLuckyDogInfo activityLuckyDogInfo : activityLuckyDogInfoList) {
            if (null == map.get(activityLuckyDogInfo.getPrizeId())) {
                List<ActivityLuckyDogInfo> activityLuckyDogInfoList1 = new ArrayList<>();
                activityLuckyDogInfoList1.add(activityLuckyDogInfo);
                map.put(activityLuckyDogInfo.getPrizeId(), activityLuckyDogInfoList1);
            } else {
                map.get(activityLuckyDogInfo.getPrizeId()).add(activityLuckyDogInfo);
            }
        }
        return map;
//        ActivityLuckyDogInfoExample activityLuckyDogInfoExample = new ActivityLuckyDogInfoExample();
//        ActivityLuckyDogInfoExample.Criteria criteria = activityLuckyDogInfoExample.createCriteria();
//        List<Integer> activityPrizeIdList = new ArrayList<>();
//        if ( null != activitySearchDTO.getActivityPrizeInfoExtId() ) {
//            ActivityPrizeInfoExt activityPrizeInfoExt = activityPrizeInfoExtMapper.selectByPrimaryKey(activitySearchDTO.getActivityPrizeInfoExtId());
//            String[] activityPrizeIds = activityPrizeInfoExt.getActivityPrizeId().trim().split(",");
//            for (String activityPrizeId : activityPrizeIds) {
//                activityPrizeIdList.add(Integer.valueOf(activityPrizeId));
//            }
//            criteria.andActivityPrizeIdIn(activityPrizeIdList);
//        }
//        criteria.andStatusEqualTo(1)
//                .andActivityIdEqualTo(activitySearchDTO.getActivityId());
//        List<ActivityLuckyDogInfo> activityLuckyDogInfoList = activityLuckyDogInfoMapper.selectByExample(activityLuckyDogInfoExample);
//        if (null == activityLuckyDogInfoList || 0 >= activityLuckyDogInfoList.size()) {
//            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "中奖人产生中...");
//        }
//
////        int count = 0;
////        int prizeIdCount21 = 0;
////        int prizeIdCount22 = 0;
//
//
//        Map<Integer, List<ActivityLuckyDogInfo>> map = new HashMap<>();
//        List<Integer> prizeIdList = new ArrayList<>();
//
//        for (ActivityLuckyDogInfo activityLuckyDogInfo : activityLuckyDogInfoList) {
//
//            if (null == map.get(activityLuckyDogInfo.getPrizeId())) {
//                prizeIdList.add(activityLuckyDogInfo.getPrizeId());
//
//                List<ActivityLuckyDogInfo> activityLuckyDogInfoList1 = new ArrayList<>();
//                activityLuckyDogInfoList1.add(activityLuckyDogInfo);
//                map.put(activityLuckyDogInfo.getPrizeId(), activityLuckyDogInfoList1);
//            } else {
//                map.get(activityLuckyDogInfo.getPrizeId()).add(activityLuckyDogInfo);
//            }
//        }
//        // 63 == prizeIdCount2 说明抽取的是666，
//        // 31 == prizeIdCount2 && 0 != prizeIdCount3 说明抽取的是333
//        // 32 == prizeIdCount2 && 0 != prizeIdCount3 说明抽取的是333补
//
//        Map<Integer, List<ActivityLuckyDogInfo>> resultMap = new HashMap<>();
//        if (1 < prizeIdList.size()) {
//
//            if (21 == prizeIdList.size()) {
//                if (5 == map.get(22).size()) { // 666
//                    return map;
//                } else if ((0 != map.get(22).size() && 2 == map.get(22).size())
//                        || (0 != map.get(22).size() && 3 == map.get(22).size())) { // 333 或 333补
//                    return map;
//                } else {
//                    ActivityPrizeInfoExample activityPrizeInfoExample = new ActivityPrizeInfoExample();
//                    activityPrizeInfoExample
//                            .createCriteria()
//                            .andActivityIdEqualTo(activitySearchDTO.getActivityId())
//                            .andStatusEqualTo(3);
//                    int count = activityPrizeInfoMapper.countByExample(activityPrizeInfoExample);
//                    ActivityPrizeInfoExample activityPrizeInfoExample1 = new ActivityPrizeInfoExample();
//                    activityPrizeInfoExample1
//                            .createCriteria()
//                            .andActivityIdEqualTo(activitySearchDTO.getActivityId())
//                            .andStatusEqualTo(3)
//                            .andIdEqualTo(44);
//                    int count1 = activityPrizeInfoMapper.countByExample(activityPrizeInfoExample1);
//
//                    if (42 == count) {
//                        // 666
//                        return map;
//                    }
//                    if (21 == count && 1 == count1) {
//                        // 333
//                        return map;
//                    }
//
//                    for (int i = 0; i < prizeIdList.size(); i++) {
//                        if (i + 1 < prizeIdList.size()) {
//                            resultMap.put(prizeIdList.get(i), map.get(prizeIdList.get(i)));
//                        }
//                    }
//                }
//            } else {
//                for (int i = 0; i < prizeIdList.size(); i++) {
//                    if (i + 1 < prizeIdList.size()) {
//                        resultMap.put(prizeIdList.get(i), map.get(prizeIdList.get(i)));
//                    }
//                }
//            }
//        }
//        if (null != resultMap && 0 < resultMap.size()) {
//            return resultMap;
//        }
//
//        // 最后一个奖项的中奖人数不足的时候怎么搞 ???
//
//
//        if ( null != activitySearchDTO.getActivityPrizeInfoExtId() ) {
//            // 333补
//            ActivityPrizeInfoExample activityPrizeInfoExample = new ActivityPrizeInfoExample();
//            activityPrizeInfoExample
//                    .createCriteria()
//                    .andActivityIdEqualTo(activitySearchDTO.getActivityId())
//                    .andStatusEqualTo(3)
//                    .andIdEqualTo(45);
//            int count = activityPrizeInfoMapper.countByExample(activityPrizeInfoExample);
//            if (1 == count) {
//                return map;
//            }
//        } else {
//            // 666 或 333
//            ActivityPrizeInfoExample activityPrizeInfoExample = new ActivityPrizeInfoExample();
//            activityPrizeInfoExample
//                    .createCriteria()
//                    .andActivityIdEqualTo(activitySearchDTO.getActivityId())
//                    .andStatusEqualTo(3);
//            int count = activityPrizeInfoMapper.countByExample(activityPrizeInfoExample);
//
//            ActivityPrizeInfoExample activityPrizeInfoExample1 = new ActivityPrizeInfoExample();
//            activityPrizeInfoExample1
//                    .createCriteria()
//                    .andActivityIdEqualTo(activitySearchDTO.getActivityId())
//                    .andStatusEqualTo(3)
//                    .andIdEqualTo(44);
//            int count1 = activityPrizeInfoMapper.countByExample(activityPrizeInfoExample1);
//
//            if (42 == count) {
//                // 666
//                return map;
//            }
//            if (21 == count && 1 == count1) {
//                // 333
//                return map;
//            }
//        }
//
//        throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "中奖人产生中...");


        //        for (ActivityLuckyDogInfo activityLuckyDogInfo : activityLuckyDogInfoList){
//
//
//            if (21 == activityLuckyDogInfo.getPrizeId()) {
//                prizeIdCount21++;
//            }
//            if (22 == activityLuckyDogInfo.getPrizeId()) {
//                prizeIdCount22++;
//            }
//
//            if (null == map.get(activityLuckyDogInfo.getPrizeId())) {
//                count++;
//                List<ActivityLuckyDogInfo> activityLuckyDogInfoList1 = new ArrayList<>();
//                activityLuckyDogInfoList1.add(activityLuckyDogInfo);
//                map.put(activityLuckyDogInfo.getPrizeId(), activityLuckyDogInfoList1);
//            } else {
//                map.get(activityLuckyDogInfo.getPrizeId()).add(activityLuckyDogInfo);
//            }
//        }
        // 查询活动对应的所有奖品
//        int prizeCount = activityPrizeInfoCustomizedMapper.getPrizeCountByActivityId(activitySearchDTO.getActivityId());


//        if (0 == count || count != prizeCount) {
//            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "中奖人产生中...");
//        }

        // 说明是抽取的是 666
//        if (prizeIdCount21 == 5) {
//            if (prizeIdCount22 != 5) {
//                throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "中奖人产生中...");
//            }
//        }
        // 抽取666 prizeIdCount23 = 5 prizeIdCount24 = 5
        // 抽取333 prizeIdCount23 = 3 prizeIdCount24 = 2
        // 再次抽取333 prizeIdCount23 = 2 prizeIdCount24 = 3


    }


    @Override
    public List<PrizeInfo> getPrize(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");

        ActivityPrizeInfoExample activityPrizeInfoExample = new ActivityPrizeInfoExample();
        activityPrizeInfoExample.createCriteria().andActivityIdEqualTo(activitySearchDTO.getActivityId());

        List<ActivityPrizeInfo> activityPrizeInfoList = activityPrizeInfoMapper.selectByExample(activityPrizeInfoExample);
        if (null == activityPrizeInfoList || 0 >= activityPrizeInfoList.size()) {
            return null;
        }

        List<Integer> prizeIdList = new ArrayList<>();
        for (ActivityPrizeInfo activityPrizeInfo : activityPrizeInfoList) {
            prizeIdList.add(activityPrizeInfo.getPrizeId());
        }

        PrizeInfoExample prizeInfoExample = new PrizeInfoExample();
        prizeInfoExample.createCriteria().andIdIn(prizeIdList);
        return prizeInfoMapper.selectByExample(prizeInfoExample);
    }

    @Override
    public ActivitySlotMachinesDTO getSlotMachinesInfo(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        ActivityBaseInfo activityBaseInfo = activityBaseInfoMapper.selectByPrimaryKey(activitySearchDTO.getActivityId());
        if (null == activityBaseInfo) {
            throw new BusinessException(ResultCode.ACTIVITY_NOT_EXIST.getCode(), ResultCode.ACTIVITY_NOT_EXIST.getMsg());
        }
        ActivitySlotMachinesDTO activitySlotMachinesDTO = new ActivitySlotMachinesDTO();
        activitySlotMachinesDTO.setActivityBaseInfo(activityBaseInfo);
        if (null != activitySearchDTO.getActivityPrizeId()) {
            activitySlotMachinesDTO.setActivityPrizeInfo(activityPrizeInfoMapper.selectByPrimaryKey(activitySearchDTO.getActivityPrizeId()));
            return activitySlotMachinesDTO;
        }
        // 查询奖项
        ActivityPrizeInfoExample activityPrizeInfoExample = new ActivityPrizeInfoExample();
        activityPrizeInfoExample
                .createCriteria()
                .andStatusIn(Arrays.asList(2, 3, 4))
                .andActivityIdEqualTo(activitySearchDTO.getActivityId());
        activityPrizeInfoExample.setOrderByClause(" update_time desc ");
        List<ActivityPrizeInfo> activityPrizeInfoList = activityPrizeInfoMapper.selectByExample(activityPrizeInfoExample);
        if (null == activityPrizeInfoList || 0 >= activityPrizeInfoList.size()) {
            return null;
        }
        activitySlotMachinesDTO.setActivityPrizeInfo(activityPrizeInfoList.get(0));
        return activitySlotMachinesDTO;
    }

    @Override
    public void checkActivityVoteStatus(Integer activityId, Integer activityType, Integer status) {

        // 同类型的活动是不是
        ActivityBaseInfoExample example = new ActivityBaseInfoExample();
        example
                .createCriteria()
                .andActivityTypeEqualTo(activityType)
                .andIdNotEqualTo(activityId)
                .andStatusIn(Arrays.asList(6, 7));
        List<ActivityBaseInfo> activityBaseInfoList = activityBaseInfoMapper.selectByExample(example);

        if (null != activityBaseInfoList && 0 < activityBaseInfoList.size()) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), activityBaseInfoList.get(0).getActivityName()+"在进行中");
        }


        ActivityBaseInfo activityBaseInfo = activityBaseInfoMapper.selectByPrimaryKey(activityId);
        if (null == activityBaseInfo) {
            throw new BusinessException(ResultCode.ACTIVITY_NOT_EXIST.getCode(), ResultCode.ACTIVITY_NOT_EXIST.getMsg());
        }
        if (4 == activityBaseInfo.getStatus()) {
            throw new BusinessException(ResultCode.ACTIVITY_NOT_EXIST.getCode(), ResultCode.ACTIVITY_NOT_EXIST.getMsg());
        }
        if (status <= activityBaseInfo.getStatus()) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "不要重复点击");
        }
        if (2 == status - activityBaseInfo.getStatus()
                ||  5 < status - activityBaseInfo.getStatus()) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "不要跳跃步骤点击");
        }
    }

    @Override
    public void modifyActivityPrizeStatus(Integer activityPrizeId, int status) {
        ActivityPrizeInfo record = new ActivityPrizeInfo();
        record.setId(activityPrizeId);
        record.setStatus(status);
        activityPrizeInfoMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public ActivityPrizeInfo getActivityPrizeInfoById(Integer activityPrizeId) {
        return activityPrizeInfoMapper.selectByPrimaryKey(activityPrizeId);
    }

    @Override
    public void modifyActivityPrizeStatusByActivityId(Integer activityId, int status) {
        ActivityPrizeInfo record = new ActivityPrizeInfo();
        record.setStatus(status);
        ActivityPrizeInfoExample example = new ActivityPrizeInfoExample();
        example
                .createCriteria()
                .andActivityIdEqualTo(activityId)
                .andStatusEqualTo(3);
        activityPrizeInfoMapper.updateByExampleSelective(record, example);
    }

    @Override
    public void addProgress(ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO) {
        AssertUtil.isNull(activityExtTimeIntervalDTO, "缺少参数");
        AssertUtil.isNull(activityExtTimeIntervalDTO.getS(), "缺少s参数");
        AssertUtil.isNull(activityExtTimeIntervalDTO.getT(), "缺少t参数");
        AssertUtil.isNull(activityExtTimeIntervalDTO.getActivityId(), "缺少activityId参数");
        AssertUtil.isNull(activityExtTimeIntervalDTO.getpId(), "缺少pId参数");
        Integer timerId = null;
        if (0 == activityExtTimeIntervalDTO.getpId()) {
            ActivityExtTimer activityExtTimer = new ActivityExtTimer();
            activityExtTimer.setActivityId(activityExtTimeIntervalDTO.getActivityId());
            activityExtTimerMapper.insertSelective(activityExtTimer);
            timerId = activityExtTimer.getId();
        } else {
            ActivityExtTimerExample activityExtTimerExample = new ActivityExtTimerExample();
            activityExtTimerExample.createCriteria().andActivityIdEqualTo(activityExtTimeIntervalDTO.getActivityId());
            List<ActivityExtTimer> activityExtTimerList = activityExtTimerMapper.selectByExample(activityExtTimerExample);
            timerId = null == activityExtTimerList || 0 >= activityExtTimerList.size() ? null : activityExtTimerList.get(0).getId();
        }
        if (null != timerId) {
            ActivityExtTimeInterval activityExtTimeInterval  = new ActivityExtTimeInterval();
            activityExtTimeInterval.setS(activityExtTimeIntervalDTO.getS());
            activityExtTimeInterval.setT(activityExtTimeIntervalDTO.getT());
            activityExtTimeInterval.setpId(activityExtTimeIntervalDTO.getpId());
            activityExtTimeInterval.setTimerId(timerId);
            activityExtTimeIntervalMapper.insertSelective(activityExtTimeInterval);
        }
    }

    @Override
    public List<ActivityExtTimeIntervalDTO> listAnimationProgress(ActivityExtTimeIntervalSearchDTO activityExtTimeIntervalSearchDTO) {
        AssertUtil.isNull(activityExtTimeIntervalSearchDTO, "缺少参数");
        AssertUtil.isNull(activityExtTimeIntervalSearchDTO.getActivityId(), "缺少activityId参数");
        ActivityExtTimerExample activityExtTimerExample = new ActivityExtTimerExample();
        activityExtTimerExample.createCriteria().andActivityIdEqualTo(activityExtTimeIntervalSearchDTO.getActivityId());
        List<ActivityExtTimer> activityExtTimerList = activityExtTimerMapper.selectByExample(activityExtTimerExample);
        if (null == activityExtTimerList || 0 >= activityExtTimerList.size()) {
            return null;
        }

        String tf = "{hh}:{mm}:{ss}";

        ActivityExtTimeIntervalExample example = new ActivityExtTimeIntervalExample();
        example.createCriteria().andTimerIdEqualTo(activityExtTimerList.get(0).getId());
        List<ActivityExtTimeInterval> activityExtTimeIntervalList = activityExtTimeIntervalMapper.selectByExample(example);

        if (null == activityExtTimeIntervalList || 0 >= activityExtTimeIntervalList.size()) {
            return null;
        }

        Map<Integer, ActivityExtTimeInterval> activityExtTimeIntervalMap = new HashMap<>();
        for (ActivityExtTimeInterval activityExtTimeInterval : activityExtTimeIntervalList ) {
            activityExtTimeIntervalMap.put(activityExtTimeInterval.getpId(), activityExtTimeInterval);
        }
        List<ActivityExtTimeIntervalDTO> activityExtTimeIntervalDTOList = new ArrayList<>();
        for (ActivityExtTimeInterval activityExtTimeInterval : activityExtTimeIntervalList) {
            ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO = new ActivityExtTimeIntervalDTO();
            activityExtTimeIntervalDTO.setActivityId(activityExtTimerList.get(0).getActivityId());
            activityExtTimeIntervalDTO.setCurrentProgress(activityExtTimerList.get(0).getCurrentProgress());
            activityExtTimeIntervalDTO.setCurrentTiming(activityExtTimerList.get(0).getCurrentTiming());
            activityExtTimeIntervalDTO.setCpf(activityExtTimerList.get(0).getCurrentProgress() / 1000 + "%");
            activityExtTimeIntervalDTO.setCtf(tf
                    .replace("{hh}", String.valueOf(int2String(activityExtTimerList.get(0).getCurrentTiming() / 3600)))
                    .replace("{mm}",String.valueOf(int2String(activityExtTimerList.get(0).getCurrentTiming() / 60 % 60)))
                    .replace("{ss}", String.valueOf(int2String(activityExtTimerList.get(0).getCurrentTiming() % 60))));


            activityExtTimeIntervalDTO.setId(activityExtTimeInterval.getId());
            activityExtTimeIntervalDTO.setpId(activityExtTimeInterval.getpId());
            activityExtTimeIntervalDTO.setS(activityExtTimeInterval.getS());
            activityExtTimeIntervalDTO.setT(activityExtTimeInterval.getT());
            activityExtTimeIntervalDTO.setTimerId(activityExtTimeInterval.getTimerId());

            activityExtTimeIntervalDTO.setSf(activityExtTimeInterval.getS() / 1000  + "%");

            activityExtTimeIntervalDTO.setTf(tf
                    .replace("{hh}", String.valueOf(int2String(activityExtTimeInterval.getT() / 3600)))
                    .replace("{mm}",String.valueOf(int2String(activityExtTimeInterval.getT() / 60 % 60)))
                    .replace("{ss}", String.valueOf(int2String(activityExtTimeInterval.getT() % 60))));

            activityExtTimeIntervalDTO.setModifyBtn(1);

            if (0 == activityExtTimeIntervalDTO.getpId()) {
                activityExtTimeIntervalDTO.setResetBtn(1);
            } else {
                activityExtTimeIntervalDTO.setResetBtn(0);
            }

            if (null == activityExtTimeIntervalMap.get(activityExtTimeIntervalDTO.getId())) {
                activityExtTimeIntervalDTO.setAddBtn(1);
                if (0 == activityExtTimeIntervalDTO.getpId()) {
                    activityExtTimeIntervalDTO.setDelBtn(0);
                } else {
                    activityExtTimeIntervalDTO.setDelBtn(1);
                }
            } else {
                activityExtTimeIntervalDTO.setAddBtn(0);
                activityExtTimeIntervalDTO.setDelBtn(0);
            }
            activityExtTimeIntervalDTOList.add(activityExtTimeIntervalDTO);
        }
        return activityExtTimeIntervalDTOList;
    }

    private String int2String (int i) {
        if (i >= 10) {
            return String.valueOf(i);
        }
        return "0"+i;
    }

    @Override
    public Integer getAnimationProgress(ActivityExtTimeIntervalSearchDTO activityExtTimeIntervalSearchDTO) {
        AssertUtil.isNull(activityExtTimeIntervalSearchDTO, "缺少参数");
        AssertUtil.isNull(activityExtTimeIntervalSearchDTO.getActivityId(), "缺少参数");

        ActivityExtTimerExample activityExtTimerExample = new ActivityExtTimerExample();
        activityExtTimerExample.createCriteria().andActivityIdEqualTo(activityExtTimeIntervalSearchDTO.getActivityId());
        List<ActivityExtTimer> activityExtTimerList = activityExtTimerMapper.selectByExample(activityExtTimerExample);
        if (null == activityExtTimerList || 0 >= activityExtTimerList.size()) {
            return null;
        }
        return activityExtTimerList.get(0).getCurrentProgress();
    }

    @Override
    public void calculationProgress(Integer activityId) {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        executor.scheduleWithFixedDelay(
            new Runnable() {
                @Override
                public void run() {
                    if (on) {
                        ActivityExtTimerExample example = new ActivityExtTimerExample();
                        example.createCriteria().andActivityIdEqualTo(activityId);
                        List<ActivityExtTimer> activityExtTimerList = activityExtTimerMapper.selectByExample(example);
                        if (null == activityExtTimerList || 0 >= activityExtTimerList.size()) {
                            executor.shutdown();
                        }
                        if (100000 == activityExtTimerList.get(0).getCurrentProgress()) {
                            executor.shutdown();
                        }

                        ActivityExtTimeIntervalExample activityExtTimeIntervalExample = new ActivityExtTimeIntervalExample();
                        activityExtTimeIntervalExample.createCriteria().andTimerIdEqualTo(activityExtTimerList.get(0).getId());
                        List<ActivityExtTimeInterval> activityExtTimeIntervalList = activityExtTimeIntervalMapper.selectByExample(activityExtTimeIntervalExample);
                        if (null == activityExtTimeIntervalList || 0 >= activityExtTimeIntervalList.size()) {
                            executor.shutdown();
                        }
                        int currentProgress = activityExtTimerList.get(0).getCurrentProgress();

                        int currentTiming = activityExtTimerList.get(0).getCurrentTiming();

                        Map<Integer, ActivityExtTimeInterval> activityExtTimeIntervalMap = new HashMap<>();
                        Map<Integer, ActivityExtTimeInterval> activityExtTimeIntervalMap1 = new HashMap<>();
                        for (ActivityExtTimeInterval activityExtTimeInterval : activityExtTimeIntervalList) {
                            activityExtTimeIntervalMap.put(activityExtTimeInterval.getpId(), activityExtTimeInterval);

                            activityExtTimeIntervalMap1.put(activityExtTimeInterval.getId(), activityExtTimeInterval);
                        }
                        ActivityExtTimeInterval activityExtTimeInterval = getActivityExtTimeInterval(currentTiming, activityExtTimeIntervalMap.get(0), activityExtTimeIntervalMap);
                        int sumCurrentTiming = getSumTiming(0, activityExtTimeInterval, activityExtTimeIntervalMap1);
                        int sumCurrentProgress = getSumProgress(0, activityExtTimeInterval, activityExtTimeIntervalMap1);
                        if (currentTiming + 1 == sumCurrentTiming) {
                            currentProgress = sumCurrentProgress;
                        } else {
                            currentProgress += Math.round(activityExtTimeInterval.getS() / activityExtTimeInterval.getT());
                        }

                        ActivityExtTimer record = activityExtTimerList.get(0);
                        record.setCurrentTiming(record.getCurrentTiming() + 1);
                        record.setCurrentProgress(currentProgress);
                        ActivityExtTimerExample activityExtTimerExample = new ActivityExtTimerExample();
                        activityExtTimerMapper.updateByExampleSelective(record, activityExtTimerExample);
                    }
                }
            }, 0, 1, TimeUnit.SECONDS);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delProgress(ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO) {
        AssertUtil.isNull(activityExtTimeIntervalDTO, "缺少参数");
        AssertUtil.isNull(activityExtTimeIntervalDTO.getId(), "缺少id参数");

        ActivityExtTimeInterval activityExtTimeInterval = activityExtTimeIntervalMapper.selectByPrimaryKey(activityExtTimeIntervalDTO.getId());
        if (null == activityExtTimeInterval) {
            return;
        }
        if (0 == activityExtTimeInterval.getpId()) {
            activityExtTimerMapper.deleteByPrimaryKey(activityExtTimeInterval.getTimerId());
        }
        activityExtTimeIntervalMapper.deleteByPrimaryKey(activityExtTimeIntervalDTO.getId());
    }

    @Override
    public void modifyProgress(ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO) {
        AssertUtil.isNull(activityExtTimeIntervalDTO, "缺少参数");
        AssertUtil.isNull(activityExtTimeIntervalDTO.getId(), "缺少id参数");

        ActivityExtTimeInterval record = new ActivityExtTimeInterval();
        record.setId(activityExtTimeIntervalDTO.getId());
        record.setT(activityExtTimeIntervalDTO.getT());
        record.setS(activityExtTimeIntervalDTO.getS());
        activityExtTimeIntervalMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    public ActivityExtTimeInterval getProgress(ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO) {

        AssertUtil.isNull(activityExtTimeIntervalDTO, "缺少参数");
        AssertUtil.isNull(activityExtTimeIntervalDTO.getId(), "缺少id参数");

        return activityExtTimeIntervalMapper.selectByPrimaryKey(activityExtTimeIntervalDTO.getId());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void resetProgress(ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO) {
        AssertUtil.isNull(activityExtTimeIntervalDTO, "缺少参数");
        AssertUtil.isNull(activityExtTimeIntervalDTO.getTimerId(), "缺少timerId参数");

        ActivityExtTimer activityExtTimer = activityExtTimerMapper.selectByPrimaryKey(activityExtTimeIntervalDTO.getTimerId());

        ActivityBaseInfo activityBaseInfo = activityBaseInfoMapper.selectByPrimaryKey(activityExtTimer.getActivityId());
        if ( null == activityBaseInfo
                ||  4 == activityBaseInfo.getStatus()) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "活动不存在");
        }
        switch (activityBaseInfo.getStatus()) {
            case 2:
                throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "活动已经结束");
        }

        ActivityExtTimer record = new ActivityExtTimer();
        record.setId(activityExtTimeIntervalDTO.getTimerId());
        record.setCurrentProgress(0);
        record.setCurrentTiming(0);
        activityExtTimerMapper.updateByPrimaryKeySelective(record);

        this.modifyStatus(activityExtTimer.getActivityId(), 1);
    }

    @Override
    public void onProgress() {
        on = true;
    }

    @Override
    public void offProgress() {
        on = false;
    }

    @Override
    public Integer getActivityPrizeId(Integer activityId) {

        ActivityPrizeInfoExample example = new ActivityPrizeInfoExample();
        example
                .createCriteria()
                .andStatusEqualTo(1)
                .andActivityIdEqualTo(activityId);
        List<ActivityPrizeInfo> activityPrizeInfoList = activityPrizeInfoMapper.selectByExample(example);

        if (null == activityPrizeInfoList || 0 >= activityPrizeInfoList.size()) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "没有有效的奖项");
        }
        return activityPrizeInfoList.get(0).getId();
    }

    @Override
    public void setLotteryDogNum(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        AssertUtil.isNull(activitySearchDTO.getActivityPrizeInfoExtId(), "缺少activityPrizeInfoExtId参数");
        ActivityPrizeInfoExample example = new ActivityPrizeInfoExample();
        example
                .createCriteria()
                .andStatusEqualTo(1)
                .andActivityIdEqualTo(activitySearchDTO.getActivityId());
        List<ActivityPrizeInfo> activityPrizeInfoList = activityPrizeInfoMapper.selectByExample(example);

        if (null == activityPrizeInfoList || 0 >= activityPrizeInfoList.size()) {
            decibelLotteryFlag = true;
        }
        if (!decibelLotteryFlag) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "没有执行抽取中奖人的操作");
        }
        if (decibelLotteryRunFlag) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "中奖人产生中...");
        }

        if (1 == activitySearchDTO.getActivityPrizeInfoExtId()) {
            if (lotteryDog666) {
                throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "请不要重复点击");
            }
            if (lotteryDog333) {
                throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "已经设置返回333");
            }
            if (lotteryDog333_) {
                throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "已经设置返回补充的333");
            }
            lotteryDog666 = true;

        } else if (2 == activitySearchDTO.getActivityPrizeInfoExtId()) {
            if (lotteryDog333) {
                throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "请不要重复点击");
            }
            if (lotteryDog666) {
                throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "已经设置返回666");
            }
            lotteryDog333 = true;
            lotteryDog333_ = false;
        } else if (3 == activitySearchDTO.getActivityPrizeInfoExtId()) {
            if (lotteryDog333_) {
                throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "请不要重复点击");
            }
            if (lotteryDog666) {
                throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "已经设置返回666");
            }
            lotteryDog333_ = true;
            lotteryDog333 = false;
        }
    }

    @Override
    public void end333(ActivitySearchDTO activitySearchDTO) {
        if (lotteryDog333) {
            lotteryDog333 = false;
        } else {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "请设置返回333");
        }

    }

    private ActivityExtTimeInterval getActivityExtTimeInterval (int currentTiming,
                                                                ActivityExtTimeInterval activityExtTimeInterval,
                                                                Map<Integer, ActivityExtTimeInterval> activityExtTimeIntervalMap) {
        currentTiming -= activityExtTimeInterval.getT();
        if (0 > currentTiming ) {
            return activityExtTimeInterval;
        } else {
            return getActivityExtTimeInterval(currentTiming,
                    activityExtTimeIntervalMap.get(activityExtTimeInterval.getId()),
                    activityExtTimeIntervalMap);
        }
    }

    private int getSumTiming(int sum ,ActivityExtTimeInterval activityExtTimeInterval,
                             Map<Integer, ActivityExtTimeInterval> activityExtTimeIntervalMap){
        sum += activityExtTimeInterval.getT();
        if (0 == activityExtTimeInterval.getpId()) {
            return sum ;
        } else {
           return getSumTiming(sum, activityExtTimeIntervalMap.get(activityExtTimeInterval.getpId()), activityExtTimeIntervalMap);
        }
    }
    private int getSumProgress(int sum ,ActivityExtTimeInterval activityExtTimeInterval,
                               Map<Integer, ActivityExtTimeInterval> activityExtTimeIntervalMap) {
        sum += activityExtTimeInterval.getS();
        if (0 == activityExtTimeInterval.getpId()) {
            return sum ;
        } else {
            return getSumProgress(sum, activityExtTimeIntervalMap.get(activityExtTimeInterval.getpId()), activityExtTimeIntervalMap);
        }
    }
}
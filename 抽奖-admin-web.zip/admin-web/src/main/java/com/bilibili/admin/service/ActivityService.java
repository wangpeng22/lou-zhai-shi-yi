package com.bilibili.admin.service;

import com.bilibili.admin.dto.*;
import com.bilibili.admin.model.*;

import java.util.List;
import java.util.Map;

/**
 * 活动服务
 * Created by wangpeng on 2018/12/19 17:50
 */
public interface ActivityService {

    /**
     * 活动列表
     * @param activitySearchDTO
     * @return
     */
    public List<ActivityDTO> list(ActivitySearchDTO activitySearchDTO);

    /**
     * 修改状态
     * @param activityId
     * @param status
     */
    public void modifyStatus(Integer activityId, int status);


    /**
     * 投票
     * @param activityUserVoteDTO
     */
    public void voting(ActivityUserVoteDTO activityUserVoteDTO);

    /**
     * 展示投票结果
     * @param activitySearchDTO
     * @param dp true:更新得票数记录，false:不更新得票数记录
     * @return
     */
    public ActivityVoteResultDTO displayVoting(ActivitySearchDTO activitySearchDTO, boolean dp);

    /**
     * 抽取投票活动的幸运儿
     * @param activitySearchDTO
     * @return
     */
    public void voteLottery(ActivitySearchDTO activitySearchDTO);

    /**
     * 获得幸运儿信息
     * @param activitySearchDTO
     * @return
     */
    public List<ActivityLuckyDogInfo> getActivityLuckyDogs(ActivitySearchDTO activitySearchDTO);

    /**
     * 除投票之外的其他活动抽奖
     * @param activitySearchDTO
     */
    public void otherLottery(ActivitySearchDTO activitySearchDTO);

    public void decibelLottery(ActivitySearchDTO activitySearchDTO);

    /**
     * 清空抽奖结果
     * @param activitySearchDTO
     */
    public void clearLottery(ActivitySearchDTO activitySearchDTO);

    public void clearDecibelLottery(ActivitySearchDTO activitySearchDTO);

    /**
     * 修改领奖标记
     * @param activityLuckyDogId 幸运儿Id
     * @param receiveFlag 1-没有领奖 2-已经领奖
     */
    public void modifyReceiveFlag(Integer activityLuckyDogId, int receiveFlag);

    /**
     * 抽奖活动详情
     * @param activitySearchDTO
     * @return
     */
    public ActivityVoteDTO getActivityVote(ActivitySearchDTO activitySearchDTO);

    /**
     * "我的奖品"
     * @param activitySearchDTO
     * @return
     */
    public List<ActivityPrizeWinningDTO> myPrize(ActivitySearchDTO activitySearchDTO);

    /**
     * 结束投票
     * @param activitySearchDTO
     */
    public void endVoting(ActivitySearchDTO activitySearchDTO);

    public ActivityBaseInfo getActivityBaseInfoByActivityId(Integer activityId);

    /**
     * 设置获胜队伍
     * @param activitySearchDTO
     */
    public void setWin(ActivitySearchDTO activitySearchDTO);

    /**
     * 查询获胜队伍
     * @param activitySearchDTO
     */
    public ActivityVoteWinDTO getWin(ActivitySearchDTO activitySearchDTO);

    /**
     * 大屏展示中奖名单
     * @param activitySearchDTO
     * @return
     */
    public Map<Integer, List<ActivityLuckyDogInfo>> getOtherLotteryDog(ActivitySearchDTO activitySearchDTO);


    public List<PrizeInfo> getPrize(ActivitySearchDTO activitySearchDTO);

    public ActivitySlotMachinesDTO getSlotMachinesInfo(ActivitySearchDTO activitySearchDTO);

    public void checkActivityVoteStatus(Integer activityId, Integer activityType, Integer status);

    public void modifyActivityPrizeStatus(Integer activityPrizeId, int status);

    public ActivityPrizeInfo getActivityPrizeInfoById(Integer activityPrizeId);

    public void modifyActivityPrizeStatusByActivityId(Integer activityId, int status);

    public void addProgress(ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO);

    public List<ActivityExtTimeIntervalDTO> listAnimationProgress(ActivityExtTimeIntervalSearchDTO activityExtTimeIntervalSearchDTO);

    public Integer getAnimationProgress(ActivityExtTimeIntervalSearchDTO activityExtTimeIntervalSearchDTO);

    public void calculationProgress(Integer activityId);

    public void delProgress(ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO);

    public void modifyProgress(ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO);

    public ActivityExtTimeInterval getProgress(ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO);

    public void resetProgress(ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO);

    public void onProgress();

    public void offProgress();

    public Integer getActivityPrizeId(Integer activityId);


    public void setLotteryDogNum(ActivitySearchDTO activitySearchDTO);

    public void end333(ActivitySearchDTO activitySearchDTO);
}

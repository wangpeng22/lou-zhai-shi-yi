package com.bilibili.admin.dto;

/**
 * 查询DTO 基类
 * Created by wangpeng on 2018/12/19 17:41
 */
public class SearchDTO extends BaseDTO {
    /**
     * 当前页码 从1开始
     */
    private Integer currentPage;

    /**
     * 每页条数
     */
    private Integer pageSize;

    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}

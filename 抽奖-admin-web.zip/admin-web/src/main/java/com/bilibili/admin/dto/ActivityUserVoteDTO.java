package com.bilibili.admin.dto;


import com.bilibili.admin.model.ActivityUserVote;

/**
 * Created by wangpeng on 2018/12/20 11:33
 */
public class ActivityUserVoteDTO extends ActivityUserVote {
}

package com.bilibili.admin.dto;

/**
 * 活动幸运儿DTO
 * Created by wangpeng on 2018/12/20 18:41
 */
public class ActivityLuckyDogDTO extends BaseDTO{

    // 姓名
    private String userName;
    // 部门
    private String userDepartmentName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserDepartmentName() {
        return userDepartmentName;
    }

    public void setUserDepartmentName(String userDepartmentName) {
        this.userDepartmentName = userDepartmentName;
    }
}

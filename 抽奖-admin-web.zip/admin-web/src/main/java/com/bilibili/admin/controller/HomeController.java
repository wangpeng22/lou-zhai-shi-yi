package com.bilibili.admin.controller;

import com.bilibili.admin.dto.AuthTokenDTO;
import com.bilibili.admin.jwt.AuthTokenDetails;
import com.bilibili.admin.jwt.JsonWebTokenUtility;
import com.bilibili.admin.model.RestResp;
import com.bilibili.admin.model.User;
import com.bilibili.admin.service.UserService;
import com.bilibili.admin.util.SessionUtil;
import com.bilibili.admin.vo.DataTable;
import com.bilibili.admin.vo.UserVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

/**
 * 用户控制器
 */
@RestController
@RequestMapping("/")
@Slf4j
public class HomeController {
    /**
     * 首页
     *
     *
     * @return
     */
    @RequestMapping(value = "/")
    public ModelAndView index() {
        //"forward:web/views/login/login.html"
       ModelAndView mv = new ModelAndView("redirect:/web/views/login/login.html");//redirect模式
       return mv;
    }
}

package com.bilibili.admin.dto;

import com.bilibili.admin.model.ActivityExtTimeInterval;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * Created by wangpeng on 2019/1/2 13:40
 */
@Repository
@Mapper
public class ActivityExtTimeIntervalDTO extends ActivityExtTimeInterval {

    // 活动Id
    private Integer activityId;

    // 当前计时，单位s
    private Integer currentTiming;

    // 当前计时
    private String ctf;

    // 当前进度（十万分之n）
    private Integer currentProgress;

    // 当前进度（百分之n）
    private String cpf;

    // 新增按钮 0-没有 1-有
    private Integer addBtn;

    // 修改按钮 0-没有 1-有
    private Integer modifyBtn;

    // 删除按钮 0-没有 1-有
    private Integer delBtn;

    // 重置按钮（将计时及进度清零） 0-没有 1-有
    private Integer resetBtn;

    // 进度间隔 (百分之n 即 s/1000)
    private String sf;

    // 时间间隔 时分秒
    private String tf;


    public Integer getResetBtn() {
        return resetBtn;
    }

    public void setResetBtn(Integer resetBtn) {
        this.resetBtn = resetBtn;
    }

    public String getTf() {
        return tf;
    }

    public void setTf(String tf) {
        this.tf = tf;
    }



    public Integer getAddBtn() {
        return addBtn;
    }

    public void setAddBtn(Integer addBtn) {
        this.addBtn = addBtn;
    }

    public Integer getModifyBtn() {
        return modifyBtn;
    }

    public void setModifyBtn(Integer modifyBtn) {
        this.modifyBtn = modifyBtn;
    }

    public Integer getDelBtn() {
        return delBtn;
    }

    public void setDelBtn(Integer delBtn) {
        this.delBtn = delBtn;
    }

    public Integer getCurrentTiming() {
        return currentTiming;
    }

    public void setCurrentTiming(Integer currentTiming) {
        this.currentTiming = currentTiming;
    }

    public Integer getCurrentProgress() {
        return currentProgress;
    }

    public void setCurrentProgress(Integer currentProgress) {
        this.currentProgress = currentProgress;
    }

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public String getCtf() {
        return ctf;
    }

    public void setCtf(String ctf) {
        this.ctf = ctf;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getSf() {
        return sf;
    }

    public void setSf(String sf) {
        this.sf = sf;
    }
}

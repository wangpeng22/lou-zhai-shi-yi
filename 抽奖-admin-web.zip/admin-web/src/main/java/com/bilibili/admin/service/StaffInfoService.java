package com.bilibili.admin.service;

import com.bilibili.admin.model.StaffDeptInfo;
import com.bilibili.admin.model.StaffInfo;
import com.bilibili.admin.model.User;
import com.bilibili.admin.vo.DataTable;

import java.util.List;


/**
 * 员工
 * @author xiaol
 */
public interface StaffInfoService {

    /**
     * 根据部门名称查询部门ID
     * @param deptName 部门名称
     * @return
     */
    StaffDeptInfo getDeptIdByDeptName(String deptName);

    /**
     * 将excel表格中的数据导入到数据库中
     * @param list
     */
    void importStaffInfo(List<StaffInfo> list);
    /**
     * 编辑员工信息
     */
    void editStaff(StaffInfo staffInfoa);

    /**
     * 条件查询员工信息
     * @param staffInfo
     * @return
     */
    DataTable<StaffInfo> listStaffInfo(StaffInfo staffInfo);
}

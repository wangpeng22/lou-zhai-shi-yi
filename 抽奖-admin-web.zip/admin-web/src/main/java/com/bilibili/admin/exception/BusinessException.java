package com.bilibili.admin.exception;

public class BusinessException extends RuntimeException {
	private static final long serialVersionUID = 5905485872074113652L;

	private int errCode;
	private String errMsg;

	public BusinessException(int errCode, String errMsg) {
		super(errMsg);
		this.errCode = errCode;
		this.errMsg = errMsg;
	}

	public int getErrCode() {
		return errCode;
	}

	public String getErrMsg() {
		return errMsg;
	}
}

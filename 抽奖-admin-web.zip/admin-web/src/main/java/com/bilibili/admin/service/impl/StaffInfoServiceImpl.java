package com.bilibili.admin.service.impl;

import com.bilibili.admin.mapper.StaffInfoMapper;
import com.bilibili.admin.model.StaffDeptInfo;
import com.bilibili.admin.model.StaffInfo;
import com.bilibili.admin.model.User;
import com.bilibili.admin.service.StaffInfoService;
import com.bilibili.admin.vo.DataTable;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service("StaffInfoService")
@Transactional
public class StaffInfoServiceImpl implements StaffInfoService {

    @javax.annotation.Resource
    private StaffInfoMapper staffInfoMapper;

    /**
     * 根据部门名称查询部门ID
     * @param deptName 部门名称
     * @return
     */
    @Override
    public StaffDeptInfo getDeptIdByDeptName(String deptName) {
        return staffInfoMapper.getDeptIdByDeptName(deptName);
    }
    /**
     * 将excel表格中的数据导入到数据库中
     * @param list
     */
    @Override
    public void importStaffInfo(List<StaffInfo> list) {
        staffInfoMapper.importStaffInfo(list);
    }

    /**
     * 编辑员工信息
     */
    @Override
    public void editStaff(StaffInfo staffInfoa) {
        staffInfoMapper.editStaff(staffInfoa);
    }

    /**
     * 条件查询员工信息
     * @param staffInfo
     * @return
     */
    @Override
    public DataTable<StaffInfo> listStaffInfo(StaffInfo staffInfo) {
        if (staffInfo.getStart()!=null && staffInfo.getLength() != null){
            PageHelper.offsetPage(staffInfo.getStart(), staffInfo.getLength());
            List<StaffInfo> users = staffInfoMapper.listStaffInfo(staffInfo);
            DataTable<StaffInfo> tables = new DataTable<>();
            tables.setRecordsTotal(((Page) users).getTotal());
            tables.setRecordsFiltered(tables.getRecordsTotal());
            tables.setDraw(staffInfo.getDraw());
            tables.setData(users);
            return tables;
        } else {
            List<StaffInfo> users = staffInfoMapper.listStaffInfo(staffInfo);
            DataTable<StaffInfo> tables = new DataTable<>();
            tables.setData(users);
            return tables;
        }
    }
}

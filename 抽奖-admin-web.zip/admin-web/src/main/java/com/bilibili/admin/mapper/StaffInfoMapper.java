package com.bilibili.admin.mapper;

import com.bilibili.admin.model.StaffDeptInfo;
import com.bilibili.admin.model.StaffInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.security.access.method.P;

import java.util.List;

/**
 * 员工操作Mapper
 */
@Mapper
public interface StaffInfoMapper{
    /**
     * 根据部门名称查询部门ID
     * @param deptName 部门名称
     * @return
     */
    StaffDeptInfo getDeptIdByDeptName(@Param("deptName") String deptName);
    /**
     * 将excel表格中的数据导入到数据库中
     * @param list
     */
    void importStaffInfo(@Param("list") List<StaffInfo> list);
    /**
     * 编辑员工信息
     * @param staffInfo
     * @return
     */
    void editStaff(@Param("staffInfo") StaffInfo staffInfo);

    /**
     * 条件查询员工信息
     * @param staffInfo
     * @return
     */
    List<StaffInfo> listStaffInfo(@Param("staffInfo") StaffInfo staffInfo);
}

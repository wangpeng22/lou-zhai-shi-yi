package com.bilibili.admin.dto;

import com.bilibili.admin.model.ActivityBaseInfo;
import com.bilibili.admin.model.ActivityPrizeInfo;

/**
 * Created by wangpeng on 2018/12/27 13:54
 */
public class ActivitySlotMachinesDTO extends BaseDTO{

    // 活动详情
    private ActivityBaseInfo activityBaseInfo;

    // 奖项详情
    private ActivityPrizeInfo activityPrizeInfo;

    public ActivityBaseInfo getActivityBaseInfo() {
        return activityBaseInfo;
    }

    public void setActivityBaseInfo(ActivityBaseInfo activityBaseInfo) {
        this.activityBaseInfo = activityBaseInfo;
    }

    public ActivityPrizeInfo getActivityPrizeInfo() {
        return activityPrizeInfo;
    }

    public void setActivityPrizeInfo(ActivityPrizeInfo activityPrizeInfo) {
        this.activityPrizeInfo = activityPrizeInfo;
    }
}

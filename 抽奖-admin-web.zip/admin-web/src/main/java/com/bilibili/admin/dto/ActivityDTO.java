package com.bilibili.admin.dto;

import com.bilibili.admin.model.ActivityBaseInfo;
import com.bilibili.admin.model.ActivityUserVote;
import com.bilibili.admin.model.ActivityVoteInfo;

import java.util.List;

/**
 * 活动DTO
 * Created by wangpeng on 2018/12/19 18:26
 */
public class ActivityDTO extends ActivityBaseInfo {

    public static ActivityDTO transfer(ActivityBaseInfo baseInfo) {
        if (null == baseInfo) {
            return null;
        }
        ActivityDTO activityDTO = new ActivityDTO();
        activityDTO.setId(baseInfo.getId());
        activityDTO.setActivityName(baseInfo.getActivityName());
        activityDTO.setActivityDesc(baseInfo.getActivityDesc());
        activityDTO.setStatus(baseInfo.getStatus());
        activityDTO.setActivityType(baseInfo.getActivityType());
        return activityDTO;
    }

    // 投票队伍
    private List<ActivityVoteInfo> activityVoteInfoList;

    // 奖项
    private List<ActivityPrizeDTO> activityPrizeDTOList;

    // 用户投票情况
    private ActivityUserVote activityUserVote;

    public ActivityUserVote getActivityUserVote() {
        return activityUserVote;
    }

    public void setActivityUserVote(ActivityUserVote activityUserVote) {
        this.activityUserVote = activityUserVote;
    }

    public List<ActivityPrizeDTO> getActivityPrizeDTOList() {
        return activityPrizeDTOList;
    }

    public void setActivityPrizeDTOList(List<ActivityPrizeDTO> activityPrizeDTOList) {
        this.activityPrizeDTOList = activityPrizeDTOList;
    }

    public List<ActivityVoteInfo> getActivityVoteInfoList() {
        return activityVoteInfoList;
    }

    public void setActivityVoteInfoList(List<ActivityVoteInfo> activityVoteInfoList) {
        this.activityVoteInfoList = activityVoteInfoList;
    }
}

/**
 * Created by bzyx on 2018-12-19
 */
package com.bilibili.admin.mapper;

import com.bilibili.admin.model.ParkInfo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ParkInfoMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ParkInfo record);

    int insertSelective(ParkInfo record);

    ParkInfo selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ParkInfo record);

    int updateByPrimaryKey(ParkInfo record);

    List<ParkInfo> findAllParkInfo();
}
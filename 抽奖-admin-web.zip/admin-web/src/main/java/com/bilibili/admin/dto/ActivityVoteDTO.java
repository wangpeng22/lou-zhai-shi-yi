package com.bilibili.admin.dto;


import com.bilibili.admin.model.ActivityBaseInfo;
import com.bilibili.admin.model.ActivityUserVote;
import com.bilibili.admin.model.ActivityVoteInfo;

import java.util.List;

/**
 * 投票活动DTO
 * Created by wangpeng on 2018/12/20 15:00
 */
public class ActivityVoteDTO extends BaseDTO {
    // 活动详情
    private ActivityBaseInfo activityBaseInfo;
    // 战队详情
    private List<ActivityVoteInfo> activityVoteInfoList;
    // 投票详情(没有投票之前这个对象为null)
    private ActivityUserVote activityUserVote;

    public ActivityBaseInfo getActivityBaseInfo() {
        return activityBaseInfo;
    }

    public void setActivityBaseInfo(ActivityBaseInfo activityBaseInfo) {
        this.activityBaseInfo = activityBaseInfo;
    }

    public List<ActivityVoteInfo> getActivityVoteInfoList() {
        return activityVoteInfoList;
    }

    public void setActivityVoteInfoList(List<ActivityVoteInfo> activityVoteInfoList) {
        this.activityVoteInfoList = activityVoteInfoList;
    }

    public ActivityUserVote getActivityUserVote() {
        return activityUserVote;
    }

    public void setActivityUserVote(ActivityUserVote activityUserVote) {
        this.activityUserVote = activityUserVote;
    }
}

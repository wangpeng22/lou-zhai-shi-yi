package com.bilibili.admin.dto;

import com.bilibili.admin.model.ActivityVoteInfo;

/**
 * Created by wangpeng on 2018/12/27 11:35
 */
public class ActivityVoteWinDTO extends ActivityVoteInfo {

    public static ActivityVoteWinDTO transfer(ActivityVoteInfo activityVoteInfo) {
        if (null == activityVoteInfo) {
            return null;
        }
        ActivityVoteWinDTO activityVoteWinDTO = new ActivityVoteWinDTO();
        activityVoteWinDTO.setId(activityVoteInfo.getId());
        activityVoteWinDTO.setActivityId(activityVoteInfo.getActivityId());
        activityVoteWinDTO.setVoteName(activityVoteInfo.getVoteName());
        activityVoteWinDTO.setVoteNumber(activityVoteInfo.getVoteNumber());
        activityVoteWinDTO.setWinFlag(activityVoteInfo.getWinFlag());
        return activityVoteWinDTO;
    }

    private Integer activityPrizeId;

    public Integer getActivityPrizeId() {
        return activityPrizeId;
    }

    public void setActivityPrizeId(Integer activityPrizeId) {
        this.activityPrizeId = activityPrizeId;
    }
}

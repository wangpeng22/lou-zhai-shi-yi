package com.bilibili.admin.controller;

import com.bilibili.admin.core.Result;
import com.bilibili.admin.core.ResultCode;
import com.bilibili.admin.core.ResultGenerator;
import com.bilibili.admin.dto.*;
import com.bilibili.admin.exception.BusinessException;
import com.bilibili.admin.model.ActivityBaseInfo;
import com.bilibili.admin.model.ActivityExtTimeInterval;
import com.bilibili.admin.model.ActivityLuckyDogInfo;
import com.bilibili.admin.service.ActivityService;
import com.bilibili.admin.util.AssertUtil;
import com.bilibili.admin.vo.DataTable;
import com.bilibili.admin.vo.OtherActivityVO;
import com.bilibili.admin.vo.VoteActivityVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 活动控制器（接口提供给后台管理系统）
 * Created by wangpeng on 2018/12/19 17:04
 */
@RestController
@RequestMapping("/console/activity")
public class ActivityConsoleController {

    private volatile static boolean calculation_progress_flag = true; // 标记是否已经开始动画 true:没有 false:有 清空结果的时候calculation_progress_flag=true

    private volatile static boolean flag = true; // 标记是否进行过分贝抽奖 ， true:没有 false:有 清空结果的时候flag=true

    @Autowired
    private ActivityService activityService;


    @RequestMapping(value = "/listvote", method = RequestMethod.POST)
    @ResponseBody
    private DataTable<VoteActivityVO> listVote() {
        // 前提： 一个抽奖活动 对应 一个奖项 对应 两个战队
        DataTable<VoteActivityVO> dataTable = new DataTable();
        List<VoteActivityVO> voteActivityVOList = new ArrayList<>();
        ActivitySearchDTO activitySearchDTO = new ActivitySearchDTO();
        activitySearchDTO.setActivityType(1);
        List<ActivityDTO> activityDTOList = activityService.list(activitySearchDTO);
        if (null != activityDTOList && 0 < activityDTOList.size()) {
            for (ActivityDTO activityDTO : activityDTOList) {
                VoteActivityVO voteActivityVO = new VoteActivityVO();
                voteActivityVO.setActivityId(activityDTO.getId());
                voteActivityVO.setActivityName(activityDTO.getActivityName());
                voteActivityVO.setStatus(activityDTO.getStatus());
                if (null != activityDTO.getActivityPrizeDTOList()
                        && 1 == activityDTO.getActivityPrizeDTOList().size() ){
                    voteActivityVO.setActivityPrizeId(activityDTO.getActivityPrizeDTOList().get(0).getId());
                }
                if (null != activityDTO.getActivityVoteInfoList()
                        && 2 == activityDTO.getActivityVoteInfoList().size()) {

                    voteActivityVO.setVoteId1(activityDTO.getActivityVoteInfoList().get(0).getId());
                    voteActivityVO.setVoteName1(activityDTO.getActivityVoteInfoList().get(0).getVoteName());
                    voteActivityVO.setVoteNumber1(activityDTO.getActivityVoteInfoList().get(0).getVoteNumber());

                    voteActivityVO.setVoteId2(activityDTO.getActivityVoteInfoList().get(1).getId());
                    voteActivityVO.setVoteName2(activityDTO.getActivityVoteInfoList().get(1).getVoteName());
                    voteActivityVO.setVoteNumber2(activityDTO.getActivityVoteInfoList().get(1).getVoteNumber());
                }
                voteActivityVOList.add(voteActivityVO);
            }
        }
        dataTable.setData(voteActivityVOList);
        dataTable.setRecordsTotal(Long.valueOf(null == voteActivityVOList ? 0 : voteActivityVOList.size()));
        dataTable.setRecordsFiltered(Long.valueOf(null == voteActivityVOList ? 0 : voteActivityVOList.size()));
        return dataTable;
    }

    /**
     * 等待投票 (节目开始)
     * @param activitySearchDTO
     * @return
     */
    @RequestMapping(value = "/waitvoting", method = RequestMethod.POST)
    @ResponseBody
    public Result waitVoting (@RequestBody ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        activityService.checkActivityVoteStatus(activitySearchDTO.getActivityId(), 1,6);
        activityService.modifyStatus(activitySearchDTO.getActivityId(), 6);
        return ResultGenerator.genSuccessResult();
    }

    /**
     * 开始投票
     * @param activitySearchDTO
     * @return
     */
    @RequestMapping(value = "/beginvoting", method = RequestMethod.POST)
    @ResponseBody
    public Result beginVoting (@RequestBody ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        activityService.checkActivityVoteStatus(activitySearchDTO.getActivityId(), 1,7);
        activityService.modifyStatus(activitySearchDTO.getActivityId(), 7);
        return ResultGenerator.genSuccessResult();
    }

    /**
     * 结束投票
     * @param activitySearchDTO
     * @return
     */
    @RequestMapping(value = "/endvoting", method = RequestMethod.POST)
    @ResponseBody
    public Result endVoting (@RequestBody ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        activityService.checkActivityVoteStatus(activitySearchDTO.getActivityId(), 1,8);
        activityService.endVoting(activitySearchDTO);
        return ResultGenerator.genSuccessResult();
    }

    /**
     * 设置获胜队伍
     * @param activitySearchDTO
     * @return
     */
    @RequestMapping(value = "/setwin", method = RequestMethod.POST)
    @ResponseBody
    public Result setWin (@RequestBody ActivitySearchDTO activitySearchDTO) {
        activityService.setWin(activitySearchDTO);
        return ResultGenerator.genSuccessResult();
    }

    @RequestMapping(value = "/otherlotterydogs", method = RequestMethod.POST)
    @ResponseBody
    public DataTable<ActivityLuckyDogInfo> otherLotteryDogs (@RequestBody ActivitySearchDTO activitySearchDTO) {
        DataTable<ActivityLuckyDogInfo> dataTable = new DataTable<>();
        activitySearchDTO.setActivityTypeList(Arrays.asList(2, 3, 4, 5));
        List<ActivityLuckyDogInfo> activityLuckyDogDTOList = activityService.getActivityLuckyDogs(activitySearchDTO);
        dataTable.setData(activityLuckyDogDTOList);
        dataTable.setRecordsTotal(Long.valueOf(null == activityLuckyDogDTOList ? 0 :activityLuckyDogDTOList.size()));
        dataTable.setRecordsFiltered(Long.valueOf(null == activityLuckyDogDTOList ? 0 :activityLuckyDogDTOList.size()));
        return dataTable;
    }

    @RequestMapping(value = "/votelotterydog", method = RequestMethod.POST)
    @ResponseBody
    public DataTable<ActivityLuckyDogInfo> voteLotteryDog (@RequestBody ActivitySearchDTO activitySearchDTO) {
        DataTable<ActivityLuckyDogInfo> dataTable = new DataTable<>();
        activitySearchDTO.setActivityType(1);
        List<ActivityLuckyDogInfo> activityLuckyDogDTOList = activityService.getActivityLuckyDogs(activitySearchDTO);
        dataTable.setData(activityLuckyDogDTOList);
        dataTable.setRecordsTotal(Long.valueOf(null == activityLuckyDogDTOList ? 0 : activityLuckyDogDTOList.size()));
        dataTable.setRecordsFiltered(Long.valueOf(null == activityLuckyDogDTOList ? 0 : activityLuckyDogDTOList.size()));
        return dataTable;
    }


    /**
     * 其他活动（activityType = 2 、activityType = 3 ）列表
     * @return
     */
    @RequestMapping(value = "/listother", method = RequestMethod.POST)
    @ResponseBody
    private DataTable<OtherActivityVO> listOther() {
        // 前提 : 一个奖项对应一个奖品
        DataTable<OtherActivityVO> dataTable = new DataTable<>();
        List<OtherActivityVO> otherActivityVOList = new ArrayList<>();
        ActivitySearchDTO activitySearchDTO = new ActivitySearchDTO();
        activitySearchDTO.setActivityType(2);
        List<ActivityDTO> activityDTOList2 = activityService.list(activitySearchDTO);
        this.addOtherActivityVOList(otherActivityVOList, activityDTOList2);

        activitySearchDTO.setActivityType(3);
        List<ActivityDTO> activityDTOList3 = activityService.list(activitySearchDTO);
        this.addOtherActivityVOList(otherActivityVOList, activityDTOList3);

        activitySearchDTO.setActivityType(4);
        List<ActivityDTO> activityDTOList4 = activityService.list(activitySearchDTO);
        this.addOtherActivityVOList(otherActivityVOList, activityDTOList4);


        activitySearchDTO.setActivityType(5);
        List<ActivityDTO> activityDTOList5 = activityService.list(activitySearchDTO);
        this.addOtherActivityVOList(otherActivityVOList, activityDTOList5);

        dataTable.setData(otherActivityVOList);
        return dataTable;
    }

    private void addOtherActivityVOList(List<OtherActivityVO> otherActivityVOList,
                                        List<ActivityDTO> activityDTOList) {
        if (null != activityDTOList && 0 < activityDTOList.size()) {
            for (ActivityDTO activityDTO : activityDTOList) {

                if (2 == activityDTO.getActivityType()) {
                    OtherActivityVO otherActivityVO1 = new OtherActivityVO();
                    otherActivityVO1.setActivityId(activityDTO.getId());
                    otherActivityVO1.setActivityName(activityDTO.getActivityName());
                    otherActivityVO1.setActivityType(activityDTO.getActivityType());
                    otherActivityVO1.setShowLotteryDog(0);
                    otherActivityVO1.setShowLotteryDog(0);
                    otherActivityVOList.add(otherActivityVO1);
                }
                if (3 == activityDTO.getActivityType()
                        || 4 == activityDTO.getActivityType()
                        || 5 == activityDTO.getActivityType()) {
                    OtherActivityVO otherActivityVO2 = new OtherActivityVO();
                    otherActivityVO2.setActivityId(activityDTO.getId());
                    otherActivityVO2.setActivityName(activityDTO.getActivityName());
                    if (3 == activityDTO.getActivityType() ) {
                        otherActivityVO2.setShowLotteryDog(1);
                        otherActivityVO2.setActivityType(activityDTO.getActivityType());
                        otherActivityVO2.setShowLottery(1);
                    } else if (4 == activityDTO.getActivityType()) {
                        otherActivityVO2.setShowLotteryDog(0);
                        otherActivityVO2.setActivityType(activityDTO.getActivityType());
                        otherActivityVO2.setShowLottery(1);
                    }else {
                        otherActivityVO2.setShowLotteryDog(0);
                        otherActivityVO2.setShowLottery(0);
                    }
                    otherActivityVO2.setShowClear(0);
                    otherActivityVOList.add(otherActivityVO2);
                }

                if (null != activityDTO.getActivityPrizeDTOList() && 0 < activityDTO.getActivityPrizeDTOList().size()) {
                    for (ActivityPrizeDTO activityPrizeDTO : activityDTO.getActivityPrizeDTOList()) {
                        OtherActivityVO otherActivityVO = new OtherActivityVO();

                        if (5 == activityDTO.getActivityType()) {
                            otherActivityVO.setActivityId(activityDTO.getId());
                            otherActivityVO.setActivityType(activityDTO.getActivityType());
                            otherActivityVO.setShowLottery(1);
                            otherActivityVO.setShowClear(1);
                        }

                        if (4 == activityDTO.getActivityType()
                                || 3 == activityDTO.getActivityType()) {
                            otherActivityVO.setActivityId(activityDTO.getId());
                            otherActivityVO.setActivityType(activityDTO.getActivityType());
                            otherActivityVO.setShowClear(1);
                            otherActivityVO.setShowLottery(0);
                        }

                        otherActivityVO.setActivityPrizeId(activityPrizeDTO.getId());
                        otherActivityVO.setActivityPrizeName(activityPrizeDTO.getActivityPrizeName());
                        otherActivityVO.setActivityPrizeWinningNumber(activityPrizeDTO.getActivityPrizeWinningNumber());

                        if (null != activityPrizeDTO.getPrizeInfoList()
                                && 1 == activityPrizeDTO.getPrizeInfoList().size()) {
                            // 一个奖项对应一个奖品
                            otherActivityVO.setPrizeId(activityPrizeDTO.getPrizeInfoList().get(0).getId());
                            otherActivityVO.setPrizeName(activityPrizeDTO.getPrizeInfoList().get(0).getPrizeName());
                        }
                        otherActivityVOList.add(otherActivityVO);
                    }
                }
            }
        }
    }

    // 新增活动动画进度
    @RequestMapping(value = "/addprogress", method = RequestMethod.POST)
    @ResponseBody
    public Result addProgress (@RequestBody ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO) {
        activityService.addProgress(activityExtTimeIntervalDTO);
        return ResultGenerator.genSuccessResult();
    }

    // 查询进度
    @RequestMapping(value = "/getprogress", method = RequestMethod.POST)
    @ResponseBody
    public Result getProgress (@RequestBody ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO) {
        ActivityExtTimeInterval activityExtTimeInterval = activityService.getProgress(activityExtTimeIntervalDTO);
        return ResultGenerator.genSuccessResult(activityExtTimeInterval);
    }

    // 修改进度
    @RequestMapping(value = "/modifyprogress", method = RequestMethod.POST)
    @ResponseBody
    public Result modifyProgress (@RequestBody ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO) {
        activityService.modifyProgress(activityExtTimeIntervalDTO);
        return ResultGenerator.genSuccessResult();
    }

    // 查询活动动画进度
    @RequestMapping(value = "/listanimationprogress", method = RequestMethod.POST)
    @ResponseBody
    public DataTable<ActivityExtTimeIntervalDTO> listAnimationProgress (@RequestBody ActivityExtTimeIntervalSearchDTO activityExtTimeIntervalSearchDTO) {
        DataTable<ActivityExtTimeIntervalDTO> dataTable = new DataTable<>();
        List<ActivityExtTimeIntervalDTO> activityExtTimeIntervalDTOList = activityService.listAnimationProgress(activityExtTimeIntervalSearchDTO);
        dataTable.setData(activityExtTimeIntervalDTOList);
        dataTable.setRecordsTotal(Long.valueOf(null == activityExtTimeIntervalDTOList ? 0 : activityExtTimeIntervalDTOList.size()));
        dataTable.setRecordsFiltered(Long.valueOf(null == activityExtTimeIntervalDTOList ? 0 : activityExtTimeIntervalDTOList.size()));
        return dataTable;
    }

    // 删除进度
    @RequestMapping(value = "/delprogress", method = RequestMethod.POST)
    @ResponseBody
    public Result delProgress (@RequestBody ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO) {
        activityService.delProgress(activityExtTimeIntervalDTO);
        return ResultGenerator.genSuccessResult();
    }

    // 开始动画
    @RequestMapping(value = "/playanimation", method = RequestMethod.POST)
    @ResponseBody
    public Result playAnimation (@RequestBody ActivitySearchDTO activitySearchDTO){

        if (!calculation_progress_flag) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "不要重复点击！");
        }

        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        ActivityBaseInfo activityBaseInfo = activityService.getActivityBaseInfoByActivityId(activitySearchDTO.getActivityId());

        if (null == activityBaseInfo || 4 == activityBaseInfo.getStatus()) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "活动不存在！");
        }
        if (2 == activityBaseInfo.getStatus()) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "活动已经结束！");
        }
        if (5 == activityBaseInfo.getStatus()) {
            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "不要重复点击！");
        }
        //开启 计算动画进度
        activityService.calculationProgress(activitySearchDTO.getActivityId());
        activityService.modifyStatus(activitySearchDTO.getActivityId(), 5);

        calculation_progress_flag = false;
        return ResultGenerator.genSuccessResult();
    }

    // 重置进度
    @RequestMapping(value = "/resetprogress", method = RequestMethod.POST)
    @ResponseBody
    public Result resetProgress (@RequestBody ActivityExtTimeIntervalDTO activityExtTimeIntervalDTO) {
        calculation_progress_flag = true;
        activityService.resetProgress(activityExtTimeIntervalDTO);
        return ResultGenerator.genSuccessResult();
    }

    // 开进度
    @RequestMapping(value = "/onprogress", method = RequestMethod.POST)
    @ResponseBody
    public Result onProgress () {
        activityService.onProgress();
        return ResultGenerator.genSuccessResult();
    }
    // 关进度
    @RequestMapping(value = "/offprogress", method = RequestMethod.POST)
    @ResponseBody
    public Result offProgress () {
        activityService.offProgress();
        return ResultGenerator.genSuccessResult();
    }

    // 分贝抽奖
    @RequestMapping(value = "/decibellottery", method = RequestMethod.POST)
    @ResponseBody
    public Result  decibelLottery (@RequestBody ActivitySearchDTO activitySearchDTO) {
        //if (flag) {
            activityService.decibelLottery(activitySearchDTO);
          //  flag = false;
//        } else {
//            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "不要重复点击！");
//        }
        return ResultGenerator.genSuccessResult();
    }


    // 设置返回666还是333抑或补充的333
    @RequestMapping(value = "/setlotterydognum", method = RequestMethod.POST)
    @ResponseBody
    public Result setLotteryDogNum (@RequestBody ActivitySearchDTO activitySearchDTO) {
        activityService.setLotteryDogNum(activitySearchDTO);
        return ResultGenerator.genSuccessResult();
    }


    @RequestMapping(value = "/end333", method = RequestMethod.POST)
    @ResponseBody
    public Result end333 (@RequestBody ActivitySearchDTO activitySearchDTO) {
        activityService.end333(activitySearchDTO);
        return ResultGenerator.genSuccessResult();
    }

    // 清空抽奖结果
    @RequestMapping(value = "/clearlottery", method = RequestMethod.POST)
    @ResponseBody
    public Result  clearLottery (@RequestBody ActivitySearchDTO activitySearchDTO) {
        activityService.clearLottery(activitySearchDTO);
        // flag = true;
        // calculation_progress_flag = true;
        return ResultGenerator.genSuccessResult();
    }

    // 清空抽奖结果
    @RequestMapping(value = "/cleardecibellottery", method = RequestMethod.POST)
    @ResponseBody
    public Result  clearDecibelLottery (@RequestBody ActivitySearchDTO activitySearchDTO) {
        activityService.clearDecibelLottery(activitySearchDTO);
        // flag = true;
        // calculation_progress_flag = true;
        return ResultGenerator.genSuccessResult();
    }






    // 领取奖品
    @RequestMapping(value = "/receiveprize", method = RequestMethod.POST)
    @ResponseBody
    public Result receivePrize (@RequestBody ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityLuckyDogId(), "缺少activityLuckyDogId参数");
        activityService.modifyReceiveFlag(activitySearchDTO.getActivityLuckyDogId(), 2);
        return ResultGenerator.genSuccessResult();
    }

    // 撤销领取奖品
    @RequestMapping(value = "/cancelprize", method = RequestMethod.POST)
    @ResponseBody
    public Result cancelPrize (@RequestBody ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityLuckyDogId(), "缺少activityLuckyDogId参数");
        activityService.modifyReceiveFlag(activitySearchDTO.getActivityLuckyDogId(), 1);
        return ResultGenerator.genSuccessResult();
    }



    // 分贝抽奖推送活动结果
    @RequestMapping(value = "/end", method = RequestMethod.POST)
    @ResponseBody
    public Result end(@RequestBody ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        // 奖项状态修改为 推送到中奖人
        activityService.modifyActivityPrizeStatusByActivityId(activitySearchDTO.getActivityId(), 4);
        // 活动状态改为 活动已结束
        // activityService.modifyStatus(activitySearchDTO.getActivityId(), 2);
        return ResultGenerator.genSuccessResult();
    }

    // 开启抽奖
    @RequestMapping(value = "/openlottery", method = RequestMethod.POST)
    @ResponseBody
    public Result openLottery(@RequestBody ActivitySearchDTO activitySearchDTO) {
        //修改奖项状态为开始抽奖
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityPrizeId(), "缺少activityPrizeId参数");
        activityService.modifyActivityPrizeStatus(activitySearchDTO.getActivityPrizeId(), 2);
        return ResultGenerator.genSuccessResult();
    }
}
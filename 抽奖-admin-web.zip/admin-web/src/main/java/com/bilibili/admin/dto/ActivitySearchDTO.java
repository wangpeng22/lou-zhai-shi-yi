package com.bilibili.admin.dto;

import java.util.List;

/**
 * 活动查询DTO
 * Created by wangpeng on 2018/12/19 17:42
 */
public class ActivitySearchDTO extends SearchDTO {

    // 活动类型
    private Integer activityType;

    // 活动Id
    private Integer activityId;

    // 用户Id
    private Integer userId;

    // 战队Id
    private Integer voteId;

    // 奖项Id
    private Integer activityPrizeId;

    // 部门Id
    private Integer departmentId;

    // 部门Id
    private String departmentName;

    // 用户名
    private String userName;

    // 幸运儿Id
    private Integer activityLuckyDogId;

    private List<Integer> activityTypeList;

    private String activityName;

    private String prizeName;
    
    // 奖项状态
    private Integer prizeStatus;

    // 1-抽取666 2-抽取333 3-再次抽取333
    private Integer activityPrizeInfoExtId;

    public Integer getActivityPrizeInfoExtId() {
        return activityPrizeInfoExtId;
    }

    public void setActivityPrizeInfoExtId(Integer activityPrizeInfoExtId) {
        this.activityPrizeInfoExtId = activityPrizeInfoExtId;
    }

    public Integer getPrizeStatus() {
        return prizeStatus;
    }

    public void setPrizeStatus(Integer prizeStatus) {
        this.prizeStatus = prizeStatus;
    }

    public String getPrizeName() {
        return prizeName;
    }

    public void setPrizeName(String prizeName) {
        this.prizeName = prizeName;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public List<Integer> getActivityTypeList() {
        return activityTypeList;
    }

    public void setActivityTypeList(List<Integer> activityTypeList) {
        this.activityTypeList = activityTypeList;
    }

    public Integer getActivityLuckyDogId() {
        return activityLuckyDogId;
    }

    public void setActivityLuckyDogId(Integer activityLuckyDogId) {
        this.activityLuckyDogId = activityLuckyDogId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }


    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public Integer getActivityPrizeId() {
        return activityPrizeId;
    }

    public void setActivityPrizeId(Integer activityPrizeId) {
        this.activityPrizeId = activityPrizeId;
    }

    public Integer getVoteId() {
        return voteId;
    }

    public void setVoteId(Integer voteId) {
        this.voteId = voteId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public Integer getActivityType() {
        return activityType;
    }

    public void setActivityType(Integer activityType) {
        this.activityType = activityType;
    }
}

package com.bilibili.admin.util;

import com.bilibili.admin.core.ResultCode;
import com.bilibili.admin.exception.BusinessException;

import java.util.List;

/**
 * 断言工具
 * Created by wangpeng on 2018/12/19 18:36
 */
public class AssertUtil {
    public static void isNull(Object o, String msg) throws BusinessException {
        if (null == o) {
            throw new BusinessException(ResultCode.MISSINGARGS.getCode(), null == msg || "".equals(msg) ? "参数为空" : msg);
        }
    }

    public static void isNull(Object o, String s, String msg) throws BusinessException {
        if (null == o
                || null == s
                || "".equals(s)) {
            throw new BusinessException(ResultCode.MISSINGARGS.getCode(), null == msg || "".equals(msg) ? "参数为空" : msg);
        }
    }

    public static void isEmpty(String s, String msg) throws BusinessException {
        if (null == s) {
            throw new BusinessException(ResultCode.MISSINGARGS.getCode(), null == msg || "".equals(msg) ? "参数为空串" : msg);
        }
    }

    public static void isNotPositiveInteger(Integer i, String msg) throws BusinessException {
        if (null == i
                || 0 >= i
                || Integer.MAX_VALUE < i) {
            throw new BusinessException(ResultCode.MISSINGARGS.getCode(), null == msg || "".equals(msg) ? "参数不是正整数" : msg);
        }
    }

    public static void isNull(List o, String msg) throws BusinessException {
        if (null == o
                && 0 >= o.size()) {
            throw new BusinessException(ResultCode.MISSINGARGS.getCode(), null == msg || "".equals(msg) ? "参数为空" : msg);
        }
    }
}

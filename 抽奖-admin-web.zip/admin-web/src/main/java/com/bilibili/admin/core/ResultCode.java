package com.bilibili.admin.core;

/**
 * 响应码枚举，参考HTTP状态码的语义
 * @author
 * @date 2018-12-18 16:08:27
 */
public enum ResultCode {
    ACTIVITY_ERR(8005, "活动错误"),
    ACTIVITY_LOTTERY_OPEN(8004, "活动已经开奖"),
    ACTIVITY_VOTED(8003, "活动已经投票"),
    ACTIVITY_END(8002, "活动已经结束"),
    ACTIVITY_NOT_BEGIN(8001, "活动没有开始"),
    ACTIVITY_NOT_EXIST(8000, "活动不存在"),

    NOT_LOGGED_IN(1, "未登录"),

    SUCCESS(200,"请求成功"),//成功
    FAIL(400,"请求的地址不存在或者包含不支持的参数"),//失败
    UNAUTHORIZED(401,"未授权"),//未认证（签名错误）
    NOT_FOUND(404,"请求的资源不存在"),//接口不存在
    INTERNAL_SERVER_ERROR(500,"服务器内部错误"),//服务器内部错误
    RPC_ERROR(503,"RPC服务异常，请联系管理员"),//RPC异常
    UNKNOWERROR(999,"未知错误"),
    NEEDPERMISSION(1000,"需要权限"),
    URINOTFOUND(1001,"资源不存在"),
    MISSINGARGS(1002,"参数不全"),
    HASBADWORD(1003,"输入有违禁词"),
    IMAGETOOLARGE(1004,"上传的图片太大"),
    INPUTTOOSHORT(1005,"输入内容太短"),
    INPUTTOOLONG(1006,"输入内容太长"),
    TARGETNOTFOUNF(1007,"目标对象不存在"),
    NEEDCAPTCHA(1008,"需要验证码"),
    IMGAGEUNKNOW(1009,"图片未知错误"),
    IMAGEWRONGFORMAT(1010,"照片格式有误(仅支持JPG,JPEG,GIF,PNG或BMP)"),
    INVALID_USERNAME_PASSWORD(1011, "用户名或密码错误"),
    SYSTEMNEEDLOG(1012,"请添加记录日志信息"),
    DATAISNULL(1022,"表格数据为空"),
    FILEISNULL(1024,"上传文件为空");

    private  int code;
    private  String msg;

    ResultCode(int code) {
        this.code = code;
    }
    ResultCode(int code,String msg) {
        this.code = code;
        this.msg=msg;
    }

    public int code() {
        return code;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}

package com.bilibili.admin.vo;

import java.io.Serializable;

/**
 * Created by wangpeng on 2018/12/26 15:59
 */
public class OtherActivityVO implements Serializable {
    private static final long serialVersionUID = 1L;

    // 活动Id
    private Integer activityId;
    // 活动名称
    private String activityName;
    // 活动类型
    private Integer activityType;
    // 活动状态 1-有效 4-无效 5-开始动画 6-等待投票 7-开始投票 8-停止投票
    private Integer activityStatus;
    // 奖项Id
    private Integer activityPrizeId;
    // 奖项名称
    private String activityPrizeName;
    // 中奖人数
    private Integer activityPrizeWinningNumber;
    // 奖项状态
    private Integer activityPrizeStatus;
    // 奖品Id
    private Integer prizeId;
    // 奖品名称
    private String prizeName;

    // 展示获奖名单 0-不展示 1-展示
    private Integer showLotteryDog;

    // 展示抽奖页面 0-不展示 1-展示
    private Integer showLottery;

    // 展示清空结果页面
    private Integer showClear;

    public Integer getShowClear() {
        return showClear;
    }

    public void setShowClear(Integer showClear) {
        this.showClear = showClear;
    }

    public Integer getShowLottery() {
        return showLottery;
    }

    public void setShowLottery(Integer showLottery) {
        this.showLottery = showLottery;
    }

    public Integer getShowLotteryDog() {
        return showLotteryDog;
    }

    public void setShowLotteryDog(Integer showLotteryDog) {
        this.showLotteryDog = showLotteryDog;
    }

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public Integer getActivityType() {
        return activityType;
    }

    public void setActivityType(Integer activityType) {
        this.activityType = activityType;
    }

    public Integer getActivityStatus() {
        return activityStatus;
    }

    public void setActivityStatus(Integer activityStatus) {
        this.activityStatus = activityStatus;
    }

    public Integer getActivityPrizeId() {
        return activityPrizeId;
    }

    public void setActivityPrizeId(Integer activityPrizeId) {
        this.activityPrizeId = activityPrizeId;
    }

    public String getActivityPrizeName() {
        return activityPrizeName;
    }

    public void setActivityPrizeName(String activityPrizeName) {
        this.activityPrizeName = activityPrizeName;
    }

    public Integer getActivityPrizeWinningNumber() {
        return activityPrizeWinningNumber;
    }

    public void setActivityPrizeWinningNumber(Integer activityPrizeWinningNumber) {
        this.activityPrizeWinningNumber = activityPrizeWinningNumber;
    }

    public Integer getActivityPrizeStatus() {
        return activityPrizeStatus;
    }

    public void setActivityPrizeStatus(Integer activityPrizeStatus) {
        this.activityPrizeStatus = activityPrizeStatus;
    }

    public Integer getPrizeId() {
        return prizeId;
    }

    public void setPrizeId(Integer prizeId) {
        this.prizeId = prizeId;
    }

    public String getPrizeName() {
        return prizeName;
    }

    public void setPrizeName(String prizeName) {
        this.prizeName = prizeName;
    }
}

package com.bilibili.admin.mapper;

import com.bilibili.admin.model.StaffInfoCustomized;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by wangpeng on 2018/12/21 14:30
 */
@Repository
@Mapper
public interface StaffInfoCustomizedMapper {

    public Integer countValidUser(@Param("departmentIdList") List<Integer> departmentIdList);

    public List<StaffInfoCustomized> selectValidUser(@Param("departmentIdList") List<Integer> departmentIdList);

    public List<StaffInfoCustomized> selectByUserIdList(@Param("userIdList") List<Integer> userIdList);
}

package com.bilibili.admin.vo;

import lombok.Data;

/**
 * Created by sail on 2016/12/25.
 */
@Data
public class TablePage {

    private Integer start;
    private Integer length;
    private Integer draw;
}

/**
 * Created by bzyx on 2018-12-19
 */
package com.bilibili.admin.mapper;

import com.bilibili.admin.model.ParkWorker;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ParkWorkerMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ParkWorker record);

    int insertSelective(ParkWorker record);

    ParkWorker selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ParkWorker record);

    int updateByPrimaryKey(ParkWorker record);

    List<ParkWorker> findAllWorker(@Param("workerType") int workerType);

    ParkWorker findByUsername(String username);
}
package com.bilibili.admin.exception;

import com.bilibili.admin.core.Result;
import com.bilibili.admin.core.ResultGenerator;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by wangpeng on 2018/12/27 18:06
 */
@ControllerAdvice
@ResponseBody
public class GlobalExceptionAspect {

    @ExceptionHandler(value = BusinessException.class)
    @ResponseStatus(HttpStatus.OK)
    public Result defaultErrorHandler(HttpServletRequest request, BusinessException exception) throws Exception {
        exception.printStackTrace();
        return ResultGenerator.genFailResult(exception.getErrCode(), exception.getErrMsg());
    }
}

package com.bilibili.admin.controller;

import com.bilibili.admin.core.Result;
import com.bilibili.admin.core.ResultCode;
import com.bilibili.admin.core.ResultGenerator;
import com.bilibili.admin.dto.ActivityExtTimeIntervalSearchDTO;
import com.bilibili.admin.dto.ActivitySearchDTO;
import com.bilibili.admin.dto.ActivitySlotMachinesDTO;
import com.bilibili.admin.dto.ActivityVoteResultDTO;
import com.bilibili.admin.exception.BusinessException;
import com.bilibili.admin.model.ActivityLuckyDogInfo;
import com.bilibili.admin.model.ActivityPrizeInfo;
import com.bilibili.admin.model.PrizeInfo;
import com.bilibili.admin.service.ActivityService;
import com.bilibili.admin.util.AssertUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Created by wangpeng on 2018/12/27 12:59
 */
@RestController
@RequestMapping("/screen/activity")
public class ActivityScreenController {

    //private volatile static boolean voteLotteryFlag = true;
    //private volatile static boolean slotMachinesLotteryFlag = true;

    @Autowired
    private ActivityService activityService;

    /******************** 投票抽奖活动 ***********************/
    /**
     * 实时投票数据展示
     * @param activitySearchDTO
     * @return
     */
    @RequestMapping(value = "/displayvoting", method = RequestMethod.POST)
    @ResponseBody
    public Result displayVoting (@RequestBody ActivitySearchDTO activitySearchDTO) {
        ActivityVoteResultDTO activityVoteResultDTO = activityService.displayVoting(activitySearchDTO, false);
        return ResultGenerator.genSuccessResult(activityVoteResultDTO);
    }

    /**
     * 查询获胜队伍
     * @param activitySearchDTO
     * @return
     */
    @RequestMapping(value = "/getwin", method = RequestMethod.POST)
    @ResponseBody
    public Result getWin (@RequestBody ActivitySearchDTO activitySearchDTO) {
        return ResultGenerator.genSuccessResult(activityService.getWin(activitySearchDTO));
    }

    /**
     * 投票抽奖 (开始抽奖)
     * @param activitySearchDTO
     * @return
     */
    @RequestMapping(value = "/votelottery", method = RequestMethod.POST)
    @ResponseBody
    public Result voteLottery (@RequestBody ActivitySearchDTO activitySearchDTO) {
//        if (!voteLotteryFlag) {
//            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "不要重复点击");
//        }
//        if (voteLotteryFlag) {
//            voteLotteryFlag = false;
            activityService.voteLottery(activitySearchDTO);
//        }
//        voteLotteryFlag = true;
        return ResultGenerator.genSuccessResult();
    }

    /**
     * 投票抽奖产生的幸运儿 (停止抽奖)
     * @param activitySearchDTO
     * @return
     */
    @RequestMapping(value = "/getlotterydog", method = RequestMethod.POST)
    @ResponseBody
    public Result getLotteryDog (@RequestBody ActivitySearchDTO activitySearchDTO) {
    //    voteLotteryFlag = true;
    //    slotMachinesLotteryFlag = true;
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        AssertUtil.isNull(activitySearchDTO.getActivityPrizeId(), "缺少activityPrizeId参数");

        // 修改奖项状态
        activityService.modifyActivityPrizeStatus(activitySearchDTO.getActivityPrizeId(), 4);

        return ResultGenerator.genSuccessResult(activityService.getActivityLuckyDogs(activitySearchDTO));
    }

    /******************** 分贝抽奖活动 ***********************/

    /**
     * 奖品列表
     * @param activitySearchDTO
     * @return
     */
    @RequestMapping(value = "/getprize", method = RequestMethod.POST)
    @ResponseBody
    public Result getPrize (@RequestBody ActivitySearchDTO activitySearchDTO) {
        List<PrizeInfo> prizeInfoList = activityService.getPrize(activitySearchDTO);
        return ResultGenerator.genSuccessResult(prizeInfoList);
    }

    // 查询活动动画进度
    @RequestMapping(value = "/getprogress", method = RequestMethod.POST)
    @ResponseBody
    public Result getProgress (@RequestBody ActivityExtTimeIntervalSearchDTO activityExtTimeIntervalSearchDTO) {
        Integer progress = activityService.getAnimationProgress(activityExtTimeIntervalSearchDTO);
        return ResultGenerator.genSuccessResult(progress);
    }

    /**
     * 查询幸运儿
     * @param activitySearchDTO
     * @return
     */
    @RequestMapping(value = "/getotherlotterydog", method = RequestMethod.POST)
    @ResponseBody
    public Result getOtherLotteryDog (@RequestBody ActivitySearchDTO activitySearchDTO) {
        Map<Integer, List<ActivityLuckyDogInfo>> map = activityService.getOtherLotteryDog(activitySearchDTO);
        return ResultGenerator.genSuccessResult(map);
    }





    /******************** 老虎机抽奖活动 ***********************/

    /**
     * 活动详情
     * @param activitySearchDTO
     * @return
     */
    @RequestMapping(value = "/getslotmachinesinfo", method = RequestMethod.POST)
    @ResponseBody
    public Result  getSlotMachinesInfo (@RequestBody ActivitySearchDTO activitySearchDTO) {
        ActivitySlotMachinesDTO activitySlotMachinesDTO = activityService.getSlotMachinesInfo(activitySearchDTO);
        return ResultGenerator.genSuccessResult(activitySlotMachinesDTO);
    }

    /**
     * 开始抽奖
     * @param activitySearchDTO
     * @return
     */
    @RequestMapping(value = "/slotmachineslottery", method = RequestMethod.POST)
    @ResponseBody
    public Result  slotMachinesLottery (@RequestBody ActivitySearchDTO activitySearchDTO) {
//        if (!slotMachinesLotteryFlag) {
//            throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "不要重复点击");
//        }
//        if (slotMachinesLotteryFlag) {
//
//            slotMachinesLotteryFlag = false;

            AssertUtil.isNull(activitySearchDTO, "缺少参数");
            AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
            AssertUtil.isNull(activitySearchDTO.getActivityPrizeId(), "缺少activityPrizeId参数");

            ActivityPrizeInfo activityPrizeInfo = activityService.getActivityPrizeInfoById(activitySearchDTO.getActivityPrizeId());
            if (null  == activityPrizeInfo) {
                throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "奖项不存在");
            }
            if (3 == activityPrizeInfo.getStatus() || 4 == activityPrizeInfo.getStatus()) {
                throw new BusinessException(ResultCode.ACTIVITY_ERR.getCode(), "已经开奖了");
            }
            activityService.otherLottery(activitySearchDTO);
    //    }
    //    slotMachinesLotteryFlag = true;
        return ResultGenerator.genSuccessResult();
    }

    // 停止抽奖 (同投票抽奖的停止抽奖)


    // 展示中奖人
    @RequestMapping(value = "/showlotterydog", method = RequestMethod.POST)
    @ResponseBody
    public Result showLotteryDog (@RequestBody ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        // 奖项状态是推送到用户
        activitySearchDTO.setPrizeStatus(4);
        List<ActivityLuckyDogInfo> activityLuckyDogDTOList = activityService.getActivityLuckyDogs(activitySearchDTO);
        return ResultGenerator.genSuccessResult(activityLuckyDogDTOList);
    }

    // 查询未中奖的奖项ID 每次只返回一个
    @RequestMapping(value = "/getactivityprizeid", method = RequestMethod.POST)
    @ResponseBody
    public Result getActivityPrizeId (@RequestBody ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getActivityId(), "缺少activityId参数");
        Integer activityPrizeId = activityService.getActivityPrizeId(activitySearchDTO.getActivityId());
        return ResultGenerator.genSuccessResult(activityPrizeId);
    }
}
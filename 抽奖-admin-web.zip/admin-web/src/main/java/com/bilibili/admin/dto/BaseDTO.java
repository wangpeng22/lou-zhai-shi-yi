package com.bilibili.admin.dto;

import java.io.Serializable;

/**
 * DTO 基类
 * Created by wangpeng on 2018/12/19 17:40
 */
public class BaseDTO implements Serializable {
    private static final long serialVersionUID = 1L;
}

package com.bilibili.admin.mapper;

import com.bilibili.admin.model.ActivityLuckyDogInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by wangpeng on 2018/12/28 11:02
 */
@Repository
@Mapper
public interface ActivityLuckyDogInfoCustomizedMapper {

    public void batchSave(@Param("activityLuckyDogInfoList") List<ActivityLuckyDogInfo> activityLuckyDogInfoList);
}

package com.bilibili.admin.service.impl;

import com.bilibili.admin.mapper.ParkInfoMapper;
import com.bilibili.admin.mapper.ParkWorkerMapper;
import com.bilibili.admin.model.ParkInfo;
import com.bilibili.admin.model.ParkWorker;
import com.bilibili.admin.model.User;
import com.bilibili.admin.service.ParkWorkerService;
import com.bilibili.admin.vo.DataTable;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author wang_zc
 * @date 2018/12/20
 */
@Service
public class ParkWorkerServiceImpl implements ParkWorkerService {

    @Autowired
    private ParkInfoMapper parkInfoMapper;

    @Autowired
    private ParkWorkerMapper parkWorkerMapper;

    /**
     * 查询所有游玩点
     *
     * @return java.util.List<com.bilibili.admin.model.ParkInfo>
     * @author wang_zc
     */
    @Override
    public List<ParkInfo> findAllParkInfo() {
        return parkInfoMapper.findAllParkInfo();
    }

    /**
     * 添加工作人员
     *
     * @param parkWorker 工作人员
     * @author wang_zc
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void addWorker(ParkWorker parkWorker) {
        // 判断username是否重复
        ParkWorker p = parkWorkerMapper.findByUsername(parkWorker.getUsername());
        if (p != null) {
            throw new RuntimeException("该账号已存在");
        }
        parkWorkerMapper.insertSelective(parkWorker);
    }

    /**
     * 删除工作人员
     *
     * @param id 工作人员id
     * @author wang_zc
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteWorker(long id) {
        parkWorkerMapper.deleteByPrimaryKey(id);
    }

    /**
     * 查询工作人员
     *
     * @param parkWorker 工作人员
     * @return com.bilibili.admin.vo.DataTable<com.bilibili.admin.model.ParkWorker>
     * @author wang_zc
     */
    @Override
    public DataTable<ParkWorker> findAllWorker(ParkWorker parkWorker) {
        PageHelper.offsetPage(parkWorker.getStart(), parkWorker.getLength());
        List<ParkWorker> allWorker = parkWorkerMapper.findAllWorker(parkWorker.getWorkerType());
        DataTable<ParkWorker> tables = new DataTable<>();
        tables.setRecordsTotal(((Page) allWorker).getTotal());
        tables.setRecordsFiltered(tables.getRecordsTotal());
        tables.setDraw(parkWorker.getDraw());
        tables.setData(allWorker);
        return tables;
    }
}

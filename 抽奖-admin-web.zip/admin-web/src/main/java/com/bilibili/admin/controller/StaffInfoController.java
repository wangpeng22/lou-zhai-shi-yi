package com.bilibili.admin.controller;

import com.bilibili.admin.core.Result;
import com.bilibili.admin.core.ResultCode;
import com.bilibili.admin.core.ResultGenerator;
import com.bilibili.admin.model.StaffInfo;
import com.bilibili.admin.service.StaffInfoService;
import com.bilibili.admin.util.PoiUtil;
import com.bilibili.admin.vo.DataTable;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 员工控制器
 */
@RestController
@RequestMapping("/staff")
@Slf4j
public class StaffInfoController {

    @Autowired
    private StaffInfoService staffInfoService;

    /**
     * 人员导入
     * @param file
     * @return
     */
    @PostMapping("/staffImport")
    public Result handleFileUpload(@RequestParam("file") MultipartFile file) throws IOException {
        if (!file.isEmpty()) {
            List<StaffInfo> list = PoiUtil.readExcel(file);
            if (list != null &&  list.size() > 0){
                //将excel表格中的数据导入到数据库中
                staffInfoService.importStaffInfo(list);
                return ResultGenerator.genSuccessResult(ResultCode.SUCCESS.getCode(),ResultCode.SUCCESS.getMsg(),null);
            }
            return ResultGenerator.genSuccessResult(ResultCode.DATAISNULL.getCode(),ResultCode.DATAISNULL.getMsg(),null);
        } else {
            return ResultGenerator.genSuccessResult(ResultCode.FILEISNULL.getCode(),ResultCode.FILEISNULL.getMsg(),null);
        }
    }

    /**
     * 人员导出
     * @return
     */
    @GetMapping("/staffExport")
    public void export(@Param("staffName") String staffName, @Param("deptName") String deptName, HttpServletResponse response) throws Exception {
        StaffInfo temp = new StaffInfo();
        temp.setDeptName(deptName);
        temp.setStaffName(staffName);
        DataTable<StaffInfo> staffInfos = staffInfoService.listStaffInfo(temp);
        List<StaffInfo> list = staffInfos.getData();
        String[] rowsName = new String[]{"序号","部门","姓名","所在地","报名时间","前往方式","道具领取状态","入园状态","游玩状态","游玩是否兑奖","座位信息","签到状态"};
        List<Object[]>  dataList = new ArrayList<Object[]>();
        Object[] objs = null;
        for (int i = 0; i < list.size(); i++) {
            StaffInfo staffInfo = list.get(i);
            objs = new Object[rowsName.length];
            objs[0] = i;
            objs[1] = staffInfo.getDeptName();
            objs[2] = staffInfo.getStaffName();
            objs[3] = staffInfo.getStaffAddress();
            if (staffInfo.getStaffRegistTime() != null) {
              SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                objs[4] = sf.format(staffInfo.getStaffRegistTime());
            } else {
                objs[4] ="";
            }
            objs[5] = staffInfo.getStaffTripMode();
            objs[6] = staffInfo.getStaffRecevieState();
            objs[7] = staffInfo.getStaffEnterState();
            objs[8] = staffInfo.getStaffPlayState();
            objs[9] = staffInfo.getStaffPrizeState();
            objs[10] = staffInfo.getStaffPlaceInfo();
            objs[11] = staffInfo.getStaffSignState();
            dataList.add(objs);
        }
       PoiUtil.export("员工基本信息",rowsName,dataList,response);
    }

    /**
     * 人员信息修改
     * @throws IOException
     */
    @PostMapping(value = "/editStaffInfo")
    public Result editStaffInfo(@RequestBody StaffInfo staffInfo) {
        staffInfoService.editStaff(staffInfo);
        return  ResultGenerator.genSuccessResult(ResultCode.SUCCESS.getCode(),ResultCode.SUCCESS.getMsg(),null);
    }

    /**
     * 条件查询员工信息
     * @param staffInfo
     * @return
     */
    @PostMapping(value = "/listStaffInfo")
    public DataTable<StaffInfo> listStaffInfo(@RequestBody StaffInfo staffInfo){

        DataTable<StaffInfo> staffInfos = staffInfoService.listStaffInfo(staffInfo);
        return staffInfos;
    }
}

package com.bilibili.admin.controller;

import com.bilibili.admin.model.ParkInfo;
import com.bilibili.admin.model.ParkWorker;
import com.bilibili.admin.model.RestResp;
import com.bilibili.admin.service.ParkWorkerService;
import com.bilibili.admin.vo.DataTable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

/**
 * 工作人员
 *
 * @author wang_zc
 * @date 2018/12/20
 */
@RestController
@RequestMapping("/parkworker")
public class ParkWorkerController {

    @Autowired
    private ParkWorkerService parkWorkerService;

    /**
     * 查询所有游玩点
     *
     * @return com.bilibili.admin.model.RestResp
     * @author wang_zc
     */
    @GetMapping("/findAllParkInfo")
    public List<ParkInfo> findAllParkInfo() {
        return parkWorkerService.findAllParkInfo();
    }

    /**
     * 添加工作人员
     *
     * @param parkWorker 工作人员
     * @return com.bilibili.admin.model.RestResp
     * @author wang_zc
     */
    @PostMapping("/addWorker")
    public RestResp addWorker(@RequestBody ParkWorker parkWorker) {
        try {
            parkWorker.setUuid(UUID.randomUUID().toString().replace("-",""));
            parkWorkerService.addWorker(parkWorker);
        } catch (Exception e) {
            e.printStackTrace();
            return RestResp.error(400, e.getMessage());
        }
        return RestResp.ok("添加成功");
    }

    /**
     * 删除工作人员
     *
     * @param id 工作人员id
     * @return com.bilibili.admin.model.RestResp
     * @author wang_zc
     */
    @GetMapping("/deleteWorker/{id}")
    public RestResp deleteWorker(@PathVariable long id) {
        parkWorkerService.deleteWorker(id);
        return RestResp.ok("删除成功");
    }

    /**
     * 查询工作人员
     *
     * @param parkWorker 工作人员
     * @return com.bilibili.admin.vo.DataTable<com.bilibili.admin.model.ParkWorker>
     * @author wang_zc
     */
    @PostMapping("/findAllWorker")
    public DataTable<ParkWorker> findAllWorker(@RequestBody ParkWorker parkWorker) {
        return parkWorkerService.findAllWorker(parkWorker);
    }

}

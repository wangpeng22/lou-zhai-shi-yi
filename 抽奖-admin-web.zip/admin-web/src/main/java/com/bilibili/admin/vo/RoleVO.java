package com.bilibili.admin.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by sail on 2016/12/25.
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class RoleVO extends TablePage{
}

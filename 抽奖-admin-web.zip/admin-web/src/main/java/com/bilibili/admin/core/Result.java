package com.bilibili.admin.core;

/**
 * 统一API响应结果封装
 * @author
 * @date 2018-12-18 16:07:55
 */
public class Result<T> {
    private int code;
    private String message;
    private T data;

    public Result setCode(int code) {
        this.code = code;
        return this;
    }

    public int getCode() {
        return code;
    }



    public String getMessage() {
        return message;
    }

    public Result setMessage(String message) {
        this.message = message;
        return this;
    }

    public Object getData() {
        return data;
    }

    public Result setData(T data) {
        this.data = data;
        return this;
    }

}

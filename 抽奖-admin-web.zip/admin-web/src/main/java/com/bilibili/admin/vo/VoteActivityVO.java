package com.bilibili.admin.vo;

import java.io.Serializable;

/**
 * 投票管理的列表展示对象
 * Created by wangpeng on 2018/12/26 09:37
 */
public class VoteActivityVO implements Serializable {
    private static final long serialVersionUID = 1L;

    // 活动Id
    private Integer activityId;
    // 活动名称
    private String activityName;
    // 活动状态 1-有效 4-无效 5-开始动画 6-等待投票 7-开始投票 8-停止投票
    private Integer status;
    // 奖项Id
    private Integer activityPrizeId;
    // 战队1Id
    private Integer voteId1;
    // 战队1名称
    private String voteName1;
    // 战队1得票数
    private Integer voteNumber1;
    // 战队2Id
    private Integer voteId2;
    // 战队2名称
    private String voteName2;
    // 战队2得票数
    private Integer voteNumber2;

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getActivityPrizeId() {
        return activityPrizeId;
    }

    public void setActivityPrizeId(Integer activityPrizeId) {
        this.activityPrizeId = activityPrizeId;
    }

    public Integer getVoteId1() {
        return voteId1;
    }

    public void setVoteId1(Integer voteId1) {
        this.voteId1 = voteId1;
    }

    public String getVoteName1() {
        return voteName1;
    }

    public void setVoteName1(String voteName1) {
        this.voteName1 = voteName1;
    }

    public Integer getVoteNumber1() {
        return voteNumber1;
    }

    public void setVoteNumber1(Integer voteNumber1) {
        this.voteNumber1 = voteNumber1;
    }

    public Integer getVoteId2() {
        return voteId2;
    }

    public void setVoteId2(Integer voteId2) {
        this.voteId2 = voteId2;
    }

    public String getVoteName2() {
        return voteName2;
    }

    public void setVoteName2(String voteName2) {
        this.voteName2 = voteName2;
    }

    public Integer getVoteNumber2() {
        return voteNumber2;
    }

    public void setVoteNumber2(Integer voteNumber2) {
        this.voteNumber2 = voteNumber2;
    }
}

package com.bilibili.admin.service;

import com.bilibili.admin.model.ParkInfo;
import com.bilibili.admin.model.ParkWorker;
import com.bilibili.admin.vo.DataTable;

import java.util.List;

/**
 * @author wang_zc
 * @date 2018/12/20
 */
public interface ParkWorkerService {
    /**
     * 查询所有游玩点
     *
     * @return java.util.List<com.bilibili.admin.model.ParkInfo>
     * @author wang_zc
     */
    List<ParkInfo> findAllParkInfo();

    /**
     * 添加工作人员
     *
     * @param parkWorker 工作人员
     * @author wang_zc
     */
    void addWorker(ParkWorker parkWorker);

    /**
     * 删除工作人员
     *
     * @param id 工作人员id
     * @author wang_zc
     */
    void deleteWorker(long id);

    /**
     * 查询工作人员
     *
     * @param parkWorker 工作人员
     * @return com.bilibili.admin.vo.DataTable<com.bilibili.admin.model.ParkWorker>
     * @author wang_zc
     */
    DataTable<ParkWorker> findAllWorker(ParkWorker parkWorker);
}

package com.bilibili.admin.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * Created by wangpeng on 2019/1/13 18:06
 */
@Repository
@Mapper
public interface ActivityPrizeInfoCustomizedMapper {
    public int getPrizeCountByActivityId(@Param("activityId") int activityId);
}

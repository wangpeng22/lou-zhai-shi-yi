package com.bilibili.admin.model;

import java.io.Serializable;

/**
 * Created by wangpeng on 2018/12/19 17:38
 */
public class Base implements Serializable {
    private static final long serialVersionUID = 1L;
}

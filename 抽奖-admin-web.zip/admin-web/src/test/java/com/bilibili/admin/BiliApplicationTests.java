package com.bilibili.admin;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class BiliApplicationTests {

	@Test
	public void contextLoads() throws ParseException {
		String string = "2019-01-12 19:40:16";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println(sdf.parse(string));

		Date closeTime = sdf.parse(string);
		Date currentTime = new Date();
		System.out.println("----"+currentTime);
		System.out.println("----"+currentTime.toGMTString());
		if (closeTime.before(currentTime)){
			System.out.println("dddd");
			//return ResultGenerator.genSuccessResult(ResultCode.TIMEISOVER.getCode(), ResultCode.TIMEISOVER.getMsg(), 0);
		}
		System.out.println("swdd");

		UTCToCST("2017-11-27T03:16:03.944Z", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	}

	public static void UTCToCST(String UTCStr, String format) throws ParseException {
		Date date = null;
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		date = sdf.parse(UTCStr);
		System.out.println("UTC时间: " + date);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR, calendar.get(Calendar.HOUR) + 8);
		//calendar.getTime() 返回的是Date类型，也可以使用calendar.getTimeInMillis()获取时间戳
		System.out.println("北京时间: " + calendar.getTime());
	}
}

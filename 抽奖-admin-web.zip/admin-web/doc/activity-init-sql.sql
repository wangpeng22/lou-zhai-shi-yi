-- 清空奖品表
truncate table prize_info;
-- 投票奖品
INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (1, "麦硕投影仪", "麦硕投影仪","1.png", NULL);

-- 分贝抽奖奖品
INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (2, "HP相机", "HP迷你生活相机","2.png", 63);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (3, "雷蛇鼠标", "雷蛇（Razer）Lancehead TE 锐蝮蛇竞技版 韦神同款 有线电竞游戏鼠标","3.png", 64);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (4, "外交官拉杆箱", "外交官（Diplomat）镜面箱子拉杆箱外交官镜面拉杆箱（前置挂包带TC-6222（20寸）黑色/银色","4.png", 63);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (5, "Bo33折叠蓝牙键盘", "Bo33可折叠智慧型蓝牙键盘","5.png", 63);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (6, "猫王小王子音箱", "猫王小王子FM/蓝牙便携式音箱 （花梨木）","6.png", 63);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (7, "Kyoto 办公套装", "Kyoto 多功能移动办公套装","7.png", 30);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (8, "云梦抱枕", "云梦抱枕","8.png", 30);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (9, "西屋加湿器", "西屋加湿器","9.png", 30);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (10, "碧然德即热净水吧", "碧然德Filter & Boil Station 即热净 水吧 FB2020B1","10.png", 30);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (11, "JBL水晶音响", "JBL SOUNDSTICKS III Wireless无线水晶音响","11.png", 50);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (12, "PanoClip全景可立拍", "PanoClip全景可立拍","12.png", 50);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (13, "多极射频美容器", "Tripollar 美容仪 RF多极射频美容器","13.png", 25);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (14, "马歇尔户外音箱", "马歇尔（Marshall） Kilburn 无线蓝牙户外音箱马勺摇滚重低音移动客厅音响 黑色","14.png", 25);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (15, "Bose无线耳机", "Bose QuietComfort 35 无线耳机","15.png", 25);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (16, "戴森造型套装", "戴森（DYSON）Airwrap 多功能 美发造型器 自动卷发棒 卷发器 6个头顺滑造型套装","16.png", 10);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (17, "华为 Mate 20 X", "Mate20 X手机华为 HUAWEI Mate 20 X 麒麟980芯片全面屏超微距影像超大广角徕卡三摄6GB+128GB宝石蓝全网通版双4G手机","17.png", 10);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (18, "戴森手持吸尘器", "戴森V10 fluffy手持吸尘器","18.png", 10);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (19, "小米卡丁车", "ninebot 小米九号平衡车卡丁车（白色平衡车+卡丁改装套件+Segway头盔）","19.png", 10);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (20, "索尼ps4", "索尼ps4 Slim/Pro psvr电脑娱乐游戏机","20.png", 5);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (21, "华为Mate 20 Pro", "华为 HUAWEI Mate 20 Pro (UD)屏内指纹版麒麟980芯片全面屏超大广角徕卡三摄8GB+256GB樱粉金全网通双4G手机","21.png", 5);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (22, "Apple IPhone XS", "Apple IPhone XS","22.png", 5);

-- 老虎机 抽奖奖品
-- INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (23, "索尼3D投影仪", "索尼G1109 Xperia Touch多点触控智能 多媒体娱乐终端3D投影仪","23.png", 5);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (24, "Apple IPhone XS MAX", "Apple IPhone XS MAX","24.png", 10);

INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (25, "旅游基金", "旅游基金","25.png", 3);

-- 神秘大奖
-- INSERT INTO prize_info (id, prize_name, prize_desc, prize_icon, prize_num) VALUES (26, "汽车使用权", "汽车使用权","26.png", 1);


-- 清空活动表
truncate table activity_base_info;
-- 投票
INSERT INTO activity_base_info (id, activity_name, activity_desc, activity_type) VALUES (1, "Round 1 歌曲表演", "请选择你喜欢的队伍投票", 1);

INSERT INTO activity_base_info (id, activity_name, activity_desc, activity_type) VALUES (2, "Round 2 游戏", "竞猜谁是胜利的队伍", 1);

INSERT INTO activity_base_info (id, activity_name, activity_desc, activity_type) VALUES (3, "Round 3 舞蹈表演", "请选择你喜欢的队伍投票", 1);

-- 分贝
INSERT INTO activity_base_info (id, activity_name, activity_desc, activity_type) VALUES (4, "砥砺前行奖", "a1.png", 2);

-- 老虎机
INSERT INTO activity_base_info (id, activity_name, activity_desc, activity_type) VALUES (5, "展望未来奖", "a2.png", 3);
INSERT INTO activity_base_info (id, activity_name, activity_desc, activity_type) VALUES (6, "展望未来奖", "a2.png", 4);


-- INSERT INTO activity_base_info (id, activity_name, activity_desc, activity_type) VALUES (7, "神秘大奖", "神秘大奖", 5);

-- 清空奖项表
truncate table activity_prize_info;
-- 投票
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (1, "幸运观众", "幸运观众", 30, 1, 1);

INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (2, "幸运观众", "幸运观众", 30, 2, 1);

INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (3, "幸运观众", "幸运观众", 30, 3, 1);

-- 不忘初心奖
-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (4, "HP相机", "HP迷你生活相机", 63, 4, 2);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (4, "HP相机", "HP迷你生活相机", 31, 4, 2);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (5, "HP相机", "HP迷你生活相机", 32, 4, 2);


-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (5, "雷蛇鼠标", "雷蛇（Razer）Lancehead TE 锐蝮蛇竞技版 韦神同款 有线电竞游戏鼠标", 64, 4, 3);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (6, "雷蛇鼠标", "雷蛇（Razer）Lancehead TE 锐蝮蛇竞技版 韦神同款 有线电竞游戏鼠标", 32, 4, 3);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (7, "雷蛇鼠标", "雷蛇（Razer）Lancehead TE 锐蝮蛇竞技版 韦神同款 有线电竞游戏鼠标", 32, 4, 3);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (6, "外交官拉杆箱", "外交官（Diplomat）镜面箱子拉杆箱外交官镜面拉杆箱（前置挂包带TC-6222（20寸）黑色/银色", 63, 4, 4);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (8, "外交官拉杆箱", "外交官（Diplomat）镜面箱子拉杆箱外交官镜面拉杆箱（前置挂包带TC-6222（20寸）黑色/银色", 32, 4, 4);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (9, "外交官拉杆箱", "外交官（Diplomat）镜面箱子拉杆箱外交官镜面拉杆箱（前置挂包带TC-6222（20寸）黑色/银色", 31, 4, 4);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (7, "Bo33折叠蓝牙键盘", "Bo33可折叠智慧型蓝牙键盘", 63, 4, 5);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (10, "Bo33折叠蓝牙键盘", "Bo33可折叠智慧型蓝牙键盘", 31, 4, 5);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (11, "Bo33折叠蓝牙键盘", "Bo33可折叠智慧型蓝牙键盘", 32, 4, 5);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (8, "猫王小王子音箱", "猫王小王子FM/蓝牙便携式音箱 （花梨木）", 63, 4, 6);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (12, "猫王小王子音箱", "猫王小王子FM/蓝牙便携式音箱 （花梨木）", 32, 4, 6);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (13, "猫王小王子音箱", "猫王小王子FM/蓝牙便携式音箱 （花梨木）", 31, 4, 6);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (9, "Kyoto 办公套装", "Kyoto 多功能移动办公套装", 30, 4, 7);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (14, "Kyoto 办公套装", "Kyoto 多功能移动办公套装", 15, 4, 7);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (15, "Kyoto 办公套装", "Kyoto 多功能移动办公套装", 15, 4, 7);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (10, "云梦抱枕", "云梦抱枕", 30, 4, 8);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (16, "云梦抱枕", "云梦抱枕", 15, 4, 8);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (17, "云梦抱枕", "云梦抱枕", 15, 4, 8);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (11, "西屋加湿器", "西屋加湿器", 30, 4, 9);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (18, "西屋加湿器", "西屋加湿器", 15, 4, 9);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (19, "西屋加湿器", "西屋加湿器", 15, 4, 9);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (12, "碧然德即热净水吧", "碧然德Filter & Boil Station 即热净 水吧 FB2020B1", 30, 4, 10);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (20, "碧然德即热净水吧", "碧然德Filter & Boil Station 即热净 水吧 FB2020B1", 15, 4, 10);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (21, "碧然德即热净水吧", "碧然德Filter & Boil Station 即热净 水吧 FB2020B1", 15, 4, 10);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (13, "JBL水晶音响", "JBL SOUNDSTICKS III Wireless无线水晶音响", 50, 4, 11);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (22, "JBL水晶音响", "JBL SOUNDSTICKS III Wireless无线水晶音响", 25, 4, 11);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (23, "JBL水晶音响", "JBL SOUNDSTICKS III Wireless无线水晶音响", 25, 4, 11);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (14, "PanoClip全景可立拍", "PanoClip全景可立拍", 50, 4, 12);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (24, "PanoClip全景可立拍", "PanoClip全景可立拍", 25, 4, 12);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (25, "PanoClip全景可立拍", "PanoClip全景可立拍", 25, 4, 12);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (15, "多极射频美容器", "Tripollar 美容仪 RF多极射频美容器", 25, 4, 13);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (26, "多极射频美容器", "Tripollar 美容仪 RF多极射频美容器", 12, 4, 13);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (27, "多极射频美容器", "Tripollar 美容仪 RF多极射频美容器", 13, 4, 13);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (16, "马歇尔户外音箱", "马歇尔（Marshall） Kilburn 无线蓝牙户外音箱马勺摇滚重低音移动客厅音响 黑色", 25, 4, 14);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (28, "马歇尔户外音箱", "马歇尔（Marshall） Kilburn 无线蓝牙户外音箱马勺摇滚重低音移动客厅音响 黑色", 13, 4, 14);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (29, "马歇尔户外音箱", "马歇尔（Marshall） Kilburn 无线蓝牙户外音箱马勺摇滚重低音移动客厅音响 黑色", 12, 4, 14);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (17, "Bose无线耳机", "Bose QuietComfort 35 无线耳机", 25, 4, 15);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (30, "Bose无线耳机", "Bose QuietComfort 35 无线耳机", 13, 4, 15);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (31, "Bose无线耳机", "Bose QuietComfort 35 无线耳机", 12, 4, 15);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (18, "戴森造型套装", "戴森（DYSON）Airwrap 多功能 美发造型器 自动卷发棒 卷发器 6个头顺滑造型套装", 10, 4, 16);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (32, "戴森造型套装", "戴森（DYSON）Airwrap 多功能 美发造型器 自动卷发棒 卷发器 6个头顺滑造型套装", 5, 4, 16);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (33, "戴森造型套装", "戴森（DYSON）Airwrap 多功能 美发造型器 自动卷发棒 卷发器 6个头顺滑造型套装", 5, 4, 16);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (19, "华为 Mate 20 X", "Mate20 X手机华为 HUAWEI Mate 20 X 麒麟980芯片全面屏超微距影像超大广角徕卡三摄6GB+128GB宝石蓝全网通版双4G手机", 10, 4, 17);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (34, "华为 Mate 20 X", "Mate20 X手机华为 HUAWEI Mate 20 X 麒麟980芯片全面屏超微距影像超大广角徕卡三摄6GB+128GB宝石蓝全网通版双4G手机", 5, 4, 17);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (35, "华为 Mate 20 X", "Mate20 X手机华为 HUAWEI Mate 20 X 麒麟980芯片全面屏超微距影像超大广角徕卡三摄6GB+128GB宝石蓝全网通版双4G手机", 5, 4, 17);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (20, "戴森手持吸尘器", "戴森V10 fluffy手持吸尘器", 10, 4, 18);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (36, "戴森手持吸尘器", "戴森V10 fluffy手持吸尘器", 5, 4, 18);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (37, "戴森手持吸尘器", "戴森V10 fluffy手持吸尘器", 5, 4, 18);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (21, "小米卡丁车", "ninebot 小米九号平衡车卡丁车（白色平衡车+卡丁改装套件+Segway头盔）", 10, 4, 19);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (38, "小米卡丁车", "ninebot 小米九号平衡车卡丁车（白色平衡车+卡丁改装套件+Segway头盔）", 5, 4, 19);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (39, "小米卡丁车", "ninebot 小米九号平衡车卡丁车（白色平衡车+卡丁改装套件+Segway头盔）", 5, 4, 19);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (22, "索尼ps4", "索尼ps4 Slim/Pro psvr电脑娱乐游戏机", 5, 4, 20);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (40, "索尼ps4", "索尼ps4 Slim/Pro psvr电脑娱乐游戏机", 2, 4, 20);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (41, "索尼ps4", "索尼ps4 Slim/Pro psvr电脑娱乐游戏机", 3, 4, 20);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (23, "华为Mate 20 Pro", "华为 HUAWEI Mate 20 Pro (UD)屏内指纹版麒麟980芯片全面屏超大广角徕卡三摄8GB+256GB樱粉金全网通双4G手机", 5, 4, 21);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (42, "华为Mate 20 Pro", "华为 HUAWEI Mate 20 Pro (UD)屏内指纹版麒麟980芯片全面屏超大广角徕卡三摄8GB+256GB樱粉金全网通双4G手机", 3, 4, 21);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (43, "华为Mate 20 Pro", "华为 HUAWEI Mate 20 Pro (UD)屏内指纹版麒麟980芯片全面屏超大广角徕卡三摄8GB+256GB樱粉金全网通双4G手机", 2, 4, 21);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (24, "Apple IPhone XS", "Apple IPhone XS", 5, 4, 22);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (44, "Apple IPhone XS", "Apple IPhone XS", 2, 4, 22);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (45, "Apple IPhone XS", "Apple IPhone XS", 3, 4, 22);

-- BiliBili欧皇奖
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (46, "Apple IPhone XS MAX", "Apple IPhone XS MAX", 5, 5, 24);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (47, "Apple IPhone XS MAX", "Apple IPhone XS MAX", 5, 5, 24);


INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (48, "旅游基金", "旅游基金", 1, 6, 25);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (49, "旅游基金", "旅游基金", 1, 6, 25);
INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (50, "旅游基金", "旅游基金", 1, 6, 25);

-- INSERT INTO activity_prize_info (id, activity_prize_name, activity_prize_desc, activity_prize_winning_number, activity_id, prize_id) VALUES (50, "汽车使用权", "汽车使用权", 1, 7, 26);

-- 清空战队表
truncate table activity_vote_info;
-- 战队信息
INSERT INTO activity_vote_info(id, vote_name, vote_number, activity_id) VALUES (1, "白队-《我是要成为孩子王的人》",0,1);
INSERT INTO activity_vote_info(id, vote_name, vote_number, activity_id) VALUES (2, "红队-《我才是要成为孩子王的人》",0,1);

INSERT INTO activity_vote_info(id, vote_name, vote_number, activity_id) VALUES (3, "白队",0,2);
INSERT INTO activity_vote_info(id, vote_name, vote_number, activity_id) VALUES (4, "蓝队",0,2);

INSERT INTO activity_vote_info(id, vote_name, vote_number, activity_id) VALUES (5, "蓝队-《新纪元》(be with you)",0,3);
INSERT INTO activity_vote_info(id, vote_name, vote_number, activity_id) VALUES (6, "红队-《新战场》（精武门+新战场）",0,3);

-- 清空投票表
truncate table activity_user_vote;

-- 清空动画进度表
truncate table activity_ext_timer;
INSERT INTO activity_ext_timer(id, activity_id) VALUE (1, 4);

-- 清空动画进度设置表
truncate table activity_ext_time_interval;
INSERT INTO activity_ext_time_interval(id, s, t, p_id, timer_id) VALUE (1, 100000, 0, 0, 1);

-- 清空幸运观众表
truncate table activity_lucky_dog_info;

-- 清空部门权重表
TRUNCATE TABLE activity_department_winning_weight;
INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('1','4','1','0','100');
INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('2','4','2,3','100','200');
INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('3','4','4,5,6,7','200','300');
INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('4','4','8,9,10,11,12,13,14,15,16','300','400');
INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('5','4','17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41','500','600');


INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('7','5','1','0','100');
INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('8','5','2,3','100','200');
INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('9','5','4,5,6,7','200','300');
INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('10','5','8,9,10,11,12,13,14,15,16','300','400');
INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('11','5','17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41','500','600');


INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('13','6','1','0','100');
INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('14','6','2,3','100','200');
INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('15','6','4,5,6,7','200','300');
INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('16','6','8,9,10,11,12,13,14,15,16','300','400');
INSERT INTO activity_department_winning_weight (id, activity_id, department_id, left_interval, right_interval) VALUES ('17','6','17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41','500','600');


truncate table activity_prize_info_ext;
INSERT INTO activity_prize_info_ext(id, activity_prize_id, activity_id, btn_name) VALUES(1, "4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45", 4, "抽取666");
INSERT INTO activity_prize_info_ext(id, activity_prize_id, activity_id, btn_name) VALUES(2, "4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36,38,40,42,44", 4, "抽取333");
INSERT INTO activity_prize_info_ext(id, activity_prize_id, activity_id, btn_name) VALUES(3, "5,7,9,11,13,15,17,19,21,23,25,27,29,31,33,35,37,39,41,43,45", 4, "再次抽取333");
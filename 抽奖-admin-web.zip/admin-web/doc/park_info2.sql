/*
Navicat MySQL Data Transfer

Source Server         : 106.14.220.206
Source Server Version : 50641
Source Host           : 106.14.220.206:3306
Source Database       : bilibili

Target Server Type    : MYSQL
Target Server Version : 50641
File Encoding         : 65001

Date: 2019-01-07 14:05:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for park_info
-- ----------------------------
DROP TABLE IF EXISTS `park_info`;
CREATE TABLE `park_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `park_name` varchar(50) NOT NULL DEFAULT '' COMMENT '园区名称',
  `park_score` int(11) NOT NULL DEFAULT '0' COMMENT '计分--游玩时可获得的分数',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='游玩点基础信息';

-- ----------------------------
-- 7个写死的游玩点基础数据（每个游玩点的分数还没确定）
-- ----------------------------
INSERT INTO `park_info` VALUES ('1', '激流勇进', '1', '2018-12-21 11:36:34', '2018-12-21 16:57:14');
INSERT INTO `park_info` VALUES ('2', '大洋历险', '2', '2018-12-21 11:40:10', '2018-12-21 16:57:15');
INSERT INTO `park_info` VALUES ('3', '蓝月飞车', '3', '2018-12-21 16:56:12', '2018-12-21 16:57:17');
INSERT INTO `park_info` VALUES ('4', '矿山历险', '4', '2018-12-21 16:56:35', '2018-12-21 16:57:18');
INSERT INTO `park_info` VALUES ('5', '金银岛', '5', '2018-12-21 16:56:44', '2018-12-21 16:57:19');
INSERT INTO `park_info` VALUES ('6', '谷木游龙', '6', '2018-12-21 16:56:59', '2018-12-21 16:57:20');
INSERT INTO `park_info` VALUES ('7', '天地双雄', '7', '2018-12-21 16:57:08', '2018-12-21 16:57:21');

-- ----------------------------
-- 需要清空的表
-- ----------------------------

-- ----------------------------
-- Table structure for park_play
-- ----------------------------
DROP TABLE IF EXISTS `park_play`;
CREATE TABLE `park_play` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '游玩者id',
  `park_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '园区id',
  `park_name` varchar(50) NOT NULL DEFAULT '' COMMENT '园区名称',
  `park_score` int(11) NOT NULL DEFAULT '0' COMMENT '计分--游玩时可获得的分数',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='园区游玩扫码计分';

-- ----------------------------
-- Table structure for redeem_info
-- ----------------------------
DROP TABLE IF EXISTS `redeem_info`;
CREATE TABLE `redeem_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '游玩者id',
  `user_score` int(11) NOT NULL DEFAULT '0' COMMENT '游玩获得的总分数',
  `quantity` int(11) NOT NULL DEFAULT '0' COMMENT '获得的刮刮卡数量',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='兑奖信息记录';





truncate table park_worker;




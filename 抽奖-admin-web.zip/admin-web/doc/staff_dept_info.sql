/*
Navicat MySQL Data Transfer

Source Server         : 106.14.220.206
Source Server Version : 50641
Source Host           : 106.14.220.206:3306
Source Database       : bilibili

Target Server Type    : MYSQL
Target Server Version : 50641
File Encoding         : 65001

Date: 2019-01-10 10:37:09
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for staff_dept_info
-- ----------------------------
DROP TABLE IF EXISTS `staff_dept_info`;
CREATE TABLE `staff_dept_info` (
  `dept_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '部门ID',
  `dept_name` varchar(255) DEFAULT NULL COMMENT '部门名称',
  `dept_desc` varchar(255) DEFAULT NULL COMMENT '部门描述',
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of staff_dept_info
-- ----------------------------
INSERT INTO `staff_dept_info` VALUES ('1', '主站运营中心', '695');
INSERT INTO `staff_dept_info` VALUES ('2', '游戏事业部', '494');
INSERT INTO `staff_dept_info` VALUES ('3', '超电文化', '203');
INSERT INTO `staff_dept_info` VALUES ('4', '主站技术中心', '202');
INSERT INTO `staff_dept_info` VALUES ('5', '电商事业部', '181');
INSERT INTO `staff_dept_info` VALUES ('6', '直播事业部', '120');
INSERT INTO `staff_dept_info` VALUES ('7', '动画制作部', '107');
INSERT INTO `staff_dept_info` VALUES ('8', '商业产品部', '94');
INSERT INTO `staff_dept_info` VALUES ('9', '直播技术部', '86');
INSERT INTO `staff_dept_info` VALUES ('10', '测试中心', '81');
INSERT INTO `staff_dept_info` VALUES ('11', '运维部', '75');
INSERT INTO `staff_dept_info` VALUES ('12', '广告营销部', '69');
INSERT INTO `staff_dept_info` VALUES ('13', 'OGV运营部', '66');
INSERT INTO `staff_dept_info` VALUES ('14', '产品部', '66');
INSERT INTO `staff_dept_info` VALUES ('15', '火鸟项目部', '53');
INSERT INTO `staff_dept_info` VALUES ('16', '人工智能部', '45');
INSERT INTO `staff_dept_info` VALUES ('17', '哔哩哔哩电竞', '44');
INSERT INTO `staff_dept_info` VALUES ('18', '人力资源部', '41');
INSERT INTO `staff_dept_info` VALUES ('19', '市场中心', '39');
INSERT INTO `staff_dept_info` VALUES ('20', 'B+技术部', '38');
INSERT INTO `staff_dept_info` VALUES ('21', 'BBQ', '38');
INSERT INTO `staff_dept_info` VALUES ('22', '云技术部', '38');
INSERT INTO `staff_dept_info` VALUES ('23', '设计中心', '37');
INSERT INTO `staff_dept_info` VALUES ('24', 'KATANA', '35');
INSERT INTO `staff_dept_info` VALUES ('25', '财务部+投资者关系部', '35');
INSERT INTO `staff_dept_info` VALUES ('26', '数据平台部', '30');
INSERT INTO `staff_dept_info` VALUES ('27', '法务部', '20');
INSERT INTO `staff_dept_info` VALUES ('28', '版权合作部', '19');
INSERT INTO `staff_dept_info` VALUES ('29', '商务中心', '19');
INSERT INTO `staff_dept_info` VALUES ('30', '公共事务部', '17');
INSERT INTO `staff_dept_info` VALUES ('31', '行政服务部', '16');
INSERT INTO `staff_dept_info` VALUES ('32', '游戏社区部', '15');
INSERT INTO `staff_dept_info` VALUES ('33', '影业', '14');
INSERT INTO `staff_dept_info` VALUES ('34', '视频部', '10');
INSERT INTO `staff_dept_info` VALUES ('35', '采购中心', '6');
INSERT INTO `staff_dept_info` VALUES ('36', '平台架构部', '5');
INSERT INTO `staff_dept_info` VALUES ('37', '企业发展部', '3');
INSERT INTO `staff_dept_info` VALUES ('38', ' 台湾分部', '31');
INSERT INTO `staff_dept_info` VALUES ('39', '日本分部', '41');

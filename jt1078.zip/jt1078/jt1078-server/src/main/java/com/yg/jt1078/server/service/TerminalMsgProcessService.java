package com.yg.jt1078.server.service;


import com.alibaba.fastjson.JSON;
import com.yg.jt1078.redis.service.RedisService;
import com.yg.jt1078.server.service.codec.MsgEncoder;
import com.yg.jt1078.server.session.SessionManager;
import com.yg.jt1078.server.util.DigestUtils;
import com.yg.jt1078.server.vo.PackageData;
import com.yg.jt1078.server.vo.PackageData.MsgHeader;
import com.yg.jt1078.server.vo.Session;
import com.yg.jt1078.server.vo.req.LocationInfoUploadMsg;
import com.yg.jt1078.server.vo.req.TerminalAuthenticationMsg;
import com.yg.jt1078.server.vo.req.TerminalRegisterMsg;
import com.yg.jt1078.server.vo.resp.ServerCommonRespMsgBody;
import com.yg.jt1078.server.vo.resp.TerminalRegisterMsgRespBody;
import com.yg.jt1078.mq.service.RocketMQService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TerminalMsgProcessService extends BaseMsgProcessService {

    private final Logger log = LoggerFactory.getLogger(getClass());
    private MsgEncoder msgEncoder;
    private SessionManager sessionManager;

    @Autowired
    private RocketMQService rocketMQService;
    
    @Autowired
    private RedisService redisService;
    
    public TerminalMsgProcessService() {
    	
        this.msgEncoder = new MsgEncoder();
        this.sessionManager = SessionManager.getInstance();
    }

    public void processRegisterMsg(TerminalRegisterMsg msg, byte[] body) throws Exception {
        log.debug("终端注册:{}", JSON.toJSONString(msg, true));

        final String sessionId = Session.buildId(msg.getChannel());
        Session session = sessionManager.findBySessionId(sessionId);
        if (session == null) {
            session = Session.buildSession(msg.getChannel(), msg.getMsgHeader().getTerminalPhone());
        }
        session.setAuthenticated(true);
        session.setTerminalPhone(msg.getMsgHeader().getTerminalPhone());
        sessionManager.put(session.getId(), session);

        TerminalRegisterMsgRespBody respMsgBody = new TerminalRegisterMsgRespBody();
        respMsgBody.setReplyCode(TerminalRegisterMsgRespBody.success);
        respMsgBody.setReplyFlowId(msg.getMsgHeader().getFlowId());
        // TODO 1、鉴权码设计:请求body摘要 2、分布式支持(redis hash缓存/持久化) 3、注册记录视业务需要是否持久化(redis/mysql)  4、放Redis，放MQ 这两步异常情况的处理方式
        //add by huangwei 180416
        String token =String.valueOf(DigestUtils.digestCRC32(body));
//        RedisService redisService = SpringUtils.getBean(RedisService.class);
        redisService.putToken(msg.getMsgHeader().getTerminalPhone(), token);
        rocketMQService.putToken(token);
        
//        respMsgBody.setReplyToken(String.valueOf(DigestUtils.digestCRC32(body)));
        respMsgBody.setReplyToken(token);
        int flowId = super.getFlowId(msg.getChannel());
        byte[] bs = this.msgEncoder.encode4TerminalRegisterResp(msg, respMsgBody, flowId);

        super.send2Client(msg.getChannel(), bs);
    }

    
    public void processAuthMsg(TerminalAuthenticationMsg msg) throws Exception {
        log.debug("终端鉴权:{}", JSON.toJSONString(msg, true));

        final String sessionId = Session.buildId(msg.getChannel());
        Session session = sessionManager.findBySessionId(sessionId);
        if (session == null) {
            session = Session.buildSession(msg.getChannel(), msg.getMsgHeader().getTerminalPhone());
        }
        session.setAuthenticated(true);
        session.setTerminalPhone(msg.getMsgHeader().getTerminalPhone());
        sessionManager.put(session.getId(), session);
//        RedisService redisService = SpringUtils.getBean(RedisService.class);
        //请求中唯一识别码(最好是终端ID)只有请求头中的手机号
        boolean exists=redisService.existsToken(msg.getMsgHeader().getTerminalPhone(), msg.getAuthCode());
        // TODO 1、暂时每次鉴权都成功 2、分布式 3、鉴权记录(上线记录)视业务需要是否持久化(MQ异步)
        ServerCommonRespMsgBody respMsgBody = new ServerCommonRespMsgBody();
        respMsgBody.setReplyCode(ServerCommonRespMsgBody.success);
        respMsgBody.setReplyFlowId(msg.getMsgHeader().getFlowId());
        respMsgBody.setReplyId(msg.getMsgHeader().getMsgId());
        int flowId = super.getFlowId(msg.getChannel());
        byte[] bs = this.msgEncoder.encode4ServerCommonRespMsg(msg, respMsgBody, flowId);
        super.send2Client(msg.getChannel(), bs);
    }

    public void processTerminalHeartBeatMsg(PackageData req) throws Exception {
        log.debug("心跳信息:{}", JSON.toJSONString(req, true));
        final MsgHeader reqHeader = req.getMsgHeader();
        ServerCommonRespMsgBody respMsgBody = new ServerCommonRespMsgBody(reqHeader.getFlowId(), reqHeader.getMsgId(),
                ServerCommonRespMsgBody.success);
        int flowId = super.getFlowId(req.getChannel());
        byte[] bs = this.msgEncoder.encode4ServerCommonRespMsg(req, respMsgBody, flowId);
        super.send2Client(req.getChannel(), bs);
    }

    public void processTerminalLogoutMsg(PackageData req) throws Exception {
        log.info("终端注销:{}", JSON.toJSONString(req, true));
        final MsgHeader reqHeader = req.getMsgHeader();
        //TODO 注销记录（终端注销暂时先不做）
        ServerCommonRespMsgBody respMsgBody = new ServerCommonRespMsgBody(reqHeader.getFlowId(), reqHeader.getMsgId(),
                ServerCommonRespMsgBody.success);
        int flowId = super.getFlowId(req.getChannel());
        byte[] bs = this.msgEncoder.encode4ServerCommonRespMsg(req, respMsgBody, flowId);
        super.send2Client(req.getChannel(), bs);
    }

    public void processLocationInfoUploadMsg(LocationInfoUploadMsg req) throws Exception {
        log.debug("位置 信息:{}", JSON.toJSONString(req, true));
        final MsgHeader reqHeader = req.getMsgHeader();
        //TODO  1、消息异步接入MQ 2、后端应用服务异步消费
        ServerCommonRespMsgBody respMsgBody = new ServerCommonRespMsgBody(reqHeader.getFlowId(), reqHeader.getMsgId(),
                ServerCommonRespMsgBody.success);
        int flowId = super.getFlowId(req.getChannel());
        byte[] bs = this.msgEncoder.encode4ServerCommonRespMsg(req, respMsgBody, flowId);
        super.send2Client(req.getChannel(), bs);
    }
}

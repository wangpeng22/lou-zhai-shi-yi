package com.yg.jt1078.server.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.MessageDigest;
import java.util.zip.CRC32;

public class DigestUtils {

	private static final Logger logger = LoggerFactory.getLogger(DigestUtils.class);

	public static void main(String[] args) {
		String s="dsfwerasdfdsf";
		System.out.println(digestSHA1(s.getBytes()));
		System.out.println(digestCRC32(s.getBytes()));;
	}

	public static long digestCRC32(byte[] bytes) {
		CRC32 crc32 = new CRC32();
		crc32.update(bytes);
		return crc32.getValue();
	}

	public static String digestSHA1(byte[] bytes) {
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("SHA1");
			messageDigest.update(bytes);
			byte[] shaBytes = messageDigest.digest();
			return HexStringUtils.toHexString(shaBytes);
		} catch (Exception e) {
			logger.error("");
		}
		return null;
	}

}

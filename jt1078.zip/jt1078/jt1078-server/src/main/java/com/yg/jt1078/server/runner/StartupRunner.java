package com.yg.jt1078.server.runner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

/**
 * 实现ApplicationRunner也可实现服务启动完成后执行指定操作
 */
@Profile("dev")
@Component
public class StartupRunner implements CommandLineRunner {
	private static final Logger logger = LoggerFactory.getLogger(StartupRunner.class.getName());

	@Override
	public void run(String... arg0) throws Exception {
		logger.info("服务启动完成!");
	}

}

package com.yg.jt1078.server;

import com.yg.jt1078.server.common.Consts;
import com.yg.jt1078.server.service.codec.Decoder4LoggingOnly;
import com.yg.jt1078.server.service.handler.TCPServerHandler;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.DelimiterBasedFrameDecoder;
import io.netty.handler.timeout.IdleStateHandler;
import io.netty.util.concurrent.Future;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import javax.annotation.PostConstruct;
import java.util.concurrent.TimeUnit;

@SpringBootApplication
@ComponentScan("com.yg.jt1078")
public class JT1078Server {

	private static final Logger log = LoggerFactory.getLogger(JT1078Server.class);

	private EventLoopGroup bossGroup = null;
	private EventLoopGroup workerGroup = null;
	@Value("${tcp.port}")
	private int port;

	@Autowired
	private TCPServerHandler tcpServerHandler;
	
	public JT1078Server() {
	}

	public JT1078Server(int port) {
		this();
		this.port = port;
	}

	private void bind() throws Exception {
		this.bossGroup = new NioEventLoopGroup();
		this.workerGroup = new NioEventLoopGroup();
		ServerBootstrap serverBootstrap = new ServerBootstrap();
		serverBootstrap.group(bossGroup, workerGroup)//
				.channel(NioServerSocketChannel.class) //
				.childHandler(new ChannelInitializer<SocketChannel>() { //
					@Override
					public void initChannel(SocketChannel ch) throws Exception {
						ch.pipeline().addLast("idleStateHandler",
								new IdleStateHandler(Consts.client_idle_minutes, 0, 0, TimeUnit.MINUTES));
						ch.pipeline().addLast(new Decoder4LoggingOnly());
						// 1024表示单条消息的最大长度，解码器在查找分隔符的时候，达到该长度还没找到的话会抛异常
						ch.pipeline().addLast(
								new DelimiterBasedFrameDecoder(1024, Unpooled.copiedBuffer(new byte[] { 0x7e }),
										Unpooled.copiedBuffer(new byte[] { 0x7e, 0x7e })));
						// ch.pipeline().addLast(new PackageDataDecoder());
//						ch.pipeline().addLast(new TCPServerHandler());
						ch.pipeline().addLast(tcpServerHandler);
					}
				}).option(ChannelOption.SO_BACKLOG, 128) //
				.childOption(ChannelOption.SO_KEEPALIVE, true);

		this.log.info("TCP服务启动完毕,port={}", this.port);
		ChannelFuture channelFuture = serverBootstrap.bind(port).sync();

		// channelFuture.channel().closeFuture().sync();
	}

	@PostConstruct
	public synchronized void startServer() throws Exception {
		log.info("TCP服务开始启动...");
		this.bind();
	}

	public synchronized void stopServer() {

		try {
			Future<?> future = this.workerGroup.shutdownGracefully().await();
			if (!future.isSuccess()) {
				log.error("workerGroup 无法正常停止:{}", future.cause());
			}

			future = this.bossGroup.shutdownGracefully().await();
			if (!future.isSuccess()) {
				log.error("bossGroup 无法正常停止:{}", future.cause());
			}
		} catch (InterruptedException e) {

		}
		log.info("TCP服务已经停止...");
	}

	/*@Bean
	public RedisService redisService() {
		return new RedisService();
	}*/

	public static void main(String[] args) throws Exception {

		SpringApplication.run(JT1078Server.class, args);
	}
}
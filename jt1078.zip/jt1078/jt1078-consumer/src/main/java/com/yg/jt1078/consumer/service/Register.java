package com.yg.jt1078.consumer.service;


import com.yg.jt1078.consumer.common.CommonData;
import com.yg.jt1078.consumer.mapper.CommonMapper;
import org.apache.rocketmq.spring.starter.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.starter.core.RocketMQListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author 少昊
 * @date 2018/4/16
 * 注册登陆
 */
@Service
@RocketMQMessageListener(topic = "11", consumerGroup = "jt1078-consumer-register")
public class Register implements RocketMQListener<String> {
    @Autowired
    private CommonMapper commonMapper;
    public void onMessage(String message) {
        System.out.println(message);
        Map<String,Object> map=new HashMap<>();
        map.put("opt_type", CommonData.REGISTER);
        map.put("opt_deviceId","231");
        map.put("opt_content",message);
        map.put("opt_time",new Date(System.currentTimeMillis()));
        commonMapper.insertData(map);
    }
}

package com.yg.jt1078.consumer;

import org.mybatis.spring.annotation.MapperScan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(value = "com.yg.jt1078.consumer.mapper")
public class Jt1078Consumer {
	private static final Logger  log =LoggerFactory.getLogger(Jt1078Consumer.class);
	public static void main(String[] args) {
		SpringApplication.run(Jt1078Consumer.class, args);
	}
	 
 }

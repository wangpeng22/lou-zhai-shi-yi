package com.yg.jt1078.consumer.common;

/**
 * @author 少昊
 * @date 2018/4/16
 */
public class CommonData {
    public static final int REGISTER = 0;
    public static final int AUTHENTICATION = 1;
    public static final int REPORT = 2;


}

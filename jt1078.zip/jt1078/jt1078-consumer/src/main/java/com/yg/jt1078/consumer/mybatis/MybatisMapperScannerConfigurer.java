package com.yg.jt1078.consumer.mybatis;

import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@AutoConfigureAfter({MybatisAutoConfigurer.class})
public class MybatisMapperScannerConfigurer  {
    
    @Bean
    public MapperScannerConfigurer mapperScanner() {
        MapperScannerConfigurer scanner=new MapperScannerConfigurer();
        scanner.setSqlSessionFactoryBeanName("sqlSessionFactory");
        scanner.setBasePackage("com.yg.jt808.consumer.com.yu.jt1078.consumer.mapper");
        return scanner;
    }

     

}

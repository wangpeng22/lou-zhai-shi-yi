package com.yg.jt1078.consumer.mapper;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface CommonMapper {

    List<Object> selectAll();
    void insertData(Map<String, Object> map);
}
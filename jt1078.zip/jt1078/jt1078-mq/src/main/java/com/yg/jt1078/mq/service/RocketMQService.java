package com.yg.jt1078.mq.service;

import org.apache.rocketmq.spring.starter.core.RocketMQTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class RocketMQService {

	static final Logger log = LoggerFactory.getLogger(RocketMQService.class);
	
	@Autowired
	private  RocketMQTemplate  rocketMQTemplate;
	
	class  RocketMQTopic{
		public static final String SEVER_AUTH_TOKEN = "test";
	}
	
	/**
	 * 将鉴权码放入MQ队列等待消费
	 * @param message
	 */
	public void putToken(String token) {
		try {
			rocketMQTemplate.convertAndSend(RocketMQTopic.SEVER_AUTH_TOKEN, token);
		}catch(Exception e) {
			log.error("鉴权码放入MQ失败！",e);
		}
	}
}

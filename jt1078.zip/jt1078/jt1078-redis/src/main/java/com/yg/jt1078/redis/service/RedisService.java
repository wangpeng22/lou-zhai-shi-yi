package com.yg.jt1078.redis.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class RedisService {

	static final Logger log = LoggerFactory.getLogger(RedisService.class);

	@Autowired
	private RedisTemplate<String, String> redisTemplate;

	class RedisKey {
		public static final String SERVER_AUTH_TOKEN = "server_auth_token";
	}

	/**
	 * 查询鉴权码是否存在
	 * 
	 * @param phoneNo
	 *            终端唯一识别码
	 * @param token
	 *            授权码
	 * @return
	 */
	public boolean existsToken(String phoneNo, String token) {
		// map的key、field
		Object value = redisTemplate.opsForHash().get(RedisKey.SERVER_AUTH_TOKEN, phoneNo);
		if (null == value) {
			return false;
		}
		return value.toString().equals(token);
	}

	/**
	 * 将鉴权码存入Redis
	 * 
	 * @param phoneNo
	 * @param token
	 */
	public void putToken(String phoneNo, String token) {
		try {
			if (StringUtils.isEmpty(phoneNo) || StringUtils.isEmpty(token)) {
				log.info("参数错误:phoneNo:{},token:{},无法将当前的token信息放入Redis！", phoneNo, token);
				return;
			}
			// 在号码和鉴权信息都不为null值的情况下，才执行put操作
			redisTemplate.opsForHash().put(RedisKey.SERVER_AUTH_TOKEN, phoneNo, token);
		} catch (Exception e) {
			log.error("鉴权码放入Redis异常！", e);
		}
	}
}

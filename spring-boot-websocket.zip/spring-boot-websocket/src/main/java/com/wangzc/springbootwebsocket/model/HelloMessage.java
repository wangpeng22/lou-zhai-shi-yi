package com.wangzc.springbootwebsocket.model;

import lombok.Data;

/**
 * 消息模板
 *
 * @author wang_zc
 * @date 2018/9/27
 */
@Data
public class HelloMessage {

    private String name;

    public HelloMessage(String name) {
        this.name = name;
    }
}

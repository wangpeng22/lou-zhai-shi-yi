package com.wangzc.springbootwebsocket.model;

import lombok.Data;

import java.util.Date;

/**
 * 时间模板
 *
 * @author wang_zc
 * @date 2018/9/27
 */
@Data
public class DateMessage {

    private Date date;

    public DateMessage(Date date) {
        this.date = date;
    }
}

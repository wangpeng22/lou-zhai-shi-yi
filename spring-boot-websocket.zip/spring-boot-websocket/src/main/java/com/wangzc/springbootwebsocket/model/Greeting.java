package com.wangzc.springbootwebsocket.model;

import lombok.Data;

/**
 * 问候模板
 *
 * @author wang_zc
 * @date 2018/9/27
 */
@Data
public class Greeting {

    private String content;

    public Greeting(String content) {
        this.content = content;
    }
}

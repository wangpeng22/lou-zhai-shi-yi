package com.wangzc.springbootwebsocket.controller;

import com.wangzc.springbootwebsocket.model.Greeting;
import com.wangzc.springbootwebsocket.model.HelloMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.web.util.HtmlUtils;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 问候控制器
 *
 * @author wang_zc
 * @date 2018/9/27
 */
@Slf4j
@Controller
public class GreetingController {

    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private final SimpMessagingTemplate messagingTemplate;

    public GreetingController(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }


    @MessageMapping("/hello")
    @SendTo("/topic/greetings")
    public Greeting greeting(HelloMessage message) throws InterruptedException {
        Thread.sleep(1000);
        log.info("执行greeting方法，获取到message的name为{}", message.getName());
        return new Greeting("Hello, " + HtmlUtils.htmlEscape(message.getName()) + "!");
    }

    @Scheduled(cron = "0/5 * * * * ? ")
    public void greeting() {
        log.info("执行greeting方法，获取到message的date为{}", sdf.format(new Date()));
        messagingTemplate.convertAndSend("/topic/greetings", new Greeting(HtmlUtils.htmlEscape(sdf.format(new Date()))));
    }

}

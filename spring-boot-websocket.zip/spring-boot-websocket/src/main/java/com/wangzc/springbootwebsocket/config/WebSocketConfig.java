package com.wangzc.springbootwebsocket.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

/**
 * WebSocket配置类
 *
 * EnableWebSocketMessageBroker：由消息代理支持的WebSocket消息处理。
 *
 * @author wang_zc
 * @date 2018/9/27
 */
@Configuration
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {

    /**
     * 注册"/gs-guide-websocket"端点
     * 启用SockJS后备选项，以便在WebSocket不可用时可以使用备用传输。
     * SockJS客户端将尝试连接到"/gs-guide-websocket"并使用可用的最佳传输（websocket，xhr-streaming，xhr-polling等）。
     *
     * @author wang_zc
     */
    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/gs-guide-websocket").withSockJS();
    }

    /**
     * 配置消息代理
     *
     * @author wang_zc
     */
    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        // 在前缀为"/topic"的目标上将问候消息传回客户端
        config.enableSimpleBroker("/topic");
        // 定义所有消息映射
        config.setApplicationDestinationPrefixes("/app");
    }
}

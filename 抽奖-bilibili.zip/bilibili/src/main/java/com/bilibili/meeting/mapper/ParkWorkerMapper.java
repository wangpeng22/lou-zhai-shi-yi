/** 
* Created by bzyx on 2018-12-19 
*/
package com.bilibili.meeting.mapper;

import com.bilibili.meeting.model.ParkWorker;

import java.util.List;

public interface ParkWorkerMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ParkWorker record);

    int insertSelective(ParkWorker record);

    ParkWorker selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ParkWorker record);

    int updateByPrimaryKey(ParkWorker record);

    List<ParkWorker> findAllWorker(int workerType);
}
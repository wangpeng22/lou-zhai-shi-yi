package com.bilibili.meeting.service.impl;

import com.bilibili.meeting.core.ResultCode;
import com.bilibili.meeting.dto.*;
import com.bilibili.meeting.exception.BusinessException;
import com.bilibili.meeting.mapper.*;
import com.bilibili.meeting.model.*;
import com.bilibili.meeting.service.ActivityService;
import com.bilibili.meeting.utils.AssertUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Created by wangpeng on 2018/12/19 17:51
 */
@Service
public class ActivityServiceImpl implements ActivityService {

    @Autowired
    private ActivityBaseInfoMapper activityBaseInfoMapper;

    @Autowired
    private ActivityPrizeInfoMapper activityPrizeInfoMapper;

    @Autowired
    private PrizeInfoMapper prizeInfoMapper;

    @Autowired
    private ActivityVoteInfoMapper activityVoteInfoMapper;

    @Autowired
    private ActivityUserVoteMapper activityUserVoteMapper;

    @Autowired
    private ActivityLuckyDogInfoMapper activityLuckyDogInfoMapper;

    /**
     * 投票
     *
     * @param activityUserVoteDTO
     */
    @Override
    public void voting(ActivityUserVoteDTO activityUserVoteDTO) {
        AssertUtil.isNull(activityUserVoteDTO, "缺少参数");
        AssertUtil.isNull(activityUserVoteDTO.getActivityId(), "缺少activityId参数");
        AssertUtil.isNull(activityUserVoteDTO.getVoteId(), "缺少voteId参数");
        AssertUtil.isNull(activityUserVoteDTO.getUserId(), "缺少userId参数");
        ActivityBaseInfo activityBaseInfo = activityBaseInfoMapper.selectByPrimaryKey(activityUserVoteDTO.getActivityId());
        if (null == activityBaseInfo) {
            throw new BusinessException(ResultCode.ACTIVITY_NOT_EXIST.getCode(), ResultCode.ACTIVITY_NOT_EXIST.getMsg());
        }
        switch (activityBaseInfo.getStatus()) {
            case 1:
            case 4:
            case 5:
                throw new BusinessException(ResultCode.ACTIVITY_NOT_EXIST.getCode(), ResultCode.ACTIVITY_NOT_EXIST.getMsg());
            case 6:
                throw new BusinessException(ResultCode.ACTIVITY_NOT_BEGIN.getCode(), "投票还没开始");
            case 7:
                ActivityUserVote activityUserVote = new ActivityUserVote();
                activityUserVote.setActivityId(activityUserVoteDTO.getActivityId());
                activityUserVote.setUserId(activityUserVoteDTO.getStaffId());
                activityUserVote.setVoteId(activityUserVoteDTO.getVoteId());
                try {
                    activityUserVoteMapper.insertSelective(activityUserVote);
                }
                catch (Exception e){
                    if (e instanceof DuplicateKeyException) {
                        throw new BusinessException(ResultCode.ACTIVITY_VOTED.getCode(), "已经投过票");
                    } else {
                        e.printStackTrace();
                    }
                }
                break;
            case 8:
                throw new BusinessException(ResultCode.ACTIVITY_END.getCode(), "投票已经结束");
        }
    }

    /**
     * 抽奖活动详情
     * @param activitySearchDTO
     * @return
     */
    @Override
    public ActivityVoteDTO getActivityVote(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getStaffId(), "缺少staffId参数");

        ActivityBaseInfoExample example = new ActivityBaseInfoExample();
        example.createCriteria().andStatusIn(Arrays.asList(6, 7, 8));
        example.setOrderByClause("update_time asc");
        List<ActivityBaseInfo> activityBaseInfoList = activityBaseInfoMapper.selectByExample(example);
        if (null == activityBaseInfoList || 0 >= activityBaseInfoList.size()) {
            throw new BusinessException(ResultCode.ACTIVITY_NOT_BEGIN.getCode(), "节目还没有开始！");
        }

        ActivityBaseInfo activityBaseInfo = null;
        Integer status = 10;
        for (ActivityBaseInfo baseInfo : activityBaseInfoList) {
            if (status >= baseInfo.getStatus()) {
                status = baseInfo.getStatus();
                activityBaseInfo = baseInfo;
            }
        }

        if (null == activityBaseInfo ) {
            throw new BusinessException(ResultCode.ACTIVITY_NOT_EXIST.getCode(), ResultCode.ACTIVITY_NOT_EXIST.getMsg());
        }

        ActivityVoteDTO activityVoteDTO = new ActivityVoteDTO();
        activityVoteDTO.setActivityBaseInfo(activityBaseInfo);

        // 投票活动
        // 查询战队信息
        ActivityVoteInfoExample activityVoteInfoExample = new ActivityVoteInfoExample();
        activityVoteInfoExample.createCriteria().andActivityIdEqualTo(activityBaseInfo.getId());
        List<ActivityVoteInfo> activityVoteInfoList = activityVoteInfoMapper.selectByExample(activityVoteInfoExample);
        if (null != activityVoteInfoList && 0 < activityVoteInfoList.size()) {
            for (ActivityVoteInfo activityVoteInfo : activityVoteInfoList) {
                ActivityUserVoteExample activityUserVoteExample = new ActivityUserVoteExample();
                activityUserVoteExample
                        .createCriteria()
                        .andActivityIdEqualTo(activityVoteInfo.getActivityId())
                        .andVoteIdEqualTo(activityVoteInfo.getId());
                activityVoteInfo.setVoteNumber(activityUserVoteMapper.countByExample(activityUserVoteExample));
            }
        }
        activityVoteDTO.setActivityVoteInfoList(activityVoteInfoList);

        // 查询用户投票信息
        ActivityUserVoteKey activityUserVoteKey = new ActivityUserVoteKey();
        activityUserVoteKey.setActivityId(activityBaseInfo.getId());
        activityUserVoteKey.setUserId(activitySearchDTO.getStaffId());
        ActivityUserVote activityUserVote = activityUserVoteMapper.selectByPrimaryKey(activityUserVoteKey);
        activityVoteDTO.setActivityUserVote(activityUserVote);

        return activityVoteDTO;
    }

    /**
     * "我的奖品"
     *
     * @param activitySearchDTO
     *
     * @return
     */
    @Override
    public List<ActivityPrizeWinningDTO> myPrize(ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getStaffId(), "缺少staffId参数");

        ActivityLuckyDogInfoExample example = new ActivityLuckyDogInfoExample();
        ActivityLuckyDogInfoExample.Criteria criteria = example.createCriteria();
        criteria.andStatusEqualTo(1)
                .andUserIdEqualTo(activitySearchDTO.getStaffId());
        if (null != activitySearchDTO.getActivityId()) {
            criteria.andActivityIdEqualTo(activitySearchDTO.getActivityId());
        }
        if (null != activitySearchDTO.getActivityPrizeId()) {
            criteria.andActivityPrizeIdEqualTo(activitySearchDTO.getActivityPrizeId());
        }
        List<ActivityLuckyDogInfo> activityLuckyDogInfoList = activityLuckyDogInfoMapper.selectByExample(example);
        if (null == activityLuckyDogInfoList || 0 >= activityLuckyDogInfoList.size()) {
            return null;
        }

        List<ActivityPrizeWinningDTO> activityPrizeWinningDTOList = new ArrayList<>();

        for (ActivityLuckyDogInfo activityLuckyDogInfo : activityLuckyDogInfoList) {
            ActivityPrizeInfo activityPrizeInfo = activityPrizeInfoMapper.selectByPrimaryKey(activityLuckyDogInfo.getActivityPrizeId());

            if (null != activityPrizeInfo && 4 == activityPrizeInfo.getStatus()) {
                // 活动结束
                ActivityPrizeWinningDTO activityPrizeWinningDTO = new ActivityPrizeWinningDTO();
                activityPrizeWinningDTO.setWinningTime(activityLuckyDogInfo.getWinningTime());
                activityPrizeWinningDTO.setReceiveFlag(activityLuckyDogInfo.getReceiveFlag());
                activityPrizeWinningDTO.setReceiveTime(activityLuckyDogInfo.getReceiveTime());

                ActivityBaseInfo activityBaseInfo = activityBaseInfoMapper.selectByPrimaryKey(activityLuckyDogInfo.getActivityId());
                if (null != activityBaseInfo) {
                    activityPrizeWinningDTO.setActivityId(activityBaseInfo.getId());
                    activityPrizeWinningDTO.setActivityName(activityBaseInfo.getActivityName());
                    activityPrizeWinningDTO.setActivityDesc(activityBaseInfo.getActivityDesc());
                    activityPrizeWinningDTO.setActivityType(activityBaseInfo.getActivityType());
                }
                PrizeInfo prizeInfo = prizeInfoMapper.selectByPrimaryKey(activityPrizeInfo.getPrizeId());
                activityPrizeWinningDTO.setPrizeInfo(prizeInfo);

                activityPrizeWinningDTOList.add(activityPrizeWinningDTO);
            }
        }
        return activityPrizeWinningDTOList;
    }
}
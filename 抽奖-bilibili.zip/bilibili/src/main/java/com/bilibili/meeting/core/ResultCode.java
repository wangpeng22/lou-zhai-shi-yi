package com.bilibili.meeting.core;

/**
 * 响应码枚举，参考HTTP状态码的语义
 * @author
 * @date 2018-12-18 16:08:27
 */
public enum ResultCode {

    MISSINGARGS(1002,"参数不全"),

    ACTIVITY_LOTTERY_OPEN(8004, "活动已经开奖"),
    ACTIVITY_VOTED(8003, "活动已经投票"),
    ACTIVITY_END(8002, "活动已经结束"),
    ACTIVITY_NOT_BEGIN(8001, "活动没有开始"),
    ACTIVITY_NOT_EXIST(8000, "活动不存在"),
    NOT_LOGGED_IN(1, "未登录"),
    NOT_LOGGED_IN_WORKER(2, "工作人员未登录"),
    SUCCESS(200,"请求成功"),//成功
    FAIL(400,"请求的地址不存在或者包含不支持的参数"),//失败
    NOT_FOUND(404,"请求的资源不存在"),//接口不存在
    INTERNAL_SERVER_ERROR(500,"服务器内部错误"),//服务器内部错误
    INVALID_USERNAME_PASSWORD(1011, "用户名或密码错误"),
    SYSTEMNEEDLOG(1012,"请添加记录日志信息"),
    UNAUTHORIZED(401,"未授权"),//未认证（签名错误）
    UNAUTHORIZEDWORKER(402,"工作人员未授权"),//未认证（签名错误）
    ISEMPTY(1022,"停车券已被抢完"),
    ISREPEAT(1024,"请勿重复抢停车券"),
    BUSISEMPTY(1023,"班车座位已被领完"),
    BUSISREPEAT(1025,"请勿重复领取班车座位"),
    USERISNULL(1026,"认证失败，用户不存在"),
    USERBYIDISNULL(1027,"用户不存在"),
    USERNOTENTERPRISE(1028,"非企业用户"),
    RESIGNUP(1029,"您已报名成功"),
    TIMEISOVER(1030,"报名已截止");


    private  int code;
    private  String msg;

    ResultCode(int code) {
        this.code = code;
    }
    ResultCode(int code,String msg) {
        this.code = code;
        this.msg=msg;
    }

    public int code() {
        return code;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}

package com.bilibili.meeting.web;

import com.bilibili.meeting.config.annotation.Log;
import com.bilibili.meeting.core.Result;
import com.bilibili.meeting.core.ResultCode;
import com.bilibili.meeting.core.ResultGenerator;
import com.bilibili.meeting.dto.*;
import com.bilibili.meeting.exception.BusinessException;
import com.bilibili.meeting.model.StaffInfo;
import com.bilibili.meeting.service.ActivityService;
import com.bilibili.meeting.service.UserService;
import com.bilibili.meeting.utils.AssertUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 活动控制器（接口提供给h5）
 * Created by wangpeng on 2018/12/19 17:02
 */
@RestController
@RequestMapping("/h5/activity")
public class ActivityH5Controller {

    @Autowired
    private ActivityService activityService;

    @Autowired
    private UserService userService;

    @RequestMapping(value = "/getactivityvote", method = RequestMethod.POST)
    @ResponseBody
    @Log
    public Result getActivityVote (@RequestBody ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getUserId(), "缺少userId参数");
        StaffInfo staffInfo = userService.getStaffInfoById(activitySearchDTO.getUserId());
        if (null == staffInfo) {
            throw new BusinessException(ResultCode.USERBYIDISNULL.getCode(), ResultCode.USERBYIDISNULL.getMsg());
        }
        activitySearchDTO.setStaffId(staffInfo.getStaffUuid());
        ActivityVoteDTO activityDTO = activityService.getActivityVote(activitySearchDTO);
        return ResultGenerator.genSuccessResult(activityDTO);
    }

    // 投票
    @RequestMapping(value = "/voting", method = RequestMethod.POST)
    @ResponseBody
    @Log
    public Result voting (@RequestBody ActivityUserVoteDTO activityUserVoteDTO) {
        AssertUtil.isNull(activityUserVoteDTO, "缺少参数");
        AssertUtil.isNull(activityUserVoteDTO.getUserId(), "缺少userId参数");
        StaffInfo staffInfo = userService.getStaffInfoById(activityUserVoteDTO.getUserId());
        if (null == staffInfo) {
            throw new BusinessException(ResultCode.USERBYIDISNULL.getCode(), ResultCode.USERBYIDISNULL.getMsg());
        }
        activityUserVoteDTO.setStaffId(staffInfo.getStaffUuid());
        activityService.voting(activityUserVoteDTO);
        return ResultGenerator.genSuccessResult();
    }

    // "我的奖品"
    @RequestMapping(value = "/myprize", method = RequestMethod.POST)
    @ResponseBody
    @Log
    public Result myPrize (@RequestBody ActivitySearchDTO activitySearchDTO) {
        AssertUtil.isNull(activitySearchDTO, "缺少参数");
        AssertUtil.isNull(activitySearchDTO.getUserId(), "缺少userId参数");
        StaffInfo staffInfo = userService.getStaffInfoById(activitySearchDTO.getUserId());
        if (null == staffInfo) {
            throw new BusinessException(ResultCode.USERBYIDISNULL.getCode(), ResultCode.USERBYIDISNULL.getMsg());
        }
        activitySearchDTO.setStaffId(staffInfo.getStaffUuid());
        List<ActivityPrizeWinningDTO> activityLuckyDogInfoList = activityService.myPrize(activitySearchDTO);
        return ResultGenerator.genSuccessResult(activityLuckyDogInfoList);
    }
}
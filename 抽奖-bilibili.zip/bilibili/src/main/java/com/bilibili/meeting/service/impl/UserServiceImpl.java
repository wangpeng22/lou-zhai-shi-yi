package com.bilibili.meeting.service.impl;

import com.bilibili.meeting.mapper.UserMapper;
import com.bilibili.meeting.model.StaffInfo;
import com.bilibili.meeting.service.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class UserServiceImpl implements UserService {

    @Resource
    private UserMapper userMapper;

    /**
     * 根据userId查询对应的数据信息
     * @param staffId
     * @return
     */
    @Override
    public StaffInfo getStaffInfoById(String staffId) {
        return userMapper.getStaffInfoById(staffId);
    }
    /**
     * 编辑员工信息
     */
    @Override
    public void editStaff(StaffInfo staffInfoa) {
        userMapper.editStaff(staffInfoa);
    }

    /**
     * 根据手机号码查询员工信息
     * @param mobile
     * @return
     */
    @Override
    public StaffInfo getStaffInfoByMobile(String mobile) {
        return userMapper.getStaffInfoByMobile(mobile);
    }

}
package com.bilibili.meeting.utils;

public enum EnumMessageType {
	text, music, news, mpnews, image, link, location, video, voice, event, thumb, file;
}

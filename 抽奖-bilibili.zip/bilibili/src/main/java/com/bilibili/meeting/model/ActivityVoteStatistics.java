package com.bilibili.meeting.model;

/**
 * 活动投票统计对象
 * Created by wangpeng on 2018/12/20 17:38
 */
public class ActivityVoteStatistics extends Base {

    // 活动id
    private Integer activityId;
    // 战队id
    private Integer voteId;
    // 得票数
    private Integer voteNumber;

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public Integer getVoteId() {
        return voteId;
    }

    public void setVoteId(Integer voteId) {
        this.voteId = voteId;
    }

    public Integer getVoteNumber() {
        return voteNumber;
    }

    public void setVoteNumber(Integer voteNumber) {
        this.voteNumber = voteNumber;
    }
}

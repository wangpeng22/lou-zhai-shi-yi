package com.bilibili.meeting.mapper;

import com.bilibili.meeting.model.StaffInfoCustomized;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by wangpeng on 2018/12/21 14:30
 */
@Repository
public interface StaffInfoCustomizedMapper {

    public Integer countValidUser(@Param("departmentIdList") List<Integer> departmentIdList);

    public List<StaffInfoCustomized> selectValidUser(@Param("departmentIdList") List<Integer> departmentIdList);

    public List<StaffInfoCustomized> selectByUserIdList(@Param("userIdList") List<Integer> userIdList);
}

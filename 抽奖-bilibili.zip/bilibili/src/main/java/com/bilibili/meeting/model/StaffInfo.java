/** 
 * 员工实体
*/
package com.bilibili.meeting.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;
public class StaffInfo implements Serializable {

    //员工ID
    private Integer staffUuid;
    // uuid
    private String staffId;

    //部门名称
    private String deptName;
    //员工姓名
    private String staffName;
    //所属部门ID
    private Integer deptId;
    //员工手机号
    private String staffPhone;
    //员工所在地
    private String staffAddress;
    //报名时间
    private Date staffRegistTime;
    //出行方式  0自行前往  1开车前往  2公司班车
    private Integer staffTripMode;
    //游玩状态 如：[2/9，0/1] （前面统计数量，0/1代表4个过山车有无完成）
    private String staffPlayState;
    //兑奖状态  0未兑奖   1已兑奖
    private Integer staffPrizeState;
    //座位信息
    private String staffPlaceInfo;
    //签到状态  0未签到  1已签到
    private Integer staffSignState;
    //员工二维码信息图片地址
    private String staffQrcodeUrl;
    //记录创建人
    private String creator;
    //记录创建时间
    private Date createTime;
    //道具领取状态 0未领取  1已领取
    private Integer staffRecevieState;
    //入园状态 0未入园   1已入园
    private Integer staffEnterState;

    public Integer getStaffUuid() {
        return staffUuid;
    }

    public void setStaffUuid(Integer staffUuid) {
        this.staffUuid = staffUuid;
    }

    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public Integer getDeptId() {
        return deptId;
    }

    public void setDeptId(Integer deptId) {
        this.deptId = deptId;
    }

    public String getStaffPhone() {
        return staffPhone;
    }

    public void setStaffPhone(String staffPhone) {
        this.staffPhone = staffPhone;
    }

    public String getStaffAddress() {
        return staffAddress;
    }

    public void setStaffAddress(String staffAddress) {
        this.staffAddress = staffAddress;
    }

    public Date getStaffRegistTime() {
        return staffRegistTime;
    }

    public void setStaffRegistTime(Date staffRegistTime) {
        this.staffRegistTime = staffRegistTime;
    }

    public Integer getStaffTripMode() {
        return staffTripMode;
    }

    public void setStaffTripMode(Integer staffTripMode) {
        this.staffTripMode = staffTripMode;
    }

    public String getStaffPlayState() {
        return staffPlayState;
    }

    public void setStaffPlayState(String staffPlayState) {
        this.staffPlayState = staffPlayState;
    }

    public Integer getStaffPrizeState() {
        return staffPrizeState;
    }

    public void setStaffPrizeState(Integer staffPrizeState) {
        this.staffPrizeState = staffPrizeState;
    }

    public String getStaffPlaceInfo() {
        return staffPlaceInfo;
    }

    public void setStaffPlaceInfo(String staffPlaceInfo) {
        this.staffPlaceInfo = staffPlaceInfo;
    }

    public Integer getStaffSignState() {
        return staffSignState;
    }

    public void setStaffSignState(Integer staffSignState) {
        this.staffSignState = staffSignState;
    }

    public String getStaffQrcodeUrl() {
        return staffQrcodeUrl;
    }

    public void setStaffQrcodeUrl(String staffQrcodeUrl) {
        this.staffQrcodeUrl = staffQrcodeUrl;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getStaffRecevieState() {
        return staffRecevieState;
    }

    public void setStaffRecevieState(Integer staffRecevieState) {
        this.staffRecevieState = staffRecevieState;
    }

    public Integer getStaffEnterState() {
        return staffEnterState;
    }

    public void setStaffEnterState(Integer staffEnterState) {
        this.staffEnterState = staffEnterState;
    }
}
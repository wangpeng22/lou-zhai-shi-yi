package com.bilibili.meeting.dto;

import com.bilibili.meeting.model.PrizeInfo;

import java.util.Date;

/**
 * 活动获奖DTO
 * Created by wangpeng on 2018/12/25 10:07
 */
public class ActivityPrizeWinningDTO extends BaseDTO {

    // 活动Id
    private Integer activityId;
    // 活动名称
    private String activityName;
    // 活动类型
    private Integer activityType;
    // 活动描述
    private String activityDesc;
    // 中奖时间
    private Date winningTime;
    // 领取标志  1-没有领奖 2-已经领奖
    private Integer receiveFlag;
    // 领取时间
    private Date receiveTime;
    // 奖品
    private PrizeInfo prizeInfo;

    public Integer getActivityType() {
        return activityType;
    }

    public void setActivityType(Integer activityType) {
        this.activityType = activityType;
    }

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getActivityDesc() {
        return activityDesc;
    }

    public void setActivityDesc(String activityDesc) {
        this.activityDesc = activityDesc;
    }

    public Date getWinningTime() {
        return winningTime;
    }

    public void setWinningTime(Date winningTime) {
        this.winningTime = winningTime;
    }

    public Integer getReceiveFlag() {
        return receiveFlag;
    }

    public void setReceiveFlag(Integer receiveFlag) {
        this.receiveFlag = receiveFlag;
    }

    public Date getReceiveTime() {
        return receiveTime;
    }

    public void setReceiveTime(Date receiveTime) {
        this.receiveTime = receiveTime;
    }

    public PrizeInfo getPrizeInfo() {
        return prizeInfo;
    }

    public void setPrizeInfo(PrizeInfo prizeInfo) {
        this.prizeInfo = prizeInfo;
    }
}

/** 
* Created by bzyx on 2018-12-19 
*/
package com.bilibili.meeting.mapper;

import com.bilibili.meeting.model.RedeemInfo;

public interface RedeemInfoMapper {
    int deleteByPrimaryKey(Long id);

    int insert(RedeemInfo record);

    int insertSelective(RedeemInfo record);

    RedeemInfo selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(RedeemInfo record);

    int updateByPrimaryKey(RedeemInfo record);

    RedeemInfo getRedeem(int id);
}
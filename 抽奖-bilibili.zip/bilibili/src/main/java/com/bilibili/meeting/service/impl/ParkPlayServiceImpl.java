package com.bilibili.meeting.service.impl;

import com.bilibili.meeting.mapper.ParkInfoMapper;
import com.bilibili.meeting.mapper.ParkPlayMapper;
import com.bilibili.meeting.mapper.RedeemInfoMapper;
import com.bilibili.meeting.mapper.UserMapper;
import com.bilibili.meeting.model.*;
import com.bilibili.meeting.service.ParkPlayService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author wang_zc
 * @date 2018/12/19
 */
@Slf4j
@Service
public class ParkPlayServiceImpl implements ParkPlayService {

    @Autowired
    private ParkPlayMapper parkPlayMapper;

    @Autowired
    private RedeemInfoMapper redeemInfoMapper;

    @Autowired
    private ParkInfoMapper parkInfoMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    /**
     * 4个过山车id
     */
    private final Long[] ROLLER_COASTER = {2L, 3L, 4L, 6L};

    /**
     * 获取园区游玩信息
     *
     * @return java.util.List<com.bilibili.meeting.model.ParkPlay>
     * @author wang_zc
     */
    @Override
    public List<ParkPlay> getParkPlayInfo(int id) {
        return parkPlayMapper.getParkPlayInfo(id);
    }

    /**
     * 查询是否兑奖
     *
     * @param id 员工id
     * @return boolean
     * @author wang_zc
     */
    @Override
    public boolean getRedeem(int id) {
        return redeemInfoMapper.getRedeem(id) != null;
    }

    /**
     * 扫码--签到、游玩、兑奖、道具领取
     *
     * @param id         员工id
     * @param parkWorker 扫码工作人员
     * @return java.lang.String
     * @author wang_zc
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public String scanCode(int id, ParkWorker parkWorker,String staffUuid) {
        if (parkWorker == null) {
            throw new RuntimeException("请使用工作人员账号登陆，并扫码");
        }
/*        if (userMapper.getStaffInfoById(id) == null) {
            throw new RuntimeException("员工不存在，请核对信息");
        }*/
        if (parkWorker.getWorkerType() == 1) {
            // 游玩
            return playScan(id, parkWorker,staffUuid);
        } else if (parkWorker.getWorkerType() == 2) {
            // 兑奖
            return redeemScan(id,staffUuid);
        } else if (parkWorker.getWorkerType() == 3) {
            // 签到
            return signIn(id);
        } else if (parkWorker.getWorkerType() == 4) {
            // 道具领取
            return prop(id);
        } else if (parkWorker.getWorkerType() == 5) {
            // 入园
            return intoPark(id);
        } else {
            throw new RuntimeException("工作人员类型不正确");
        }
    }

    /**
     * 游玩扫码
     *
     * @param id         员工id
     * @param parkWorker 扫码工作人员
     * @return java.lang.String
     * @author wang_zc
     */
    private String playScan(int id, ParkWorker parkWorker,String staffUuid) {
        // 查询此员工是否兑奖
        log.info("=============查询此员工是否兑奖=============");
        log.info("员工的id为：{}", id);
        RedeemInfo redeem = redeemInfoMapper.getRedeem(id);
        if (redeem != null) {
            // 说明已经兑奖
            // 推送场景值
            messagingTemplate.convertAndSend("/topic/codescan/" + staffUuid, 1);
            throw new RuntimeException("已兑奖，此次游玩不计分");
        }
        log.info("=============员工未兑奖=============");
        log.info("=============查询此点是否游玩过=============");
        // 查询此点是否游玩过
        ParkPlay p = parkPlayMapper.findByUserIdAndParkId(id, parkWorker.getParkId());
        if (p != null) {
            // 这个地方已经游玩过
            // 推送场景值
            messagingTemplate.convertAndSend("/topic/codescan/" + staffUuid, 1);
            throw new RuntimeException("请勿重复游玩扫码");
        }
        log.info("=============此点未游玩=============");

        // 游玩
        // 查询此次游玩可以获得的分数
        log.info("此次的游玩点为：{}", parkWorker.getParkName());
        ParkInfo parkInfo = parkInfoMapper.selectByPrimaryKey(parkWorker.getParkId());
        ParkPlay parkPlay = new ParkPlay();
        parkPlay.setParkId(parkInfo.getId());
        parkPlay.setParkName(parkInfo.getParkName());
        parkPlay.setUserId(id);
        parkPlay.setParkScore(parkInfo.getParkScore());
        parkPlayMapper.insertSelective(parkPlay);

        // 计算游玩点
        List<ParkPlay> parkPlayList = parkPlayMapper.getParkPlayInfo(id);

        // 计算4个过山车有没有游玩 i = 0 没有游玩， i = 1 已经游玩
        int i = 0;
        if (isPlayRollerCoaster(parkPlayList)) {
            // 游玩的地方包括了4个过山车
            i = 1;
        }

        // 更改员工表游玩状态
        StaffInfo staffInfo = new StaffInfo();
        staffInfo.setStaffUuid(id);
        staffInfo.setStaffPlayState("[" + parkPlayList.size() + "/7," + i + "/1]");
        // 修改员工信息
        userMapper.editStaff(staffInfo);

        // 推送场景值
        messagingTemplate.convertAndSend("/topic/codescan/" + staffUuid, 1);

        return "";
    }

    /**
     * 兑奖扫码
     *
     * @param id 员工id
     * @return java.lang.String
     * @author wang_zc
     */
    private String redeemScan(int id,String staffUuid) {
        // 查询此员工是否兑奖
        log.info("=============查询此员工是否兑奖=============");
        RedeemInfo redeem = redeemInfoMapper.getRedeem(id);
        if (redeem != null) {
            // 说明已经兑奖
            // 推送场景值
            messagingTemplate.convertAndSend("/topic/codescan/" + staffUuid, 2);
            throw new RuntimeException("该用户已兑奖"+redeem.getQuantity()+"张，请勿重复兑奖");
        }
        log.info("=============员工未兑奖=============");

        // 查询游玩区域
        List<ParkPlay> list = getParkPlayInfo(id);
        // 统计分数
        int score = 0;
        for (ParkPlay parkPlay : list) {
            score += parkPlay.getParkScore();
        }

        log.info("统计游玩分数，总分为：{} 分", score);

        // 兑奖所对应的刮刮卡数量
        int count = 0;
        if (list.size() == 7) {
            // 7个点全部游玩过
            count = 3;
        } else if (list.size() >= 4) {
            if (isPlayRollerCoaster(list)) {
                // 游玩的地方包括了4个过山车
                count++;
            }
            if (list.size() >= 5) {
                // 随机游玩5个及以上
                count++;
            }
        }

        log.info("统计兑刮刮卡数量，一共：{} 张", count);

        RedeemInfo redeemInfo = new RedeemInfo();
        redeemInfo.setUserId(id);
        redeemInfo.setUserScore(score);
        redeemInfo.setQuantity(count);
        redeemInfoMapper.insertSelective(redeemInfo);

        // 更改员工表兑奖状态
        StaffInfo staffInfo = new StaffInfo();
        staffInfo.setStaffUuid(id);
        staffInfo.setStaffPrizeState(1);
        userMapper.editStaff(staffInfo);

        // 推送场景值
        messagingTemplate.convertAndSend("/topic/codescan/" + staffUuid, 2);

        return count + "";
    }

    /**
     * 签到扫码
     *
     * @param id 员工id
     * @return String
     * @author wang_zc
     */
    private String signIn(int id) {
        log.info("id为 {} 的员工开始签到", id);
        // 员工信息
        StaffInfo info = userMapper.getStaffInfoByStaffUuid(id);

        // 查询是否签到
        /*if (info.getStaffSignState() == 1) {
            // 已经签到过
            // 推送场景值
            messagingTemplate.convertAndSend("/topic/codescan/" + id, 3);
            throw new RuntimeException("请勿重复签到");
        }*/

        StaffInfo staffInfo = new StaffInfo();
        staffInfo.setStaffUuid(id);
        staffInfo.setStaffSignState(1);
        // 更新状态
        userMapper.editStaff(staffInfo);

        // 推送场景值
        messagingTemplate.convertAndSend("/topic/codescan/" + info.getStaffId(), 3);

        log.info("===========签到结束==========");

        return info.getStaffPlaceInfo();
    }

    /**
     * 道具领取扫码
     *
     * @param id 员工id
     * @return String
     * @author wang_zc
     */
    private String prop(int id) {
        log.info("id为 {} 的员工开始领取道具", id);
        // 员工信息
        StaffInfo info = userMapper.getStaffInfoByStaffUuid(id);

        // 查询是否领取
        if (info.getStaffRecevieState() == 1) {
            // 已经领取过
            // 推送场景值
            messagingTemplate.convertAndSend("/topic/codescan/" + info.getStaffId(), 4);
            throw new RuntimeException(info.getStaffName());
        }

        StaffInfo staffInfo = new StaffInfo();
        staffInfo.setStaffUuid(id);
        staffInfo.setStaffRecevieState(1);
        // 更新状态
        userMapper.editStaff(staffInfo);

        // 推送场景值
        messagingTemplate.convertAndSend("/topic/codescan/" + info.getStaffId(), 4);

        log.info("===========领取道具结束==========");

        return info.getStaffName();
    }

    /**
     * 入园扫码
     *
     * @param id 员工id
     * @return String
     * @author wang_zc
     */
    private String intoPark(int id) {
        log.info("id为 {} 的员工开始入园", id);
        // 员工信息
        StaffInfo info = userMapper.getStaffInfoByStaffUuid(id);

        // 查询是否入园
        if (info.getStaffEnterState() == 1) {
            // 已经入园过
            // 推送场景值
            messagingTemplate.convertAndSend("/topic/codescan/" + info.getStaffId(), 5);
            throw new RuntimeException(info.getStaffName());
        }

        StaffInfo staffInfo = new StaffInfo();
        staffInfo.setStaffUuid(id);
        staffInfo.setStaffEnterState(1);
        // 更新状态
        userMapper.editStaff(staffInfo);

        // 推送场景值
        messagingTemplate.convertAndSend("/topic/codescan/" + info.getStaffId(), 5);

        log.info("===========入园结束==========");

        return info.getStaffName();
    }

    /**
     * 工作人员登录
     *
     * @param username
     * @param password
     * @return
     */
    @Override
    public ParkWorker workerLogin(String username, String password) {
        return parkPlayMapper.workerLogin(username, password);
    }

    /**
     * 计算游玩集合中是否包括4个过山车
     * 包括：return true
     * 不包括：return false
     *
     * @param parkPlayList 游玩点集合
     * @return boolean
     * @author wang_zc
     */
    private boolean isPlayRollerCoaster(List<ParkPlay> parkPlayList) {
        List<Long> longList = new ArrayList<>();
        parkPlayList.forEach(ppl -> longList.add(ppl.getParkId()));
        // 游玩的地方包括了4个过山车
        return longList.containsAll(Arrays.asList(ROLLER_COASTER));
    }

}

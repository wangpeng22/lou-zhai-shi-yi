package com.bilibili.meeting.service.impl;

import com.bilibili.meeting.mapper.InvitationMapper;
import com.bilibili.meeting.model.BaseData;
import com.bilibili.meeting.service.InvitationService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class InvitationServiceImpl implements InvitationService {
    @Resource
    private InvitationMapper invitationMapper;
    /**
     * 系统初始化将停车券及班车座位数缓存在reids中
     * @throws Exception
     */
    @Override
    public BaseData getBaseData() {
        return invitationMapper.getBaseData();
    }
}
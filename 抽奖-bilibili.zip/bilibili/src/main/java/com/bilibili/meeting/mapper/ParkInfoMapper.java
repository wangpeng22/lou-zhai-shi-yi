/** 
* Created by bzyx on 2018-12-19 
*/
package com.bilibili.meeting.mapper;

import com.bilibili.meeting.model.ParkInfo;

import java.util.List;

public interface ParkInfoMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ParkInfo record);

    int insertSelective(ParkInfo record);

    ParkInfo selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ParkInfo record);

    int updateByPrimaryKey(ParkInfo record);

    List<ParkInfo> findAllParkInfo();
}
package com.bilibili.meeting.dto;

/**
 * 活动查询DTO
 * Created by wangpeng on 2018/12/19 17:42
 */
public class ActivitySearchDTO extends SearchDTO {

    // 活动类型
    private Integer activityType;

    // 活动Id
    private Integer activityId;

    //  staffuuid
    private String userId;

    // staffId
    private Integer staffId;

    // 战队Id
    private Integer voteId;

    // 奖项Id
    private Integer activityPrizeId;

    // 部门Id
    private Integer departmentId;

    // 用户名
    private String userName;

    // 幸运儿Id
    private Integer activityLuckyDogId;

    public Integer getActivityLuckyDogId() {
        return activityLuckyDogId;
    }

    public void setActivityLuckyDogId(Integer activityLuckyDogId) {
        this.activityLuckyDogId = activityLuckyDogId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Integer departmentId) {
        this.departmentId = departmentId;
    }

    public Integer getActivityPrizeId() {
        return activityPrizeId;
    }

    public void setActivityPrizeId(Integer activityPrizeId) {
        this.activityPrizeId = activityPrizeId;
    }

    public Integer getVoteId() {
        return voteId;
    }

    public void setVoteId(Integer voteId) {
        this.voteId = voteId;
    }

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public Integer getActivityType() {
        return activityType;
    }

    public void setActivityType(Integer activityType) {
        this.activityType = activityType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Integer getStaffId() {
        return staffId;
    }

    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }
}

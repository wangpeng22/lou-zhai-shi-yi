package com.bilibili.meeting.config.aspect;

import com.alibaba.fastjson.JSONObject;
import com.bilibili.meeting.config.SpringContextBean;
import com.bilibili.meeting.config.annotation.Log;
import com.bilibili.meeting.core.Result;
import com.bilibili.meeting.core.ResultCode;
import com.bilibili.meeting.model.StaffInfo;
import com.bilibili.meeting.model.SysOperationLogWithBLOBs;
import com.bilibili.meeting.service.ISysOperationLogService;
import com.bilibili.meeting.utils.DateUtils;
import com.bilibili.meeting.utils.IpUtils;
import net.sf.json.util.JSONUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.util.*;

/**
 * @author wangyl
 * @since on 2018/5/10.
 */
public class RecordLog implements AspectApi {

    private Logger logger = LoggerFactory.getLogger(RecordLog.class);

    @Override
    public Object doHandlerAspect(Object [] obj ,ProceedingJoinPoint pjp, Method method,boolean isAll) throws Throwable{
        Log log  = method.getAnnotation( Log.class );
        // 异常日志信息
        String actionLog = null;
        StackTraceElement[] stackTrace =null;
        // 是否执行异常
        boolean isException = false;
        // 接收时间戳
        long endTime;
        // 开始时间戳
        long operationTime = System.currentTimeMillis();
        Object object=null;
        HttpServletRequest request=null;
        Set<Object> allParams = new LinkedHashSet<>();
        try {
            RequestAttributes ra = RequestContextHolder.getRequestAttributes();
            ServletRequestAttributes sra = (ServletRequestAttributes) ra;
            request = sra.getRequest();
//            BodyReaderHttpServletRequestWrapper requestWrapper=new BodyReaderHttpServletRequestWrapper(request);
            Object[] args = pjp.getArgs();
            getRequestParam(request,args,allParams);
            logger.info("执行方法信息 请求参数:"+JSONObject.toJSONString(allParams));
            Object objectErr=Arrays.stream(args).filter(a->a instanceof BindingResult).findFirst().orElse(null);
            if(objectErr!=null){
                BindingResult bindingResult=(BindingResult)objectErr;
                if (bindingResult.hasErrors()) {
                    logger.info("执行方法信息 异常返回:"+JSONObject.toJSONString(doErrorHandle(bindingResult)));
                    return doErrorHandle(bindingResult);
                }
            }
            object=pjp.proceed(obj);
            logger.info("执行方法信息 返回:"+JSONObject.toJSONString(object));
            return object;
        } catch ( Throwable throwable ) {
            isException = true;
            actionLog = throwable.getMessage();
            stackTrace = throwable.getStackTrace();
            throw throwable;
        }finally {
            logHandle( pjp , method , log , actionLog , operationTime , isException,stackTrace,request,allParams);
        }
    }

    private void logHandle (ProceedingJoinPoint joinPoint ,
                            Method method ,
                            Log log ,
                            String actionLog ,
                            long startTime  ,
                            boolean isException,
                            StackTraceElement[] stackTrace,
                            HttpServletRequest request,
                            Object args
    ) {
        ISysOperationLogService operationLogService = SpringContextBean.getBean(ISysOperationLogService.class);
//        String authorization = request.getHeader("Authorization");
        SysOperationLogWithBLOBs operationLog = new SysOperationLogWithBLOBs();
        //TODO 需要添加用户名
//        User user=getUserInfo(request);
//        if(user!=null){
//            operationLog.setUserName(user.getUsername());
//        }
        Object obj = request.getSession().getAttribute("currentStaff");
        if (obj != null){
            StaffInfo staffInfo = (StaffInfo)obj;
            operationLog.setUserName(staffInfo.getStaffName());
        }
        operationLog.setIp(IpUtils.getIpAddr(request));
        operationLog.setClassName(joinPoint.getTarget().getClass().getName() );
        operationLog.setCreateTime(DateUtils.longToDate(startTime));
        operationLog.setLogDescription(log.description());
        if(isException){
            StringBuilder sb = new StringBuilder();
            sb.append(actionLog+" &#10; ");
            for (int i = 0; i < stackTrace.length; i++) {
                sb.append(stackTrace[i]+" &#10; ");
            }
            operationLog.setMessage(sb.toString());
        }
        operationLog.setMethod(method.getName());
        operationLog.setSucceed(String.valueOf(!isException));

        if(args!=null){
            operationLog.setActionArgs(JSONObject.toJSONString(args));
        }
        operationLogService.insert(operationLog);
    }


    public static void getRequestParam(HttpServletRequest request,Object[] args,Set<Object> allParams){


        boolean isJoint = false;

        for(Object arg : args){
            if("-1".equals(arg)){
                continue;
            }
            if (arg instanceof Map<?, ?>) {
                Map<String, Object> map = (Map<String, Object>) arg;
                allParams.add(map);
            }else if(arg instanceof HttpServletRequest){
                request = (HttpServletRequest) arg;
                //获取query string 或 posted form data参数
                Map<String, String[]> paramMap = request.getParameterMap();
                if(paramMap!=null && paramMap.size()>0){
                    allParams.add(paramMap);
                }
            }else if(arg instanceof HttpServletResponse){
            }else if(arg instanceof String
                    || arg instanceof Long
                    || arg instanceof Integer
                    || arg instanceof Double
                    || arg instanceof Float
                    || arg instanceof Byte
                    || arg instanceof Short
                    || arg instanceof Character){
                isJoint=true;

            }
            else if(arg instanceof String []
                    || arg instanceof Long []
                    || arg instanceof Integer []
                    || arg instanceof Double []
                    || arg instanceof Float []
                    || arg instanceof Byte []
                    || arg instanceof Short []
                    || arg instanceof Character []){
                Object[] strs = (Object[])args;
                StringBuilder sbArray  =new StringBuilder();
                sbArray.append("[");
                for (Object str:strs) {
                    sbArray.append(str.toString()+",");
                }
                sbArray.deleteCharAt(sbArray.length()-1);
                sbArray.append("]");
                allParams.add(sbArray);
            }
            else if(arg instanceof BindingResult) {
            }else{
//                JSONObject jsonObject=JSON.parseObject(arg.toString());
//                jsonObject.put("userId","11");
//                jsonObject.put("orgId","222");
                allParams.add(arg);
            }
        }

        if(isJoint){
            StringBuilder sb = new StringBuilder();
            Map<String, String[]> parameterMap = request.getParameterMap();
            for (String key:parameterMap.keySet()) {
                String[] strings = parameterMap.get(key);
                for (String str:strings) {
                    sb.append(key+"="+str+"&");
                }
            }
            allParams.add(sb);
        }
    }

    public static Object doErrorHandle(BindingResult bindingResult){
        if(bindingResult != null){
            List<FieldError> errors=bindingResult.getFieldErrors();
            if(errors!=null&&errors.size()>0){
                Result result=new Result();
                result.setCode(ResultCode.FAIL.getCode());
                result.setMessage(errors.get(0).getDefaultMessage());
                return result;
            }
        }
        return  null;
    }



}

package com.bilibili.meeting.web;

import cn.hutool.core.date.DateTime;
import com.alibaba.fastjson.JSONObject;
import com.bilibili.meeting.config.RedisConfig;
import com.bilibili.meeting.config.annotation.Log;
import com.bilibili.meeting.config.annotation.Token;
import com.bilibili.meeting.core.Result;
import com.bilibili.meeting.core.ResultCode;
import com.bilibili.meeting.core.ResultGenerator;
import com.bilibili.meeting.model.BaseData;
import com.bilibili.meeting.service.InvitationService;
import com.bilibili.meeting.service.RedisService;
import com.bilibili.meeting.service.impl.RedisServiceImpl;
import com.bilibili.meeting.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Date;

/**
 * 邀请函模块
 * @author 梁荣兵
 * @version 1.0
 */
@RestController
@RequestMapping(value = "/invitation")
public class InvitationController implements InitializingBean {

    private static Logger logger = LoggerFactory.getLogger(InvitationController.class);

    @Autowired
    private InvitationService invitationService;

    @Autowired
    private RedisConfig redisConfig;
    @Autowired
    private RedisService redisService;
    /**
     * 系统初始化将停车券及班车座位数缓存在reids中
     * @throws Exception
     */
    @Override
    public void afterPropertiesSet() throws Exception {
       //查询数据库基础数据
        BaseData baseData = invitationService.getBaseData();
        if (baseData == null){
            return;
        }
        String parkCouponCount = redisConfig.getStringValue("parkCouponCount");
        String busSeatCount = redisConfig.getStringValue("busSeatCount");
        if (parkCouponCount == null || parkCouponCount.equals("")){
            //将停车券数量缓存到redis
            redisConfig.setValue("parkCouponCount",baseData.getParkCouponCount().toString());
        }
        if (busSeatCount == null || busSeatCount.equals("")){
            //将班车座位数量缓存到redis
            redisConfig.setValue("busSeatCount",baseData.getBusSeatCount().toString());
        }

    }
    /**
     * 跳转至报名页面
     * @throws IOException
     */
    @Log
    @Token(save=true)
    @RequestMapping(value = "/goSignPage",method = RequestMethod.GET)
    public Result goSignPage(HttpServletRequest request) throws Exception {

        logger.info("");
        //获取报名截止时间
        BaseData baseData = invitationService.getBaseData();
        Date closeTime = baseData.getCloseTime();
        Date currentTime = new Date();
        logger.info("closeTime is {},currentTime {}",closeTime,currentTime);
        if (closeTime.before(currentTime)){
            return ResultGenerator.genSuccessResult(ResultCode.TIMEISOVER.getCode(), ResultCode.TIMEISOVER.getMsg(), 0);
        }
        BaseData baseDataTemp = new BaseData();
        baseDataTemp.setParkCouponCount(Integer.parseInt(redisConfig.getStringValue("parkCouponCount"))<0?0:Integer.parseInt(redisConfig.getStringValue("parkCouponCount")));
        baseDataTemp.setBusSeatCount(Integer.parseInt(redisConfig.getStringValue("busSeatCount"))<0?0:Integer.parseInt(redisConfig.getStringValue("busSeatCount")));
        baseDataTemp.setToken(request.getSession().getAttribute("token").toString());
        return ResultGenerator.genSuccessResult(ResultCode.SUCCESS.getCode(), ResultCode.SUCCESS.getMsg(), baseDataTemp);
    }


    /**
     * 年会报名
     * @throws IOException
     */
    @Log
    @Token(remove=true)
    @RequestMapping(value = "/signUp",method = RequestMethod.GET)
    public Result signUp(@RequestParam("staffId") String staffId,@RequestParam("staffTripMode") Integer staffTripMode) throws Exception {
        return redisService.seckill(staffId, staffTripMode);
    }
    /**
     * 发送弹幕
     * @return
     */
    @Log
    @GetMapping(value = "/bilibiliSendMsg")
    public Result bilibiliSendMsg(@RequestParam("roomi") Integer roomi,
                                  @RequestParam("msg") String msg,
                                  @RequestParam("csrf") String csrf
    ){
        //获取当前时间戳
        Long currentTime = DateTime.now().getTime();
        String str = "{'roomid':"+roomi+",'msg':'"+msg+"','rnd':'"+currentTime+"','fontsize':25,'mode':1,'color':10,'csrf':'"+csrf+"'}";
        JSONObject jsonObject = CommonUtil.httpsRequest("https://api.live.bilibili.com/xlive/web-room/v1/dM/sendmsg", "POST", str);
        return ResultGenerator.genSuccessResult(jsonObject);
    }
}

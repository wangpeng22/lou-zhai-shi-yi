package com.bilibili.meeting.utils;

import com.bilibili.meeting.core.ResultCode;
import com.bilibili.meeting.exception.BusinessException;
import com.bilibili.meeting.model.ParkWorker;
import com.bilibili.meeting.model.StaffInfo;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

public class CurrentObjectUtil {
    /**
     * 从session获取员工登录信息
     * @return
     */
    public static StaffInfo getCurrentStaff() {
        HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
        StaffInfo staffInfo = (StaffInfo)request.getSession().getAttribute("currentStaff");
        if (null == staffInfo) {
            throw new BusinessException(ResultCode.NOT_LOGGED_IN.getCode(),ResultCode.NOT_LOGGED_IN.getMsg());
        }


        return staffInfo;
    }

    /**
     * 从session获取工作人员登录信息
     * @return
     */
    public static ParkWorker getCurrentWorkerInfo() {
        HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
        ParkWorker parkWorker = (ParkWorker)request.getSession().getAttribute("currentWorker");
        return parkWorker;
    }
}

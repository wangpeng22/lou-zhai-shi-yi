package com.bilibili.meeting.service.impl;

import com.bilibili.meeting.mapper.SysOperationLogMapper;
import com.bilibili.meeting.model.SysOperationLog;
import com.bilibili.meeting.model.SysOperationLogWithBLOBs;
import com.bilibili.meeting.service.ISysOperationLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SysOperationLogServiceImpl implements ISysOperationLogService {

    @Autowired
    private SysOperationLogMapper sysOperationLogMapper;

    @Override
    public int insert(SysOperationLogWithBLOBs sysOperationLog) {
        return sysOperationLogMapper.insert(sysOperationLog);
    }
}

/** 
* Created by bzyx on 2018-12-18 
*/
package com.bilibili.meeting.model;

import java.io.Serializable;

public class SysOperationLogWithBLOBs extends SysOperationLog implements Serializable {
    /** 日志名称 */
    private String actionArgs;

    /** 备注 */
    private String message;

    /**  */
    private static final long serialVersionUID = 1L;

    public String getActionArgs() {
        return actionArgs;
    }

    public void setActionArgs(String actionArgs) {
        this.actionArgs = actionArgs == null ? null : actionArgs.trim();
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message == null ? null : message.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", actionArgs=").append(actionArgs);
        sb.append(", message=").append(message);
        sb.append("]");
        return sb.toString();
    }
}
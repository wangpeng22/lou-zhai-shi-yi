package com.bilibili.meeting.mapper;

import com.bilibili.meeting.model.PrizeInfo;
import com.bilibili.meeting.model.PrizeInfoExample;
import com.bilibili.meeting.model.StaffInfo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StaffInfoMapper {

    void editStaff(@Param("staffInfo") StaffInfo staffInfo);
}
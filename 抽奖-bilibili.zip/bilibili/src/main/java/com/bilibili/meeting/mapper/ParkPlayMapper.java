/**
 * Created by bzyx on 2018-12-19
 */
package com.bilibili.meeting.mapper;

import com.bilibili.meeting.model.ParkPlay;
import com.bilibili.meeting.model.ParkWorker;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ParkPlayMapper {
    int deleteByPrimaryKey(Long id);

    int insert(ParkPlay record);

    int insertSelective(ParkPlay record);

    ParkPlay selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ParkPlay record);

    int updateByPrimaryKey(ParkPlay record);

    List<ParkPlay> getParkPlayInfo(int id);

    ParkWorker workerLogin(@Param("username") String username, @Param("password") String password);

    ParkPlay findByUserIdAndParkId(@Param("id") int id, @Param("parkId") Long parkId);
}
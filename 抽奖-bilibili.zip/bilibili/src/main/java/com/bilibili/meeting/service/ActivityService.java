package com.bilibili.meeting.service;

import com.bilibili.meeting.dto.*;

import java.util.List;

/**
 * 活动服务
 * Created by wangpeng on 2018/12/19 17:50
 */
public interface ActivityService {

    /**
     * 投票
     * @param activityUserVoteDTO
     */
    public void voting(ActivityUserVoteDTO activityUserVoteDTO);

    /**
     * 抽奖活动详情
     * @param activitySearchDTO
     * @return
     */
    public ActivityVoteDTO getActivityVote(ActivitySearchDTO activitySearchDTO);

    /**
     * "我的奖品"
     * @param activitySearchDTO
     * @return
     */
    public List<ActivityPrizeWinningDTO> myPrize(ActivitySearchDTO activitySearchDTO);

}

package com.bilibili.meeting.utils;

public enum EnumMethod {
	GET,POST;
}

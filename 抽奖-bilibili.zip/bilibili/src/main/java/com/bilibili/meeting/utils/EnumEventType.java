package com.bilibili.meeting.utils;

public enum EnumEventType {
	subscribe, unsubscribe, LOCATION, CLICK, VIEW;
}

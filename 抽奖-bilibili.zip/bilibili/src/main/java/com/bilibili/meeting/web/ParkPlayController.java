package com.bilibili.meeting.web;

import com.bilibili.meeting.config.RedisConfig;
import com.bilibili.meeting.config.annotation.Log;
import com.bilibili.meeting.core.Result;
import com.bilibili.meeting.core.ResultCode;
import com.bilibili.meeting.core.ResultGenerator;
import com.bilibili.meeting.model.ParkPlay;
import com.bilibili.meeting.model.ParkWorker;
import com.bilibili.meeting.model.StaffInfo;
import com.bilibili.meeting.service.ParkPlayService;
import com.bilibili.meeting.service.UserService;
import com.bilibili.meeting.utils.CurrentObjectUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 园区游玩controller
 *
 * @author wang_zc
 * @date 2018/12/19
 */
@RestController
@RequestMapping("/parkplay")
public class ParkPlayController {

    @Autowired
    private ParkPlayService parkPlayService;
    @Autowired
    private RedisConfig redisConfig;

    @Autowired
    private UserService userService;
    /**
     * 查询园区游玩信息
     *
     * @return com.bilibili.meeting.core.Result
     * @author wang_zc
     */
    @Log(description = "查询园区游玩信息")
    @PostMapping("/getParkPlayInfo")
    public Result getParkPlayInfo(@RequestBody StaffInfo staffInfo) {
        //根据uuid查询员工id
        StaffInfo temp = userService.getStaffInfoById(staffInfo.getStaffId());
        List<ParkPlay> parkPlayList = parkPlayService.getParkPlayInfo(temp.getStaffUuid());
        // 查询是否兑奖
        boolean redeem = parkPlayService.getRedeem(temp.getStaffUuid());

        Map<String, Object> map = new HashMap<>();
        map.put("parkPlayList", parkPlayList);
        map.put("redeem", redeem);

        return ResultGenerator.genSuccessResult(map);
    }

    /**
     * 扫码--签到、游玩、兑奖、道具领取
     *
     * @return com.bilibili.meeting.core.Result
     * @author wang_zc
     */
    @Log(description = "扫码--签到、游玩、兑奖、道具领取")
    @PostMapping("/scancode")
    public Result scanCode(@RequestBody ParkWorker parkWorker) {
        String result;
        try {
            //根据uuid查询员工id
            StaffInfo staffInfo = userService.getStaffInfoById(parkWorker.getStaffId());
            if (null == staffInfo) {
                return ResultGenerator.genFailResult("扫码失败，请重试");
            }
            result = parkPlayService.scanCode(staffInfo.getStaffUuid(), parkWorker,parkWorker.getStaffId());
        } catch (Exception e) {
            e.printStackTrace();
            return ResultGenerator.genFailResult(e.getMessage());
        }
        return ResultGenerator.genSuccessResult(result);
    }

    /**
     * 工作人员登录
     * @author xiaol
     */
    @Log(description = "工作人员登录")
    @GetMapping("/workerLogin")
    public Result workerLogin(@RequestParam("username") String username, @RequestParam("password") String password, HttpServletRequest request) {
        ParkWorker parkWorker = parkPlayService.workerLogin(username,password);
        if (parkWorker == null){
            return ResultGenerator.genSuccessResult(ResultCode.INVALID_USERNAME_PASSWORD.getCode(),ResultCode.INVALID_USERNAME_PASSWORD.getMsg(),null);
        }
        //将userId作为token存放到redis中
        redisConfig.setValue(parkWorker.getId(),parkWorker.getId());
        request.getSession().setAttribute("currentWorker",parkWorker);
        return ResultGenerator.genSuccessResult(ResultCode.SUCCESS.getCode(),ResultCode.SUCCESS.getMsg(),parkWorker);
    }
}

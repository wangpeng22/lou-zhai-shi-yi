package com.bilibili.meeting.service;

import com.bilibili.meeting.model.ParkPlay;
import com.bilibili.meeting.model.ParkWorker;

import java.util.List;

/**
 * @author wang_zc
 * @date 2018/12/19
 */
public interface ParkPlayService {

    /**
     * 获取园区游玩信息
     *
     * @param id 员工id
     * @return java.util.List<com.bilibili.meeting.model.ParkPlay>
     * @author wang_zc
     */
    List<ParkPlay> getParkPlayInfo(int id);

    /**
     * 查询是否兑奖
     *
     * @param id 员工id
     * @return boolean
     * @author wang_zc
     */
    boolean getRedeem(int id);

    /**
     * 扫码--签到、游玩、兑奖、道具领取
     *
     * @param id         员工id
     * @param parkWorker 扫码工作人员
     * @return java.lang.String
     * @author wang_zc
     */
    String scanCode(int id, ParkWorker parkWorker,String staffUuid);

    /**
     * 工作人员登录
     * @param username
     * @param password
     * @return
     */
    ParkWorker workerLogin(String username, String password);
}

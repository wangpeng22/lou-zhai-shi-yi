package com.bilibili.meeting.service;


import com.bilibili.meeting.model.BaseData;

/**
 * 邀请函模块
 */
public interface InvitationService {

    /**
     * 系统初始化将停车券及班车座位数缓存在reids中
     * @throws Exception
     */
    BaseData getBaseData();
}

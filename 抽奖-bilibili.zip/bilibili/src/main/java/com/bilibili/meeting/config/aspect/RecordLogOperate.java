package com.bilibili.meeting.config.aspect;

/**
 * @author wangyl
 * @since on 2018/5/10.
 */
public class RecordLogOperate extends AspectHandler{
    @Override
    protected RecordLog factoryMethod() {
        return new RecordLog();
    }
}

package com.bilibili.meeting.service;

import com.bilibili.meeting.model.StaffInfo;

/**
 * 用户操作模块
 */
public interface UserService {

    /**
     * 根据userId查询对应的数据信息
     * @param staffId
     * @return
     */
    StaffInfo getStaffInfoById(String staffId);
    /**
     * 编辑员工信息
     */
    void editStaff(StaffInfo staffInfoa);

    /**
     * 根据手机号码查询用户信息
     * @param mobile
     * @return
     */
    StaffInfo getStaffInfoByMobile(String mobile);
}

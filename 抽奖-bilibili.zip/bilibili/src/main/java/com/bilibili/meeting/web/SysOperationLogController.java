package com.bilibili.meeting.web;


import com.bilibili.meeting.config.annotation.Log;
import com.bilibili.meeting.model.SysOperationLogWithBLOBs;
import com.bilibili.meeting.service.ISysOperationLogService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 操作日志 前端控制器
 * </p>
 *
 * @author wangyl
 * @since 2018-08-23
 */
@RestController
@RequestMapping("/sysOperationLog")
public class SysOperationLogController {


    private final Logger logger = LoggerFactory.getLogger(SysOperationLogController.class);

    @Autowired
    public ISysOperationLogService iSysOperationLogService;


    /**
     * 保存和修改公用的
     * @param sysOperationLog  传递的实体
     * @return  0 失败  1 成功
     */
    @Log
    @RequestMapping(value="/sysOperationLogSave")
    public int sysOperationLogSave(SysOperationLogWithBLOBs sysOperationLog) {
        int count = 0;
        try {
            count = iSysOperationLogService.insert(sysOperationLog);
        } catch (Exception e) {
            logger.error("sysOperationLogSave -=- {}",e.toString());
        }
        return count;
    }



}

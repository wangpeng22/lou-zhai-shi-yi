package com.bilibili.meeting.dto;

import com.bilibili.meeting.model.ActivityVoteInfo;

import java.util.List;

/**
 * 投票结果DTO
 * Created by wangpeng on 2018/12/20 16:57
 */
public class ActivityVoteResultDTO extends BaseDTO {
    // 战队信息
    private List<ActivityVoteInfo> activityVoteInfoList;

    public List<ActivityVoteInfo> getActivityVoteInfoList() {
        return activityVoteInfoList;
    }

    public void setActivityVoteInfoList(List<ActivityVoteInfo> activityVoteInfoList) {
        this.activityVoteInfoList = activityVoteInfoList;
    }
}

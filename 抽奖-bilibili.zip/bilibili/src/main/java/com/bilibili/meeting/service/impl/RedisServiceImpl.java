package com.bilibili.meeting.service.impl;

import com.bilibili.meeting.config.RedisConfig;
import com.bilibili.meeting.core.Result;
import com.bilibili.meeting.core.ResultCode;
import com.bilibili.meeting.core.ResultGenerator;
import com.bilibili.meeting.mapper.InvitationMapper;
import com.bilibili.meeting.mapper.StaffInfoMapper;
import com.bilibili.meeting.mapper.UserMapper;
import com.bilibili.meeting.model.BaseData;
import com.bilibili.meeting.model.StaffInfo;
import com.bilibili.meeting.service.RedisService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;

@Service
public class RedisServiceImpl implements RedisService {
    private static Logger logger = LoggerFactory.getLogger(RedisServiceImpl.class);
    @Autowired
    private RedisConfig redisConfig;
    @Autowired
    private UserMapper userMapper;

    @Autowired
    private StaffInfoMapper staffInfoMapper;


    private HashMap<String, String> localOverMap =  new HashMap<String, String>();
    /**
     * 抢券
     */
    @Override
    public Result seckill(String staffId,Integer staffTripMode) throws Exception {
        //内存标记，减少redis访问
        String over = localOverMap.get(staffId);
        if (null != over && over.equals("1")) {
            return ResultGenerator.genSuccessResult(ResultCode.RESIGNUP.getCode(), ResultCode.RESIGNUP.getMsg(), 0);
        }
        //自行前往
        if (staffTripMode == 0){
            localOverMap.put(staffId, "1");
            editStaff(staffId, staffTripMode);
            return ResultGenerator.genSuccessResult(ResultCode.SUCCESS.getCode(), ResultCode.SUCCESS.getMsg(), 0);
        }
        //开车出行
        if (staffTripMode == 1){
            return parkTicket(staffId,staffTripMode);
        }
        //乘坐班车
        if (staffTripMode == 2){
            return busTicket(staffId,staffTripMode);
        }
        return null;
    }

    /**
     * 停车券
     */
    public Result parkTicket(String staffId,Integer staffTripMode) {
        //停车券数量减1
        long parkCouponCount = redisConfig.decr("parkCouponCount");
        String parkCouponCountTemp = redisConfig.getStringValue("parkCouponCount");
        logger.info("======================停车券剩余张数:"+parkCouponCountTemp);
        if (parkCouponCount < 0) {
            return ResultGenerator.genSuccessResult(ResultCode.ISEMPTY.getCode(), ResultCode.ISEMPTY.getMsg(), 0);
        }
        localOverMap.put(staffId, "1");
        //将该用户领取停车券状态修改为已经领取
        editStaff(staffId, staffTripMode);
        logger.info("员工ID为【"+staffId+"】的领取了一张停车券");
        return ResultGenerator.genSuccessResult(ResultCode.SUCCESS.getCode(), ResultCode.SUCCESS.getMsg(), 0);
    }
    /**
     * 班车座位数
     */
    public Result busTicket(String staffId,Integer staffTripMode) {
        //班车座位数量减1
        long parkCouponCount = redisConfig.decr("busSeatCount");
        if (parkCouponCount < 0) {
            return ResultGenerator.genSuccessResult(ResultCode.BUSISEMPTY.getCode(), ResultCode.BUSISEMPTY.getMsg(), 0);
        }
        localOverMap.put(staffId, "1");
        //将该用户领取班车座位状态修改为已经领取
        editStaff(staffId, staffTripMode);
        logger.info("员工ID为【"+staffId+"】的领取了一张班车座位券");
        return ResultGenerator.genSuccessResult(ResultCode.SUCCESS.getCode(), ResultCode.SUCCESS.getMsg(), 0);
    }
    /**
     * 更改员工出行方式状态
     */
    public void editStaff(String staffId,Integer staffTripMode) {
        logger.info("=================staffId====================="+staffId);
        StaffInfo staffInfo = new StaffInfo();
        staffInfo.setStaffRegistTime(new Date());
        staffInfo.setCreateTime(new Date());
        staffInfo.setStaffId(staffId);
        staffInfo.setStaffTripMode(staffTripMode);
        //编辑员工信息
        staffInfoMapper.editStaff(staffInfo);
    }
}

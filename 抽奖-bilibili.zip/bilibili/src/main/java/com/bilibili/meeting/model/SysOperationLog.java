/** 
* Created by bzyx on 2018-12-18 
*/
package com.bilibili.meeting.model;

import java.io.Serializable;
import java.util.Date;

public class SysOperationLog implements Serializable {
    /** 主键 */
    private Integer operationLogId;

    /** 日志类型 */
    private String logDescription;

    /** 用户id */
    private String userName;

    /** 类名称 */
    private String className;

    /** 方法名称 */
    private String method;

    /**  */
    private String ip;

    /** 创建时间 */
    private Date createTime;

    /** 是否成功 */
    private String succeed;

    /** 返回数据 */
    private String actionRet;

    /**  */
    private static final long serialVersionUID = 1L;

    public Integer getOperationLogId() {
        return operationLogId;
    }

    public void setOperationLogId(Integer operationLogId) {
        this.operationLogId = operationLogId;
    }

    public String getLogDescription() {
        return logDescription;
    }

    public void setLogDescription(String logDescription) {
        this.logDescription = logDescription == null ? null : logDescription.trim();
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className == null ? null : className.trim();
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method == null ? null : method.trim();
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip == null ? null : ip.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getSucceed() {
        return succeed;
    }

    public void setSucceed(String succeed) {
        this.succeed = succeed == null ? null : succeed.trim();
    }

    public String getActionRet() {
        return actionRet;
    }

    public void setActionRet(String actionRet) {
        this.actionRet = actionRet == null ? null : actionRet.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", operationLogId=").append(operationLogId);
        sb.append(", logDescription=").append(logDescription);
        sb.append(", userName=").append(userName);
        sb.append(", className=").append(className);
        sb.append(", method=").append(method);
        sb.append(", ip=").append(ip);
        sb.append(", createTime=").append(createTime);
        sb.append(", succeed=").append(succeed);
        sb.append(", actionRet=").append(actionRet);
        sb.append("]");
        return sb.toString();
    }
}
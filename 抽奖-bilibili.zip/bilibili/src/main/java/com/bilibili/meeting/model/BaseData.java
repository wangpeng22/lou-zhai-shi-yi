/** 
 * 基础数据（停车券及班车座位数）
*/
package com.bilibili.meeting.model;

import java.io.Serializable;
import java.util.Date;

public class BaseData implements Serializable {

  private Integer id;
     /*
      停车券数量
     */
  private Integer parkCouponCount;
    /*
      班车座位数量
     */
  private Integer busSeatCount;

  private Date closeTime;

    public Date getCloseTime() {
        return closeTime;
    }

    public void setCloseTime(Date closeTime) {
        this.closeTime = closeTime;
    }

    /*
      token
       */
  private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getParkCouponCount() {
        return parkCouponCount;
    }

    public void setParkCouponCount(Integer parkCouponCount) {
        this.parkCouponCount = parkCouponCount;
    }

    public Integer getBusSeatCount() {
        return busSeatCount;
    }

    public void setBusSeatCount(Integer busSeatCount) {
        this.busSeatCount = busSeatCount;
    }
}
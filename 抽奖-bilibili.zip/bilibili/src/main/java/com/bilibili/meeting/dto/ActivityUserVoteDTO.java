package com.bilibili.meeting.dto;
/**
 * Created by wangpeng on 2018/12/20 11:33
 */
public class ActivityUserVoteDTO extends BaseDTO {
    private Integer activityId;
    private Integer voteId;
    // 前端传的是StaffUUId 弃用
    private String userId;
    private Integer staffId;

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public Integer getVoteId() {
        return voteId;
    }

    public void setVoteId(Integer voteId) {
        this.voteId = voteId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Integer getStaffId() {
        return staffId;
    }

    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }
}

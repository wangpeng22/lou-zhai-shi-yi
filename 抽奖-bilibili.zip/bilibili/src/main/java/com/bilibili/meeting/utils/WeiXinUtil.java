package com.bilibili.meeting.utils;

import com.alibaba.fastjson.JSONObject;
import com.bilibili.meeting.config.RedisConfig;
import com.bilibili.meeting.core.Result;
import com.bilibili.meeting.core.ResultCode;
import com.bilibili.meeting.core.ResultGenerator;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Map;
import java.util.UUID;

@Component
public class WeiXinUtil {
	private static Logger logger = LoggerFactory.getLogger(WeiXinUtil.class);
	 /**
	  * 企业微信部分
	  *	corpid		企业ID
	  *	corpsecret	应用的凭证密钥
	  * agentid	 授权方的网页应用ID，在具体的网页应用中查看
	  * redirectUri	重定向地址，需要进行UrlEncode
	  * state	用于保持请求和回调的状态，授权请求后原样带回给企业。该参数可用于防止csrf攻击（跨站请求伪造攻击），建议企业带上该参数，可设置为简单的随机数加session进行校验
	  */
	/*public final static String agentid = "1000002";
	public final static String redirectUri = "http://www.binyouyun.com";
	public final static String state = "bilibili";
	public final static String corpid = "wwbf3195b7d4cc2e18";
	public final static String corpsecret = "w7sa22YZDhtT5wYBFXNn-CviPJEP_34fyUnEakj3R4g";*/

	@Value("${wechat.agentid}")
	public  String agentid;
	@Value("${wechat.redirectUri}")
	public  String redirectUri;
	@Value("${wechat.state}")
	public  String state;
	@Value("${wechat.corpid}")
	public  String corpid;
	@Value("${wechat.corpsecret}")
	public  String corpsecret;
    @Autowired
    private RedisConfig redisConfig;
	public  String errorCode = "40029";
	public  String successCode = "0";

	public  String accessTokenUrl="https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=ID&corpsecret=SECRET";
	//获取扫码人对应的UserId
	public  String userBaseInfo="https://qyapi.weixin.qq.com/cgi-bin/user/getuserinfo?access_token=ACCESS_TOKEN&code=CODE";
    //根据UserId获取微信成员信息
	public  String userDetailInfo="https://qyapi.weixin.qq.com/cgi-bin/user/get?access_token=ACCESS_TOKEN&userid=USERID";
    //获取企业微信扫一扫ticket
	public String getScanCodeSign = "https://qyapi.weixin.qq.com/cgi-bin/get_jsapi_ticket?access_token=ACCESS_TOKEN";

	//public String url="http://mp.weixin.qq.com";
	public  String getCodeUrl() {
		//该连接用于获取code参数（二维码）
		String url="https://open.work.weixin.qq.com/wwopen/sso/qrConnect?appid="+corpid+"&agentid="+agentid+"&redirect_uri="+redirectUri+"&state="+state;
		return url;
	}
	public  String getCodePageUrl() {
		//getAccessToken();
		//该连接用于获取code参数（网页授权链接）
		//String pageurl="https://open.weixin.qq.com/connect/oauth2/authorize?appid="+corpid+"&redirect_uri="+redirectUri+"&response_type=code&scope=snsapi_base&state="+state;
		String pageurl="https://open.weixin.qq.com/connect/oauth2/authorize?appid="+corpid+"&redirect_uri="+redirectUri+"&response_type=snsapi_privateinfo&agentid="+agentid+"&scope=snsapi_base&state="+state+"#wechat_redirect";
		return pageurl;
	}
	/**
	 * 获取access_token是调用企业微信API接口的第一步，相当于创建了一个登录凭证，其它的业务API接口，都需要依赖于access_token来鉴权调用者身份
	 * @return
	 */
	public  AccessToken getAccessToken(String code) {
		AccessToken accesstoken=new AccessToken();
		byte [] accessToken = redisConfig.getValue(code);
		if (accessToken != null && !accessToken.equals("")){
			accesstoken.setToken(new String(accessToken));
		} else {
			//替换真实appid和appsecret
			String requestUrl = accessTokenUrl.replace("ID", corpid).replace("SECRET", corpsecret);
			//得到json对象
			JSONObject jsonObject = CommonUtil.httpsRequest(requestUrl, "GET", null);
			logger.info("======================access_token"+jsonObject.getString("access_token"));
			redisConfig.setValueTime(code,jsonObject.getString("access_token"),Long.parseLong("5400"));
			//将得到的json对象的属性值，存到accesstoken中
			accesstoken.setToken(jsonObject.getString("access_token"));
			accesstoken.setExpiresIn(jsonObject.getString("expires_in"));
		}
		return accesstoken;
	}


	/**
	 * 获取access_token是调用企业微信API接口的第一步，相当于创建了一个登录凭证，其它的业务API接口，都需要依赖于access_token来鉴权调用者身份
	 * @return
	 */
	public  AccessToken getAccessTokenForTicket() {
		AccessToken accesstoken=new AccessToken();
		//替换真实appid和appsecret
		String requestUrl = accessTokenUrl.replace("ID", corpid).replace("SECRET", corpsecret);
		//得到json对象
		JSONObject jsonObject = CommonUtil.httpsRequest(requestUrl, "GET", null);
		logger.info("======================access_token"+jsonObject.getString("access_token"));
		//将得到的json对象的属性值，存到accesstoken中
		accesstoken.setToken(jsonObject.getString("access_token"));
		accesstoken.setExpiresIn(jsonObject.getString("expires_in"));
		return accesstoken;
	}

	/**
	 * 获取访问用户身份
	 * @param code  前端传递的code值，代表授权成功
	 * @return
	 */
	public  Result getWeChatUserInfo(String code) {
		logger.info("======================获取access_token start=======================");
		String requestUrl = userBaseInfo.replace("ACCESS_TOKEN", getAccessToken(code).getToken()).replace("CODE", code);
		logger.info("======================获取access_token end=======================");
		logger.info("======================通过网页授权获取用户信息 start=========requestUrl"+requestUrl);
		//通过网页授权获取用户信息
		JSONObject jsonObject = CommonUtil.httpsRequest(requestUrl, EnumMethod.GET.name(), null);
		logger.info("======================通过网页授权获取用户信息 end=======================");
		//获取请求返回码
		String responseCode = jsonObject.getString("errcode");
		//获取请求返回信息
		String responseMsg = jsonObject.getString("errmsg");
		logger.info("=======================获取请求返回码"+responseCode);
		logger.info("=======================获取请求返回信息"+responseMsg);
		if (responseCode.equals(errorCode)) {
			return ResultGenerator.genFailResult(responseMsg);
		} else if (responseCode.equals(successCode)) {
			//获取UserId
			String userId = jsonObject.getString("UserId");
			if (userId == null || userId.equals("")){
				return ResultGenerator.genSuccessResult(ResultCode.USERNOTENTERPRISE.getCode(),ResultCode.USERNOTENTERPRISE.getMsg(),null);
			} else {
				/*logger.info("=======================获取UserId"+userId);
				//根据UserId获取用户详细信息
				String userDetail = userDetailInfo.replace("ACCESS_TOKEN", getAccessToken().getToken()).replace("USERID", userId);
				JSONObject userDetailObject = CommonUtil.httpsRequest(userDetail, EnumMethod.GET.name(), null);
				//获取请求返回码
				String responseUserDetailCode = userDetailObject.getString("errcode");
				//获取请求返回信息
				String responseUserDetailMsg = userDetailObject.getString("errmsg");
				if (responseUserDetailCode.equals(successCode)) {*/
					//return ResultGenerator.genSuccessResult(userDetailObject.getString("mobile"));
				return ResultGenerator.genSuccessResult(userId);
				/*} else {
					return ResultGenerator.genFailResult(responseUserDetailMsg);
				}*/
			}
		}
		return ResultGenerator.genFailResult(responseMsg);
	}


	/**
	 * 微信开发之使用java获取签名signature
	 * @return
	 */
	public  Result getScanQRSignature(String url) {
        byte [] ticketRedis = redisConfig.getValue("ticket");
        if (ticketRedis != null && !ticketRedis.equals("")){
            //获取签名signature
            String noncestr = UUID.randomUUID().toString();
            String timestamp = Long.toString(System.currentTimeMillis() / 1000);
            String str = "jsapi_ticket=" + new String(ticketRedis) +
                    "&noncestr=" + noncestr +
                    "&timestamp=" + timestamp +
                    "&url=" + url;
            //sha1加密
            Map<String,String> temp = new HashedMap();
            temp.put("signature",SHA1(str));
            temp.put("timestamp",timestamp);
            temp.put("noncestr",noncestr);
            temp.put("agentid",agentid);
            temp.put("corpid",corpid);
            return ResultGenerator.genSuccessResult(ResultCode.SUCCESS.getCode(),ResultCode.SUCCESS.getMsg(),temp);
        } else {
            String requestUrl = getScanCodeSign.replace("ACCESS_TOKEN", getAccessTokenForTicket().getToken());
            //通过网页授权获取用户信息
            JSONObject jsonObject = CommonUtil.httpsRequest(requestUrl, EnumMethod.GET.name(), null);
            //获取请求返回码
            String responseCode  = jsonObject.getString("errcode");
            //获取请求返回信息
            String responseMsg = jsonObject.getString("errmsg");
            if (responseCode.equals(errorCode)) {
                return ResultGenerator.genFailResult(responseMsg);
            } else if (responseCode.equals(successCode)) {
                //获取ticket
                String ticket =  jsonObject.getString("ticket");
                redisConfig.setValueTime("ticket",ticket,Long.parseLong("5400"));
                //获取签名signature
                String noncestr = UUID.randomUUID().toString();
                String timestamp = Long.toString(System.currentTimeMillis() / 1000);
                String str = "jsapi_ticket=" + ticket +
                        "&noncestr=" + noncestr +
                        "&timestamp=" + timestamp +
                        "&url=" + url;
                //sha1加密
                Map<String,String> temp = new HashedMap();
                temp.put("signature",SHA1(str));
                temp.put("timestamp",timestamp);
                temp.put("noncestr",noncestr);
                temp.put("agentid",agentid);
                temp.put("corpid",corpid);
                return ResultGenerator.genSuccessResult(ResultCode.SUCCESS.getCode(),ResultCode.SUCCESS.getMsg(),temp);
            }
            return ResultGenerator.genFailResult(responseMsg);
        }
	}

	public static String SHA1(String str) {
		try {
			MessageDigest digest = java.security.MessageDigest
					.getInstance("SHA-1"); //如果是SHA加密只需要将"SHA-1"改成"SHA"即可
			digest.update(str.getBytes());
			byte messageDigest[] = digest.digest();
			// Create Hex String
			StringBuffer hexStr = new StringBuffer();
			// 字节数组转换为 十六进制 数
			for (int i = 0; i < messageDigest.length; i++) {
				String shaHex = Integer.toHexString(messageDigest[i] & 0xFF);
				if (shaHex.length() < 2) {
					hexStr.append(0);
				}
				hexStr.append(shaHex);
			}
			return hexStr.toString();

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return null;
	}
}

	

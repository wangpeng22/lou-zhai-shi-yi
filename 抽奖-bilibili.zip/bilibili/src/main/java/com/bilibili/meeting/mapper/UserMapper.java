
package com.bilibili.meeting.mapper;

import com.bilibili.meeting.model.StaffInfo;
import org.apache.ibatis.annotations.Param;

public interface UserMapper {
    /**
     * 根据userId查询对应的数据信息
     * @param staffId
     * @return
     */
    StaffInfo getStaffInfoById(@Param("staffId") String staffId);
    /**
     * 编辑员工信息
     * @param staffInfo
     * @return
     */
    void editStaff(@Param("staffInfo") StaffInfo staffInfo);

    /**
     * 根据手机号码查询员工信息
     * @param mobile
     * @return
     */
    StaffInfo getStaffInfoByMobile(@Param("mobile") String mobile);

    StaffInfo getStaffInfoByStaffUuid(@Param("id") int id);
}
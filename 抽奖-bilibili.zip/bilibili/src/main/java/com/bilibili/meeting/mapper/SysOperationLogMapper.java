/** 
* Created by bzyx on 2018-12-18 
*/
package com.bilibili.meeting.mapper;

import com.bilibili.meeting.model.SysOperationLog;
import com.bilibili.meeting.model.SysOperationLogWithBLOBs;

public interface SysOperationLogMapper {
    int deleteByPrimaryKey(Integer operationLogId);

    int insert(SysOperationLogWithBLOBs record);

    int insertSelective(SysOperationLogWithBLOBs record);

    SysOperationLogWithBLOBs selectByPrimaryKey(Integer operationLogId);

    int updateByPrimaryKeySelective(SysOperationLogWithBLOBs record);

    int updateByPrimaryKeyWithBLOBs(SysOperationLogWithBLOBs record);

    int updateByPrimaryKey(SysOperationLog record);
}
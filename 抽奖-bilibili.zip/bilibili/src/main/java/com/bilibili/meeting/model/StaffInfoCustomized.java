package com.bilibili.meeting.model;

/**
 * Created by wangpeng on 2018/12/21 14:38
 */
public class StaffInfoCustomized extends Base {

    private Integer staffId;
    private String staffName;
    private Integer deptId;
    private String deptName;

    public Integer getStaffId() {
        return staffId;
    }

    public void setStaffId(Integer staffId) {
        this.staffId = staffId;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public Integer getDeptId() {
        return deptId;
    }

    public void setDeptId(Integer deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }
}

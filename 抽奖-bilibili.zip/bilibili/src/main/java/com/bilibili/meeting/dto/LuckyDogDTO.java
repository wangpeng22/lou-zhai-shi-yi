package com.bilibili.meeting.dto;

/**
 * Created by wangpeng on 2018/12/20 18:41
 */
public class LuckyDogDTO {
}

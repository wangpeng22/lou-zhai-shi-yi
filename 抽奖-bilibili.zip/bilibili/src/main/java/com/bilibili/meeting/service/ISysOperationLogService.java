package com.bilibili.meeting.service;

import com.bilibili.meeting.model.SysOperationLog;
import com.bilibili.meeting.model.SysOperationLogWithBLOBs;

public interface ISysOperationLogService {
    int insert(SysOperationLogWithBLOBs sysOperationLog);
}

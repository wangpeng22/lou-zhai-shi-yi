package com.bilibili.meeting.service;

import com.bilibili.meeting.core.Result;

public interface RedisService {

	/***
	 * 抢券
	 */
	Result seckill(String staffId,Integer staffTripMode) throws Exception;
}

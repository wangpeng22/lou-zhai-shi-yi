/** 
* Created by bzyx on 2018-12-19 
*/
package com.bilibili.meeting.model;

import java.io.Serializable;
import java.util.Date;

public class ParkPlay implements Serializable {
    /** 主键 */
    private Long id;

    /** 游玩者id */
    private Integer userId;

    /** 园区id */
    private Long parkId;

    /** 园区名称 */
    private String parkName;

    /** 计分--游玩时可获得的分数 */
    private Integer parkScore;

    /** 创建时间 */
    private Date createTime;

    /** 更新时间 */
    private Date updateTime;

    /**  */
    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Long getParkId() {
        return parkId;
    }

    public void setParkId(Long parkId) {
        this.parkId = parkId;
    }

    public String getParkName() {
        return parkName;
    }

    public void setParkName(String parkName) {
        this.parkName = parkName == null ? null : parkName.trim();
    }

    public Integer getParkScore() {
        return parkScore;
    }

    public void setParkScore(Integer parkScore) {
        this.parkScore = parkScore;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", userId=").append(userId);
        sb.append(", parkId=").append(parkId);
        sb.append(", parkName=").append(parkName);
        sb.append(", parkScore=").append(parkScore);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append("]");
        return sb.toString();
    }
}
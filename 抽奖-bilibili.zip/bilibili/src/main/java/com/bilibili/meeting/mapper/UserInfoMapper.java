/** 
* Created by bzyx on 2018-12-18 
*/
package com.bilibili.meeting.mapper;

import com.bilibili.meeting.model.UserInfo;

public interface UserInfoMapper {
    int deleteByPrimaryKey(Long userId);

    int insert(UserInfo record);

    int insertSelective(UserInfo record);

    UserInfo selectByPrimaryKey(Long userId);

    int updateByPrimaryKeySelective(UserInfo record);

    int updateByPrimaryKey(UserInfo record);
}
package com.bilibili.meeting.config;


import com.alibaba.fastjson.JSON;
import com.bilibili.meeting.core.Result;
import com.bilibili.meeting.core.ResultCode;
import com.bilibili.meeting.exception.BusinessException;
import com.bilibili.meeting.exception.ServiceException;
import com.bilibili.meeting.utils.SpringContextUtils;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 全局配置
 * @author
 * @date 2018-12-18 14:58:32
 */
@Configuration
public class WebMvcConfigurer extends WebMvcConfigurationSupport {
    public final static String HEADER_TOKEN_NAME = "sessionId";
    public final static String HEADER_TOKEN_NAME_WORKER = "workerSessionId";
    private final Logger logger = LoggerFactory.getLogger(WebMvcConfigurer.class);
    /**
     * 当前配置文件
     */
    @Value("${spring.profiles.active}")
    private String env;
    /**
     * 统一异常处理
     * @param exceptionResolvers
     */
    @Override
    public void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {
        exceptionResolvers.add((request, response, handler, e)-> {
                Result result = new Result();
                if (handler instanceof HandlerMethod) {
                    HandlerMethod handlerMethod = (HandlerMethod) handler;

                    //业务失败的异常，如“账号或密码错误”
                    if (e instanceof ServiceException) {
                        result.setCode(ResultCode.FAIL.getCode()).setMessage(e.getMessage());
                        logger.info(e.getMessage());
                    }
                    else if (e instanceof BusinessException) {
                        BusinessException businessException = (BusinessException)e;
                        result.setCode(businessException.getErrCode()).setMessage(businessException.getMessage());
                    }
                    else {
                        result.setCode(ResultCode.INTERNAL_SERVER_ERROR.getCode()).setMessage("接口 [" + request.getRequestURI() + "] 内部错误，请联系管理员");
                        String message = String.format("接口 [%s] 出现异常，方法：%s.%s，异常摘要：%s",
                                request.getRequestURI(),
                                handlerMethod.getBean().getClass().getName(),
                                handlerMethod.getMethod().getName(),
                                e.getMessage());
                        logger.error(message, e);
                    }
                } else {
                    if (e instanceof NoHandlerFoundException) {
                        result.setCode(ResultCode.NOT_FOUND.getCode()).setMessage("接口 [" + request.getRequestURI() + "] 不存在");
                    }else {
                        result.setCode(ResultCode.INTERNAL_SERVER_ERROR.getCode()).setMessage(e.getMessage());
                        logger.error(e.getMessage(), e);
                    }
                }
                responseResult(response, result);
                return new ModelAndView();
        });
    }

    /**
     * 解决跨域问题
     * @param registry
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {

    }

    /**
     * 添加拦截器
     * @param registry
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
       registry.addInterceptor(new TokenInterceptor()).addPathPatterns("/invitation/goSignPage");
        registry.addInterceptor(new TokenInterceptor()).addPathPatterns("/invitation/signUp");
         registry.addInterceptor(new HandlerInterceptorAdapter() {
                @Override
                public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
                    RedisConfig redisService = SpringContextUtils.getBean(RedisConfig.class);
                    String id = request.getHeader(HEADER_TOKEN_NAME);
                    try {
                        if(request.getRequestURI().contains("scancode")){
                            String workerId = request.getHeader(HEADER_TOKEN_NAME_WORKER);
                            if (workerId != null && !workerId.equals("")){
                                String workId = redisService.getStringValue(workerId);
                                if (workerId.equals(workId)){
                                    return true;
                                } else {
                                    Result result = new Result();
                                    result.setCode(ResultCode.NOT_LOGGED_IN_WORKER.getCode()).setMessage(ResultCode.NOT_LOGGED_IN_WORKER.getMsg());
                                    responseResult(response, result);
                                    return false;
                                }
                            }else {
                                Result result = new Result();
                                result.setCode(ResultCode.NOT_LOGGED_IN_WORKER.getCode()).setMessage(ResultCode.NOT_LOGGED_IN_WORKER.getMsg());
                                responseResult(response, result);
                                return false;
                            }
                        }
                        String userId = redisService.getStringValue(id);
                        if (id.equals(userId)){
                            return true;
                        } else {
                            Result result = new Result();
                            result.setCode(ResultCode.UNAUTHORIZED.getCode()).setMessage(ResultCode.UNAUTHORIZED.getMsg());
                            responseResult(response, result);
                            return false;
                        }
                    } catch (Exception e){
                        Result result = new Result();
                        result.setCode(ResultCode.UNAUTHORIZED.getCode()).setMessage(ResultCode.UNAUTHORIZED.getMsg());
                        responseResult(response, result);
                        return false;
                    }

                }
            }).addPathPatterns("/**").excludePathPatterns("/auth/**")
                 .excludePathPatterns("/parkplay/workerLogin")
                 .excludePathPatterns("/h5/activity/**")
                 .excludePathPatterns("/invitation/bilibiliSendMsg");//;
//                 .excludePathPatterns("/invitation/signUp");
    }

    private void responseResult(HttpServletResponse response, Result result) {
        response.setCharacterEncoding("UTF-8");
        response.setHeader("Content-type", "application/json;charset=UTF-8");
        response.setStatus(200);
        try {
            response.getWriter().write(JSON.toJSONString(result));
        } catch (IOException ex) {
            logger.error(ex.getMessage());
        }
    }

    /**
     * 一个简单的签名认证，规则：请求参数按ASCII码排序后，拼接为a=value&b=value...这样的字符串后进行MD5
     *
     * @param request
     * @param requestSign
     * @return
     */
    private boolean validateSign(HttpServletRequest request, String requestSign) {
        List<String> keys = new ArrayList<String>(request.getParameterMap().keySet());
        Collections.sort(keys);

        String linkString = "";

        for (String key : keys) {
            if (!"sign".equals(key)) {
                linkString += key + "=" + request.getParameter(key) + "&";
            }
        }
        if (StringUtils.isEmpty(linkString)) {
            return false;
        }

        linkString = linkString.substring(0, linkString.length() - 1);
        //自己修改
        String key = "Potato";
        String sign = DigestUtils.md5Hex(linkString + key);

        return StringUtils.equals(sign, requestSign);

    }

    private String getIpAddress(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        // 如果是多级代理，那么取第一个ip为客户ip
        if (ip != null && ip.indexOf(",") != -1) {
            ip = ip.substring(0, ip.indexOf(",")).trim();
        }

        return ip;
    }

}

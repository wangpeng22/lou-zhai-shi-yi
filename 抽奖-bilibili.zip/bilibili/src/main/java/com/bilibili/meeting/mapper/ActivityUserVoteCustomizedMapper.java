package com.bilibili.meeting.mapper;

import com.bilibili.meeting.model.ActivityUserVote;
import com.bilibili.meeting.model.ActivityVoteStatistics;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by wangpeng on 2018/12/20 17:37
 */
@Repository
public interface ActivityUserVoteCustomizedMapper {

    public List<ActivityVoteStatistics> statistics(@Param("activityId") Integer activityId);

    /**
     * 统计有效的投票用户（过滤已经获得其他活动奖品的用户），即可以参与抽奖的人群
     * @param activityId
     * @param voteId
     * @return
     */
    public Integer countValidVoteUser(@Param("activityId") Integer activityId, @Param("voteId")Integer voteId);

    /**
     * 查询有效的投票用户（过滤已经获得其他活动奖品的用户），即可以参与抽奖的人群
     * @param activityId
     * @param voteId
     * @return
     */
    public List<ActivityUserVote> selectValidVoteUser(@Param("activityId") Integer activityId, @Param("voteId")Integer voteId);
}

package com.bilibili.meeting.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.awt.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * 启动完成后打开浏览器.实现ApplicationRunner也可实现服务启动完成后执行指定操作
 */

@Component
public class StartupRunner implements CommandLineRunner {
    private static final Logger logger = LoggerFactory.getLogger(StartupRunner.class.getName());
    @Value("${server.port}")
    private int port;

    @Value("${spring.profiles.active}")
    private String env;
	@Override
	public void run(String... arg0) throws Exception {
	    logger.info("{} 服务启动完成! 服务端口:{}",env,port);
	}

	@Async
	public void openBrowser() {
	    String url = "http://localhost:"+port;
		try {
			if(Desktop.isDesktopSupported()){
				Desktop.getDesktop().browse(new URI(url));
				return ;
			}
			Runtime.getRuntime().exec("rundll32 url.dll,FileProtocolHandler "+url);
		} catch (IOException | URISyntaxException e) {
			logger.warn("open url:{} ,{}",url,e.getLocalizedMessage());
		}
	}
}


package com.bilibili.meeting.mapper;

import com.bilibili.meeting.model.BaseData;
import com.bilibili.meeting.model.StaffInfo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

public interface InvitationMapper {
    /**
     * 系统初始化将停车券及班车座位数缓存在reids中
     * @throws Exception
     */
    BaseData getBaseData();
}
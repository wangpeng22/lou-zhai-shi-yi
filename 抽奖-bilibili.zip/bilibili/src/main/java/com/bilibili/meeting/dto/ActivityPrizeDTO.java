package com.bilibili.meeting.dto;

import com.bilibili.meeting.model.ActivityPrizeInfo;
import com.bilibili.meeting.model.PrizeInfo;

import java.util.List;

/**
 * Created by wangpeng on 2018/12/19 18:49
 */
public class ActivityPrizeDTO extends ActivityPrizeInfo {


    public static ActivityPrizeDTO transfer (ActivityPrizeInfo activityPrizeInfo) {
        if (null == activityPrizeInfo) {
            return null;
        }
        ActivityPrizeDTO activityPrizeDTO = new ActivityPrizeDTO();
        activityPrizeDTO.setId(activityPrizeInfo.getId());
        activityPrizeDTO.setActivityPrizeName(activityPrizeInfo.getActivityPrizeName());
        activityPrizeDTO.setActivityPrizeDesc(activityPrizeInfo.getActivityPrizeDesc());
        activityPrizeDTO.setActivityPrizeWinningNumber(activityPrizeInfo.getActivityPrizeWinningNumber());
        activityPrizeDTO.setActivityId(activityPrizeInfo.getActivityId());
        activityPrizeDTO.setPrizeId(activityPrizeInfo.getPrizeId());
        return activityPrizeDTO;
    }

    // 奖品
    private List<PrizeInfo> prizeInfoList;

    public List<PrizeInfo> getPrizeInfoList() {
        return prizeInfoList;
    }

    public void setPrizeInfoList(List<PrizeInfo> prizeInfoList) {
        this.prizeInfoList = prizeInfoList;
    }
}

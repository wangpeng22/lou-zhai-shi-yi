package com.bilibili.meeting.web;

import com.bilibili.meeting.config.RedisConfig;
import com.bilibili.meeting.config.annotation.Log;
import com.bilibili.meeting.config.annotation.Token;
import com.bilibili.meeting.core.Result;
import com.bilibili.meeting.core.ResultCode;
import com.bilibili.meeting.core.ResultGenerator;
import com.bilibili.meeting.exception.BusinessException;
import com.bilibili.meeting.model.StaffInfo;
import com.bilibili.meeting.service.RedisService;
import com.bilibili.meeting.service.UserService;
import com.bilibili.meeting.utils.QrCodeCreateUtil;
import com.bilibili.meeting.utils.WeiXinUtil;
import com.google.zxing.WriterException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.net.URL;

/**
 * 微信扫码认证登录模块
 * @author 梁荣兵
 * @version 1.0
 */
@RestController
@RequestMapping(value = "/auth")
public class WeChatAuthController {
    private static Logger logger = LoggerFactory.getLogger(WeiXinUtil.class);
    @Autowired
    private UserService userService;

    @Autowired
    private RedisConfig redisConfig;

    @Autowired
    private WeiXinUtil weiXinUtil;

    /**
     * 构造独立窗口登录二维码(此方法紧返回微信所需得获取code参数的链接)
     * @return 获取code参数的链接
     * @throws IOException
     */
    @Log
    @RequestMapping(value = "/ ")
    public Result createShortUrl() {
        return  ResultGenerator.genSuccessResult(ResultCode.SUCCESS.getCode(),ResultCode.SUCCESS.getMsg(),weiXinUtil.getCodeUrl());
    }

    /**
     * 构造网页授权链接
     * @return 获取code参数的链接
     * @throws IOException
     */
    @Log
    @RequestMapping(value = "/getCodePageUrl")
    public Result getCodePageUrl() {
        return  ResultGenerator.genSuccessResult(ResultCode.SUCCESS.getCode(),ResultCode.SUCCESS.getMsg(),weiXinUtil.getCodePageUrl());
    }

    /**
     * 根据用户授权的code获取对应信息
     * @param  code 用户授权code
     * @return 对应的成员信息
     * @throws IOException
     */
    @Log
    @RequestMapping(value = "/getMemberByCode")
    public Result getMemberByCode(@RequestParam("code") String code, HttpServletRequest request) throws IOException, WriterException {
        Result result = weiXinUtil.getWeChatUserInfo(code);
        //获取微信认证返回的userID
        if (result.getCode() == 200) {
            //String mobile = result.getData().toString();
            String userId = result.getData().toString();
            //根据手机号码查询对应的数据信息
            StaffInfo staffInfo = userService.getStaffInfoByMobile(userId);
            if (staffInfo == null) {
                return ResultGenerator.genSuccessResult(ResultCode.USERISNULL.getCode(),ResultCode.USERISNULL.getMsg(),staffInfo);
            }
            //将userId作为token存放到redis中
            redisConfig.setValue(staffInfo.getStaffId(),staffInfo.getStaffId());
            //根据用户信息生成用户二维码
            String qrPath = QrCodeCreateUtil.getQrCodeUrl(staffInfo.getStaffId());
            staffInfo.setStaffQrcodeUrl(qrPath);
            userService.editStaff(staffInfo);
            //将登录信息缓存到session中
            request.getSession().setAttribute("currentStaff",staffInfo);
            staffInfo.setStaffUuid(null);
            return ResultGenerator.genSuccessResult(ResultCode.SUCCESS.getCode(),ResultCode.SUCCESS.getMsg(),staffInfo);
        }
        return  result;
    }

    /**
     * 根据员工ID查询员工详情
     * @param staffId
     * @return
     */
    @Log
    @GetMapping(value = "/listStaffInfoById")
    public Result listStaffInfo(@RequestParam("staffId") String staffId){
        StaffInfo staffInfo = userService.getStaffInfoById(staffId);
        if (staffInfo == null) {
            return ResultGenerator.genSuccessResult(ResultCode.USERBYIDISNULL.getCode(),ResultCode.USERBYIDISNULL.getMsg(),0);
        }
        return ResultGenerator.genSuccessResult(ResultCode.SUCCESS.getCode(),ResultCode.SUCCESS.getMsg(),staffInfo);
    }

    /**
     * 企业微信扫一扫签名
     * @return
     */
    @Log
    @GetMapping(value = "/getScanQRSignature")
    public Result getScanQRSignature(@RequestParam("url") String url){
        return weiXinUtil.getScanQRSignature(url);
    }


    @RequestMapping(value = "/checkstaff/{staffUUID}/", method = RequestMethod.POST)
    @ResponseBody
    @Log
    public Result checkStaff(@PathVariable("staffUUID") String staffUUID) {
        StaffInfo staffInfo = userService.getStaffInfoById(staffUUID);

        if (null == staffInfo) {
            throw new BusinessException(ResultCode.USERBYIDISNULL.getCode(), ResultCode.USERBYIDISNULL.getMsg());
        }
        return ResultGenerator.genSuccessResult();
    }
}

package com.bilibili.meeting.model;

/**
 * 微信用户信息
 * @author Administrator
 * @version 1.0
 */
public class WeChatUserInfo {
	private String userid;	 //成员UserID。对应管理端的帐号，企业内必须唯一。不区分大小写，长度为1~64个字节
	private String name;	 //成员名称
	private String mobile;	 //手机号码，第三方仅通讯录应用可获取
	private String department;	//成员所属部门id列表
	private String order;	  //部门内的排序值，默认为0。数量必须和department一致，数值越大排序越前面。值范围是[0, 2^32)
	private String position;	//职务信息；第三方仅通讯录应用可获取
	private String gender;  	//性别。0表示未定义，1表示男性，2表示女性
	private String email;	  //邮箱，第三方仅通讯录套件可获取
	private String isleader;	//上级字段，标识是否为上级；第三方仅通讯录应用可获取
	private String avatar; 	//头像url。注：如果要获取小图将url最后的”/0”改成”/100”即可。第三方仅通讯录应用可获取
	private String telephone;	//座机。第三方仅通讯录应用可获取
	private String enable;	  //成员启用状态。1表示启用的成员，0表示被禁用。注意，服务商调用接口不会返回此字段
	private String alias;	 //别名；第三方仅通讯录应用可获取
	private String extattr;	//扩展属性，第三方仅通讯录应用可获取
	private String status;	  //激活状态: 1=已激活，2=已禁用，4=未激活。已激活代表已激活企业微信或已关注微工作台（原企业号）。未激活代表既未激活企业微信又未关注微工作台（原企业号）。
	private String qr_code	; //员工个人二维码，扫描可添加为外部联系人；第三方仅通讯录应用可获取
	private String external_profile;   //	成员对外属性，字段详情见对外属性；第三方仅通讯录应用可获取
	private String external_position;	//对外职务，如果设置了该值，则以此作为对外展示的职务，否则以position来展示。

	public WeChatUserInfo() {
	}

	public WeChatUserInfo(String userid, String name,
                          String mobile, String department,
                          String order, String position,
                          String gender, String email,
                          String isleader, String avatar,
                          String telephone, String enable,
                          String alias, String extattr,
                          String status, String qr_code,
                          String external_profile,
                          String external_position) {
		this.userid = userid;
		this.name = name;
		this.mobile = mobile;
		this.department = department;
		this.order = order;
		this.position = position;
		this.gender = gender;
		this.email = email;
		this.isleader = isleader;
		this.avatar = avatar;
		this.telephone = telephone;
		this.enable = enable;
		this.alias = alias;
		this.extattr = extattr;
		this.status = status;
		this.qr_code = qr_code;
		this.external_profile = external_profile;
		this.external_position = external_position;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIsleader() {
		return isleader;
	}

	public void setIsleader(String isleader) {
		this.isleader = isleader;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getEnable() {
		return enable;
	}

	public void setEnable(String enable) {
		this.enable = enable;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getExtattr() {
		return extattr;
	}

	public void setExtattr(String extattr) {
		this.extattr = extattr;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getQr_code() {
		return qr_code;
	}

	public void setQr_code(String qr_code) {
		this.qr_code = qr_code;
	}

	public String getExternal_profile() {
		return external_profile;
	}

	public void setExternal_profile(String external_profile) {
		this.external_profile = external_profile;
	}

	public String getExternal_position() {
		return external_position;
	}

	public void setExternal_position(String external_position) {
		this.external_position = external_position;
	}
}
